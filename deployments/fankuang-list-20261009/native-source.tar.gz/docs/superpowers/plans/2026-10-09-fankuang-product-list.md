# Fankuang Product List Implementation Plan

**Goal:** Show a compact 翻筐乐 badge beneath product names/codes and an optional 仅翻筐乐 filter, preserving store, status and search scope.

**Architecture:** Use the existing server in_fankuang projection, never guess from price when it is available. Add fankuang=1 to handheld products before counts/pagination/media signing. Include the selection in native request/cache identity. PC listSkus filters in PostgreSQL before its result limit; cards and rows use the shared enrollment rule.

**Tech Stack:** SwiftUI/XCTest, Kotlin/Compose/JUnit, TanStack/React/Node tests. Existing nullable fankuang_override; no migration.

- [x] Add failing HTTP tests for enrollment filtering before paging, manual false, current-store scope, all-status archives and counts.
- [x] Add native tests for canonical membership, filter URL and separate cache identities; observe failure before implementation.
- [x] Implement backend/schema, iPhone badge/filter/query/cache, Android badge/filter/query/persistence, PC card/row/filter.
- [x] Run backend and native tests/builds; render the iPhone fixture and inspect a screenshot. Verify PC components with isolated rendering.
- [ ] Commit scoped code/client snapshots to GitHub. Tencent publication and phone installation are separate acceptance, not implied by a local build.

Approved UI: add the badge to the existing badge area below the product code; add a compact toggle alongside current filters. Default off. Keep bottom navigation, location controls and status tabs unchanged. Active filtering combines with existing filters; zero-result and retry states remain existing states.

Verification: 106 backend/PC checks, 9 enrollment regression checks and 30 iOS tests passed. Exported and inspected the real SwiftUI product-list fixture at 390pt width. Android final tests passed (25) and debug APK built. Tencent listing-retouch-20261009-v2 published after scoped candidate build/checks; store, catalog, media and worker guards passed. No phone install is claimed.
