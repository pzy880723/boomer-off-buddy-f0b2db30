import Foundation
import CryptoKit

enum POSProductType: String, Codable {
    case custom
    case bundle
    case standard
}

enum POSCatalogTab: String, CaseIterable {
    case standard = "标准商品"
    case custom = "自定义商品"
}

struct POSCashSaleRejected: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

enum POSCashRecoveryResult {
    case completed(POSReceipt)
    case cancelled
}

struct POSCashSaleAttempt: Codable {
    let userID: String
    let locationID: String
    let operationID: String
    let payload: Data
    let fingerprint: String
    let subtotalCents: Int
    let discountCents: Int
    var uncertain = false
    var payableCents: Int { subtotalCents - discountCents }

    init(userID: String, locationID: String, body: [String: Any], cart: POSCart) throws {
        self.userID = userID
        self.locationID = locationID
        operationID = body["client_op_id"] as? String ?? ""
        payload = try JSONSerialization.data(withJSONObject: body, options: [.sortedKeys])
        fingerprint = Self.digest(payload)
        subtotalCents = cart.subtotalCents
        discountCents = cart.discountCents
        _ = try validatedBody()
    }

    static func digest(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    func validatedBody() throws -> [String: Any] {
        guard !userID.isEmpty, !locationID.isEmpty, !operationID.isEmpty,
              fingerprint == Self.digest(payload),
              let body = try JSONSerialization.jsonObject(with: payload) as? [String: Any],
              body["client_op_id"] as? String == operationID,
              let tenders = body["tenders"] as? [[String: Any]], tenders.count == 1,
              tenders.first?["provider"] as? String == "cash" else {
            throw APIError.message("现金收款保护记录损坏，请保留记录并联系 ERP 核对，勿重新收款")
        }
        return body
    }
}

@MainActor
final class POSCashRecoveryStore {
    static let shared = POSCashRecoveryStore()
    private let directory: URL

    init(directory: URL? = nil) {
        self.directory = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("pos-cash-recovery-v1", isDirectory: true)
    }

    private func file(userID: String, locationID: String) throws -> URL {
        guard !userID.isEmpty, !locationID.isEmpty else { throw APIError.message("请登录并选择门店后收款") }
        let scope = try JSONEncoder().encode([userID, locationID])
        return directory.appendingPathComponent(POSCashSaleAttempt.digest(scope) + ".json")
    }

    func load(userID: String, locationID: String) throws -> POSCashSaleAttempt? {
        let data: Data
        do { data = try Data(contentsOf: file(userID: userID, locationID: locationID)) }
        catch let error as CocoaError where error.code == .fileReadNoSuchFile { return nil }
        let attempt = try JSONDecoder().decode(POSCashSaleAttempt.self, from: data)
        guard attempt.userID == userID, attempt.locationID == locationID else {
            throw APIError.message("现金收款保护记录所属用户或门店不符")
        }
        _ = try attempt.validatedBody()
        return attempt
    }

    func save(_ attempt: POSCashSaleAttempt) throws {
        _ = try attempt.validatedBody()
        let existing = try load(userID: attempt.userID, locationID: attempt.locationID)
        guard existing == nil || (existing?.operationID == attempt.operationID && existing?.fingerprint == attempt.fingerprint) else {
            throw APIError.message("有未确认的现金收款，不能替换原单或幂等标识")
        }
        var record = attempt
        record.uncertain = attempt.uncertain || existing?.uncertain == true
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try JSONEncoder().encode(record).write(to: file(userID: record.userID, locationID: record.locationID), options: .atomic)
    }

    func remove(_ attempt: POSCashSaleAttempt, onlyIfCertain: Bool = false) throws -> Bool {
        guard let existing = try load(userID: attempt.userID, locationID: attempt.locationID) else { return true }
        guard existing.operationID == attempt.operationID, existing.fingerprint == attempt.fingerprint,
              !onlyIfCertain || !existing.uncertain else { return false }
        try FileManager.default.removeItem(at: file(userID: attempt.userID, locationID: attempt.locationID))
        return true
    }
}

struct POSStandardCatalog: Decodable {
    let locationID: String
    var groups: [POSStandardGroup]

    enum CodingKeys: String, CodingKey {
        case locationID = "location_id", groups
    }
}

struct POSStandardGroup: Decodable, Identifiable, Hashable {
    var id: String { categoryCode }
    let categoryCode: String
    let categoryName: String
    let imageURL: String?
    let subcategories: [POSStandardSubcategory]
    var prices: [POSStandardPrice]
    var locationID = ""

    enum CodingKeys: String, CodingKey {
        case categoryCode = "category_code", categoryName = "category_name"
        case imageURL = "image_url", subcategories, prices
    }
}

struct POSStandardSubcategory: Decodable, Hashable {
    let code: String
    let name: String
}

struct POSStandardPrice: Decodable, Identifiable, Hashable {
    var id: String { skuID }
    let skuID: String
    let price: Decimal
    var unitPriceCents: Int {
        var value = price * 100
        var rounded = Decimal()
        NSDecimalRound(&rounded, &value, 0, .plain)
        return NSDecimalNumber(decimal: rounded).intValue
    }

    enum CodingKeys: String, CodingKey {
        case skuID = "sku_id", price
    }
}

struct POSProduct: Identifiable, Hashable {
    var id: String { skuID }
    let skuID: String
    let name: String
    let unitPriceCents: Int
    let availableQuantity: Int
    let productType: POSProductType
    var skuCode = ""
    var barcode = ""
    var epc = ""
    var conditionGrade = ""
    var imageURL = ""
    var locationID = ""
    var saleOwnership = "owned"
    var discountEligible = true
    var isUnlimitedStock = false
}

struct POSProductPage {
    let items: [POSProduct]
    let nextOffset: Int?
}

struct POSHeldCart: Decodable, Identifiable {
    let id: String
    var locationID = ""
    let customerID: String?
    let heldAt: String?
    let items: [POSHeldItem]
    let discount: POSHeldDiscount?
    var itemCount: Int { items.reduce(0) { $0 + $1.quantity } }

    enum CodingKeys: String, CodingKey {
        case id, customerID = "customer_id", heldAt = "held_at"
        case items = "pos_held_cart_items", discount = "discount_snapshot"
    }
}

struct POSHeldItem: Decodable, Equatable {
    let skuID: String
    let quantity: Int
    enum CodingKeys: String, CodingKey { case skuID = "sku_id", quantity }
}

struct POSHeldDiscount: Decodable {
    let type: String?
    let value: Double?
    let reason: String?
}

struct POSCartLine: Identifiable, Hashable {
    var id: String { product.skuID }
    let product: POSProduct
    var quantity: Int
    var totalCents: Int { product.unitPriceCents * quantity }
}

struct POSCartAddResult: Equatable {
    let added: Bool
    let message: String
}

struct POSCart {
    private(set) var lines: [POSCartLine] = []
    private(set) var discountCents = 0

    var subtotalCents: Int { lines.reduce(0) { $0 + $1.totalCents } }
    var payableCents: Int { max(subtotalCents - discountCents, 0) }
    var itemCount: Int { lines.reduce(0) { $0 + $1.quantity } }

    mutating func add(_ product: POSProduct) -> POSCartAddResult {
        guard product.isUnlimitedStock || product.availableQuantity > 0 else {
            return POSCartAddResult(added: false, message: "商品没有可售库存")
        }
        guard let index = lines.firstIndex(where: { $0.product.skuID == product.skuID }) else {
            lines.append(POSCartLine(product: product, quantity: 1))
            normalizeDiscount()
            return POSCartAddResult(added: true, message: "")
        }
        guard product.productType != .custom else {
            return POSCartAddResult(added: false, message: "孤品已在购物车中")
        }
        guard product.isUnlimitedStock || lines[index].quantity < product.availableQuantity else {
            return POSCartAddResult(added: false, message: "已达到可售库存")
        }
        lines[index].quantity += 1
        normalizeDiscount()
        return POSCartAddResult(added: true, message: "")
    }

    mutating func setQuantity(skuID: String, quantity: Int) {
        guard let index = lines.firstIndex(where: { $0.product.skuID == skuID }) else { return }
        if quantity <= 0 {
            lines.remove(at: index)
        } else {
            if lines[index].product.productType == .custom {
                lines[index].quantity = 1
            } else if lines[index].product.isUnlimitedStock {
                lines[index].quantity = quantity
            } else {
                lines[index].quantity = min(quantity, lines[index].product.availableQuantity)
            }
        }
        normalizeDiscount()
    }

    mutating func applyDiscount(amountCents: Int) {
        discountCents = min(max(amountCents, 0), subtotalCents)
    }

    mutating func clear() {
        lines.removeAll()
        discountCents = 0
    }

    private mutating func normalizeDiscount() {
        discountCents = min(discountCents, subtotalCents)
    }
}

struct POSShift: Identifiable, Hashable {
    let id: String
    let locationID: String
    let status: String
    let registerName: String
}

struct POSCustomer: Identifiable, Hashable {
    let id: String
    let phone: String
    let nickname: String
    var points: Int? = nil
    var storeCreditCents = 0
    var memberLevel = ""

    var displayName: String {
        if !nickname.isEmpty { return nickname }
        return phone.count >= 7 ? "\(phone.prefix(3))****\(phone.suffix(4))" : "会员"
    }

    var membershipSummary: String {
        "\(memberLevel.isEmpty ? "类型暂无" : memberLevel) · \(points.map { "\($0) 积分" } ?? "积分暂无")"
    }
}

struct POSReceipt: Hashable {
    let orderID: String
    let orderNo: String
    let receiptNo: String
    let totalCents: Int
    let paymentProvider: String
    var providerTransactionID = ""
    var paidAt = ""
    var locationName = ""
    var cashierName = ""
    var subtotalCents = 0
    var discountCents = 0
    var items: [POSReceiptLine] = []
    var customerName = ""
}

struct POSReceiptLine: Hashable {
    let name: String
    let skuCode: String
    let quantity: Int
    let unitPriceCents: Int
    let lineTotalCents: Int
}

enum POSPaymentProvider: String {
    case wechat
    case alipay
    case cash

    static let defaultProvider = POSPaymentProvider.wechat
}

enum POSPaymentMode: String {
    case merchantScan = "merchant_scan"
    case customerScan = "customer_scan"

    static let defaultMode = POSPaymentMode.merchantScan
}

enum POSPaymentStatus: String {
    case pending
    case userPaying = "user_paying"
    case paid
    case failed
    case closed
    case expired

    var completesSale: Bool { self == .paid }
    var isTerminal: Bool { [.paid, .failed, .closed, .expired].contains(self) }
}

struct POSPaymentAttempt: Hashable {
    let id: String
    let provider: String
    let mode: POSPaymentMode
    let status: POSPaymentStatus
    let amountCents: Int
    let outTradeNo: String
    var providerTransactionID = ""
    var qrContent = ""
    var expiresAt = ""
    var message = ""
    var receipt: POSReceipt?
}

struct POSBootstrap {
    let locations: [Location]
    let openShift: POSShift?
}

struct POSDiscountPreview {
    let subtotalCents: Int
    let discountCents: Int
    let payableCents: Int
    let requiresAuthorization: Bool
    let authorizationRule: String
    var pointsRedemption: POSPointsRedemption? = nil
}

struct POSPointsRedemption: Decodable {
    let enabled: Bool
    let availablePoints: Int
    let maxPoints: Int
    let requestedPoints: Int
    let appliedPoints: Int
    let discountAmount: Decimal
    let reason: String?
    let capRate: Double?
    let pointsPerUnit: Int?
    let unitFen: Int?
    let policyVersion: Int?
    let supportedTenders: [String]?
    let asyncPaymentSupported: Bool?

    var discountCents: Int {
        var value = discountAmount * 100
        var rounded = Decimal()
        NSDecimalRound(&rounded, &value, 0, .plain)
        return NSDecimalNumber(decimal: rounded).intValue
    }

    var ruleMessage: String {
        switch reason {
        case "points_rule_not_configured": return "服务端尚未配置积分兑换规则"
        case "customer_inactive": return "当前会员不可用"
        case "membership_points_not_allowed": return "当前会员不支持积分抵扣"
        case "points_unavailable": return "本单暂无可抵扣积分"
        case "points_request_capped": return "已按服务端上限及兑换单位调整积分"
        default: return enabled ? "按服务端规则计算，结算时再次核验" : "积分抵扣暂不可用"
        }
    }

    enum CodingKeys: String, CodingKey {
        case enabled, reason
        case availablePoints = "available_points", maxPoints = "max_points"
        case requestedPoints = "requested_points", appliedPoints = "applied_points"
        case discountAmount = "discount_amount", capRate = "cap_rate"
        case pointsPerUnit = "points_per_unit", unitFen = "unit_fen", policyVersion = "policy_version"
        case supportedTenders = "supported_tenders", asyncPaymentSupported = "async_payment_supported"
    }
}

struct POSPaymentProfile {
    let ready: Bool
    let subjectName: String
    let merchantIDMasked: String
    let message: String
}

struct POSCashMovement: Identifiable, Hashable {
    let id: String
    let type: String
    let amountCents: Int
    let reason: String
    let createdAt: String
}

struct POSCashDrawer {
    let balanceCents: Int
    let movements: [POSCashMovement]
}

enum POSResolvedCode {
    case product(POSProduct)
    case customer(phone: String)
    case coupon(name: String)
}

struct Location: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let kind: String
}

struct ERPUser: Codable {
    let id: String
    let displayName: String
    let roles: [String]
    let avatarURL: String

    init(id: String, displayName: String, roles: [String], avatarURL: String = "") {
        self.id = id
        let name = displayName.trimmingCharacters(in: .whitespacesAndNewlines)
        self.displayName = name.contains("@") || (name.count == 11 && name.allSatisfy(\.isNumber)) ? "" : name
        self.roles = roles
        self.avatarURL = URL(string: avatarURL)?.scheme == "https" ? avatarURL : ""
    }

    private enum CodingKeys: String, CodingKey { case id, displayName, roles, avatarURL }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.init(id: try values.decode(String.self, forKey: .id),
                  displayName: try values.decode(String.self, forKey: .displayName),
                  roles: try values.decode([String].self, forKey: .roles),
                  avatarURL: try values.decodeIfPresent(String.self, forKey: .avatarURL) ?? "")
    }

    static func apiPayload(_ envelope: [String: Any]) -> ERPUser {
        let payload = envelope["user"] as? [String: Any] ?? envelope
        let id = (payload["id"] as? String).flatMap { $0.isEmpty ? nil : $0 }
            ?? payload["user_id"] as? String
            ?? ""
        let displayName = ["display_name", "name", "full_name"]
            .compactMap { payload[$0] as? String }
            .first { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            ?? ""
        let roles = payload["roles"] as? [String] ?? []
        return ERPUser(id: id, displayName: displayName, roles: roles, avatarURL: payload["avatar_url"] as? String ?? "")
    }
}

struct DashboardStats {
    var stockCount = 0
    var inventoryAccuracy: Double?
    var inTransitCount = 0
}

struct DashboardTask: Identifiable {
    let id: String
    let type: String
    let urgency: String
    let title: String
    let description: String
    let action: String
    let targetId: String
}

struct DashboardData {
    var stats = DashboardStats()
    var tasks: [DashboardTask] = []
    var unreadNotifications = 0
}

struct ProductCounts: Codable {
    var custom = 0
    var bundle = 0
    var standard = 0
    var all = 0
}

struct Product: Identifiable, Hashable, Codable {
    let id: String
    var name: String
    var skuCode: String
    var barcode: String
    var category: String
    var productType: String
    var imageURL: String
    var price: Double
    var stockQty: Int
    var conditionGrade: String
    var listingStatus: String
    var statusLabel: String
    var editable: Bool
    var canRestock: Bool
    var images: [String] = []
    var description: String = ""
    var brand: String = ""
    var era: String = ""
    var ipName: String = ""
    var tags: [String] = []
    var isUnlimitedStock = false
    var imageProcessingStatus: String?
    var locationStocks: [ProductLocationStock]?
    var canEdit: Bool?
    var canDelete: Bool?
    var updatedAt: String?
    var imageReferences: [ProductImageReference]?
    var fankuangOverride: Bool?

    var fankuangMembership: Bool?
    var inFankuang: Bool {
        guard productType == "custom", !isUnlimitedStock else { return false }
        return fankuangMembership ?? FankuangEnrollment.includes(price: String(price), override: fankuangOverride)
    }

    var allowsEditing: Bool {
        editable && productType != "standard" && canEdit == true && !(updatedAt ?? "").isEmpty
    }
}

func formattedProductPrice(_ price: Double) -> String {
    price.formatted(
        .number.locale(Locale(identifier: "en_US_POSIX"))
            .precision(.fractionLength(0...2))
            .grouping(.never)
    )
}

enum ProductPriceInput {
    static func amount(_ text: String) throws -> NSDecimalNumber {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard clean.range(of: #"^[0-9]+(\.[0-9]{1,2})?$"#, options: .regularExpression) != nil,
              let amount = Decimal(string: clean, locale: Locale(identifier: "en_US_POSIX")),
              amount > 0, amount <= Decimal(string: "999999.99")! else {
            throw APIError.message("售价需为 0.01–999,999.99 元，最多两位小数")
        }
        return NSDecimalNumber(decimal: amount)
    }
}

struct ProductEditInput {
    var name: String
    var price: String
    var grade: String
    var description: String
    var fankuangOverride: Bool?

    var inFankuang: Bool { FankuangEnrollment.includes(price: price, override: fankuangOverride) }

    func fields() throws -> [String: Any] {
        let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty, title.count <= 200 else { throw APIError.message("商品名称需为 1–200 字") }
        let amount = try ProductPriceInput.amount(price)
        guard ConditionGrade(rawValue: grade) != nil else { throw APIError.message("请选择有效成色") }
        guard description.count <= 2000 else { throw APIError.message("商品介绍不能超过 2000 字") }
        return ["name": title, "price_tier": amount,
                "condition_grade": grade, "description": description,
                "fankuang_override": fankuangOverride ?? NSNull()]
    }
}

enum FankuangEnrollment {
    static func includes(price: String, override: Bool?) -> Bool {
        if let override { return override }
        guard let amount = try? ProductPriceInput.amount(price) else { return false }
        return amount.compare(NSDecimalNumber(string: "49.9")) != .orderedDescending
    }
}

enum ProductImageProcessingPresentation {
    static func title(for status: String?) -> String? {
        switch status {
        case "queued", "processing": "主图正在修图"
        case "retryable_failed": "主图正在修图，正在自动重试"
        case "partial_failed": "部分主图修图未完成"
        default: nil
        }
    }

    static func shouldPoll(_ status: String?) -> Bool {
        ["queued", "processing", "retryable_failed", "partial_failed"].contains(status)
    }
}

struct StandardProductGroup: Identifiable, Hashable {
    let id: String
    let name: String
    let category: String
    let imageURL: String
    let tiers: [Product]

    var minimumPrice: Double { tiers.first?.price ?? 0 }
    var maximumPrice: Double { tiers.last?.price ?? 0 }
}

enum StandardProductGrouping {
    static func groups(from products: [Product]) -> [StandardProductGroup] {
        var orderedKeys: [String] = []
        var productsByKey: [String: [Product]] = [:]

        for product in products where product.productType == ProductType.standard.rawValue {
            let key = "\(product.category)|\(product.name)"
            if productsByKey[key] == nil { orderedKeys.append(key) }
            productsByKey[key, default: []].append(product)
        }

        return orderedKeys.compactMap { key in
            guard let products = productsByKey[key], let first = products.first else { return nil }
            let tiers = products.sorted {
                if $0.price == $1.price { return $0.skuCode < $1.skuCode }
                return $0.price < $1.price
            }
            return StandardProductGroup(
                id: key,
                name: first.name,
                category: first.category,
                imageURL: tiers.first(where: { !$0.imageURL.isEmpty })?.imageURL ?? "",
                tiers: tiers
            )
        }
    }
}

enum ProductPagePlan {
    static func additionalPages(total: Int, pageSize: Int) -> [Int] {
        guard pageSize > 0, total > pageSize else { return [] }
        return Array(2...Int(ceil(Double(total) / Double(pageSize))))
    }
}

struct ProductCacheKey: Hashable {
    let userID: String
    let locationID: String
    let type: String
    let status: String
    let sort: String
    let query: String
    var scope: String = "current_location"
    var authorization: String = ""
    var onlyFankuang = false

    var storageKey: String {
        let identity = [userID, locationID, scope, authorization, type, status, sort, query, String(onlyFankuang)].joined(separator: "|")
        let digest = SHA256.hash(data: Data(identity.utf8)).map { String(format: "%02x", $0) }.joined()
        return "location-scoped-v3-\(digest)"
    }
}

struct ProductSnapshot: Codable {
    let products: [Product]
    let counts: ProductCounts
}

struct StockLocation: Identifiable, Hashable {
    let id: String
    let name: String
    let kind: String
}

struct GlobalStockItem: Identifiable {
    let id: String
    let name: String
    let skuCode: String
    let barcode: String
    let category: String
    let productType: String
    let imageURL: String
    let price: Double
    let totalQty: Int
    let listingStatus: String
    let statusLabel: String
    let stocks: [String: Int]
    let isUnlimitedStock: Bool

    func displayLocations(from locations: [StockLocation]) -> [StockLocation] {
        productType == "custom" ? locations.filter { (stocks[$0.id] ?? 0) > 0 } : locations
    }

    var hasCustomLocationConflict: Bool {
        productType == "custom" && stocks.values.filter { $0 > 0 }.count > 1
    }
}

struct GlobalStockData {
    var locations: [StockLocation] = []
    var items: [GlobalStockItem] = []
    var skuCount = 0
    var totalQty = 0
    var outOfStock = 0
    var lowStock = 0
}

struct TransferRecord: Identifiable {
    let id: String
    let code: String
    let status: String
    let qty: Int
    let fromLocationID: String
    let toLocationID: String
    let createdAt: String
    let notes: String
}

struct TransferLine: Identifiable {
    var id: String { skuID }
    let skuID: String
    let expectedQty: Int
    let shippedQty: Int
    let receivedQty: Int
}

struct TransferEPC: Identifiable {
    var id: String { epc }
    let epc: String
    let skuID: String
    let shipScannedAt: String
    let receiveScannedAt: String
}

struct TransferDetail {
    let summary: TransferRecord
    let lines: [TransferLine]
    let epcs: [TransferEPC]
}

struct TransferScanResult {
    let side: String
    let received: Int
    let unknown: [String]
}

struct StocktakeRecord: Identifiable {
    let id: String
    let code: String
    let status: String
    let openedAt: String
    let submittedAt: String
    let notes: String
}

struct NotificationRecord: Identifiable {
    let id: String
    let kind: String
    let title: String
    let detail: String
    let timestamp: String
    var isRead: Bool? = nil
    var needsAction = false
    var locationName = ""
}

struct RFIDLookupResult {
    let known: Bool
    let epc: String
    let currentLocationID: String
    let currentLocationName: String
    let skuID: String
}

struct RFIDStockInResult {
    let accepted: Int
    let duplicated: [String]
}

struct RFIDBindResult {
    let epc: String
    let skuID: String
    let locationID: String
    let stockAfter: Int
}

enum LabelElementType: String, CaseIterable, Identifiable {
    case logo = "LOGO"
    case shopName = "SHOP_NAME"
    case itemName = "ITEM_NAME"
    case price = "PRICE"
    case category = "CATEGORY"
    case condition = "CONDITION"
    case description = "DESCRIPTION"
    case itemCode = "ITEM_CODE"
    case barcode = "BARCODE"
    case qrCode = "QR_CODE"
    case customText = "CUSTOM_TEXT"

    var id: String { rawValue }
}

enum LabelLogoPreset: String, CaseIterable, Identifiable {
    case horizontal
    case stacked

    var id: String { rawValue }
    var title: String { self == .horizontal ? "横版 Logo" : "叠版 Logo" }
    var assetName: String { self == .horizontal ? "BOLogoHorizontal" : "BOLogoStacked" }
}

struct LabelElement: Identifiable, Hashable {
    let id: String
    var type: LabelElementType
    var x: CGFloat
    var y: CGFloat
    var width: CGFloat
    var height: CGFloat
    var textSize: CGFloat
    var bold: Bool
    var enabled: Bool
    var customText: String
    var alignment: String
    var fontFamily: String
    var italic: Bool
    var underline: Bool
    var boxed: Bool

    var logoPreset: LabelLogoPreset {
        LabelLogoPreset(rawValue: customText) ?? .horizontal
    }

    var logoAssetName: String {
        logoPreset.assetName
    }
}

enum PrintTemplateType: String, CaseIterable, Identifiable, Hashable {
    case label
    case receipt

    var id: String { rawValue }
    var title: String { self == .label ? "标签" : "小票" }
}

struct LabelTemplate: Identifiable, Hashable {
    let id: String
    var name: String
    var widthMM: Int
    var heightMM: Int
    var elements: [LabelElement]
    var isDefault: Bool
    var version: Int
    var printType: PrintTemplateType = .label

    mutating func removeElement(id: String) {
        elements.removeAll { $0.id == id }
    }

    @discardableResult
    mutating func addElement(type: LabelElementType) -> LabelElement {
        let element = LabelElement(
            id: UUID().uuidString,
            type: type,
            x: 24,
            y: 110,
            width: type == .qrCode ? 80 : (type == .logo ? 300 : 230),
            height: type == .description ? 42 : (type == .barcode ? 56 : 28),
            textSize: type == .price ? 34 : 14,
            bold: type == .itemName || type == .price,
            enabled: true,
            customText: type == .logo
                ? LabelLogoPreset.horizontal.rawValue
                : (type == .customText ? "自定义文字" : ""),
            alignment: "center",
            fontFamily: "sans",
            italic: false,
            underline: false,
            boxed: false
        )
        elements.append(element)
        return element
    }
}

struct LabelTemplateCollection {
    var defaultTemplateID = ""
    var defaultTemplateIDs: [PrintTemplateType: String] = [:]
    var items: [LabelTemplate] = []
    var canManage = false

    func items(for type: PrintTemplateType) -> [LabelTemplate] {
        items.filter { $0.printType == type }
    }

    func defaultTemplateID(for type: PrintTemplateType) -> String {
        defaultTemplateIDs[type]
            ?? (type == .label ? defaultTemplateID : "")
    }
}

func canManageLabelTemplates(cloudPermission: Bool, roles: [String]) -> Bool {
    cloudPermission
        || roles.contains("super_admin")
        || roles.contains("hq_operator")
}

struct SyncRecord: Identifiable {
    let id: String
    let skuID: String
    let targetStock: Int
    let reason: String
    let status: String
    let attempts: Int
    let lastError: String
    let updatedAt: String
}

enum ParcelBucket: String, CaseIterable, Identifiable {
    case pending
    case received

    var id: String { rawValue }
    var title: String { self == .pending ? "待签收" : "已签收" }
}

enum ParcelListMode: String, CaseIterable, Identifiable {
    case item
    case parcel

    var id: String { rawValue }
    var title: String { self == .item ? "商品" : "包裹" }
}

struct ParcelCounts {
    var pending = 0
    var received = 0

    func count(for bucket: ParcelBucket) -> Int {
        bucket == .pending ? pending : received
    }
}

struct ParcelListResult {
    let mode: ParcelListMode
    let items: [ParcelItem]
    let rows: [ParcelRow]
    let hasMore: Bool
    let nextOffset: Int?
}

struct ParcelRow: Identifiable, Hashable {
    let id: String
    let trackingNo: String
    let sourceOrderNo: String
    let firstItemName: String
    let firstImageURL: String
    let seller: String
    let warehouseLocation: String
    let status: String
    let isProblem: Bool
    let grandTotalCNY: Double?
    let averageUnitCNY: Double?
    let itemCount: Int
    let totalQuantity: Int
    let purchasedAt: String
    let paidAt: String
    let receivedAt: String
    let createdAt: String
    let note: String
    let internationalFreightCNY: Double?
    let tariffCNY: Double?
    let goodsTotalCNY: Double?
    let weight: String
    let systemCode: String
}

struct ParcelItem: Identifiable, Hashable {
    var landedUnitCNY: Double? {
        guard let total = landedCNY, total.isFinite, total >= 0, quantity > 0 else { return nil }
        return total / Double(quantity)
    }

    let id: String
    let parcelID: String
    let name: String
    let originalName: String
    let imageURL: String
    let subOrderNo: String
    let systemCode: String
    let addedBy: String
    let addedAt: String
    let quantity: Int
    let itemTotalCNY: Double?
    let averageCNY: Double?
    let landedCNY: Double?
    var piecePriceCNY: Double?
    var piecePriceJPY: Double?
    var packPieces: Int?
    var packPiecesSource: String
    var packUnitNote: String
    let jpySubtotal: Double?
    let unitPriceJPY: Double?
    let weight: String
    let exchangeRate: Double?
    let serviceFeeCNY: Double?
    let domesticShippingCNY: Double?
    let shippingAdjustmentCNY: Double?
    let tariffCategory: String
    let taxRate: Double?
    let tariffJPY: Double?
    let allocatedFreightCNY: Double?
    let tariffCNY: Double?
    let paymentMethod: String
    let paidAt: String
    let merchantOrderNo: String
    let platform: String
    let condition: String
    let extraService: String
    let note: String
}

struct ParcelTotals {
    let goodsTotalCNY: Double?
    let freightCNY: Double?
    let tariffCNY: Double?
    let grandTotalCNY: Double?
    let totalQuantity: Int
    let itemCount: Int
}

struct ParcelDetail: Identifiable {
    var id: String { parcel.id }
    let parcel: ParcelRow
    let totals: ParcelTotals
    var items: [ParcelItem]
}

struct PackPiecesEstimate {
    let pieces: Int?
    let confidence: Double?
    let reasoning: String
    let unit: String
}

struct PackPiecesResult {
    let id: String
    let packPieces: Int?
    let source: String
    let unit: String
    let piecePriceCNY: Double?
    let piecePriceJPY: Double?
}

struct ListingSubmission: Codable, Equatable {
    let operationID: String
    let locationID: String
    let userID: String
    let body: Data
}

struct ListingDraft: Codable {
    var images: [Data] = []
    var uploadedPaths: [String] = []
    // Optional for older saved drafts. Keep image positions when a sibling upload fails.
    var uploadedImagePaths: [String?]?
    var listingPaths: [String] = []
    var listingURLs: [String] = []
    var name = ""
    var category = ""
    var categoryCode = ""
    var brand = ""
    var brandID: String?
    var brandMatchStatus: String?
    var brandConfirmed: Bool?
    var brandSuggestions: [IPRecognitionSuggestion]?
    var ipName = ""
    var ipMatchStatus = "empty"
    var ipConfirmed = true
    var ipSuggestions: [IPRecognitionSuggestion] = []
    var tags: [String] = []
    var facetCodes: [String]?
    var era = ""
    var conditionGrade = "A"
    var description = ""
    var price = ""
    var recognitionConfidence: Double?
    var recognitionWarning = ""
    var recognitionRequestID: String?
    var classificationStatus: String?
    var aiSuggestedPrice: Double?
    var submission: ListingSubmission?
    var fankuangOverride: Bool?

    var inFankuang: Bool { FankuangEnrollment.includes(price: price, override: fankuangOverride) }

    var rawUploadSlots: [String?] {
        if let uploadedImagePaths, uploadedImagePaths.count == images.count { return uploadedImagePaths }
        var slots = Array<String?>(repeating: nil, count: images.count)
        for (index, path) in uploadedPaths.prefix(images.count).enumerated() where !path.isEmpty {
            slots[index] = path
        }
        return slots
    }

    mutating func recordRawUpload(_ path: String, at index: Int) {
        guard submission == nil, images.indices.contains(index), !path.isEmpty else { return }
        var slots = rawUploadSlots
        slots[index] = path
        uploadedImagePaths = slots
        let completed = slots.compactMap { $0 }
        uploadedPaths = completed.count == images.count ? completed : []
    }

    mutating func prepareSubmission(locationID: String, userID: String) throws {
        if let submission {
            guard submission.locationID == locationID, submission.userID == userID else {
                throw APIError.message("这份草稿有待确认的上架，请切回原门店和账号后重试")
            }
            return
        }
        guard !locationID.isEmpty, !userID.isEmpty else {
            throw APIError.message("请先登录并选择上架门店")
        }
        let amount = try ProductPriceInput.amount(price)
        let operationID = "ios-smart-\(UUID().uuidString.lowercased())"
        var body: [String: Any] = [
            "name": name, "category": categoryCode.isEmpty ? category : categoryCode,
            "price_tier": amount, "is_custom_price": true,
            "fankuang_override": fankuangOverride ?? NSNull(),
            "grade": conditionGrade, "brand": brand, "ip_name": ipName,
            "ip_confirmed": ipConfirmed, "facet_codes": normalizedFacetCodes,
            "era": era, "notes": description, "location_id": locationID,
            "auto_push_youzan": true, "client_op_id": operationID,
            "recognition_request_id": recognitionRequestID?.isEmpty == false ? recognitionRequestID! : NSNull(),
            "category_confidence": recognitionConfidence ?? NSNull(),
            "classification_status": classificationStatus?.isEmpty == false ? classificationStatus! : NSNull(),
            "ai_suggested_price": aiSuggestedPrice ?? NSNull(),
            "image_storage_paths": uploadedPaths.map { ["bucket": "sku-raw", "storage_path": $0] }
        ]
        if let brandID, !brandID.isEmpty { body["brand_id"] = brandID }
        if let brandConfirmed { body["brand_confirmed"] = brandConfirmed }
        submission = ListingSubmission(operationID: operationID, locationID: locationID,
            userID: userID, body: try JSONSerialization.data(withJSONObject: body, options: .sortedKeys))
    }

    mutating func invalidateProcessedImages() {
        guard submission == nil else { return }
        let enteredPrice = price
        let enrollment = fankuangOverride
        self = ListingDraft(images: images)
        price = enteredPrice
        fankuangOverride = enrollment
    }

    mutating func clearRecognition() {
        guard submission == nil else { return }
        let originals = images
        let paths = uploadedPaths
        let checkpoints = uploadedImagePaths
        let preparedPaths = listingPaths
        let preparedURLs = listingURLs
        let enteredPrice = price
        let enrollment = fankuangOverride
        self = ListingDraft(images: originals, uploadedPaths: paths,
                            uploadedImagePaths: checkpoints,
                            listingPaths: preparedPaths, listingURLs: preparedURLs)
        price = enteredPrice
        fankuangOverride = enrollment
    }

    mutating func applyQuickTitle(_ title: String, baseline: ListingDraft) {
        guard submission == nil, name == baseline.name, !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        name = title
    }

    // Do not replace fields the employee edited while this request was running.
    mutating func applyRecognition(_ result: RecognitionPayload, baseline: ListingDraft) {
        guard submission == nil else { return }
        if name == baseline.name { name = result.name }
        if categoryCode == baseline.categoryCode {
            categoryCode = result.categoryCode
            category = result.category
            if facetCodes == baseline.facetCodes {
                facetCodes = result.facetCodes
                tags = result.tags
            }
        }
        if brand == baseline.brand {
            brand = result.brand
            brandID = result.brandID.isEmpty ? nil : result.brandID
            brandMatchStatus = result.brandMatchStatus
            brandSuggestions = result.brandSuggestions
            brandConfirmed = result.brand.isEmpty || result.brandMatchStatus == "matched"
        }
        if ipName == baseline.ipName {
            ipName = result.ipName
            ipMatchStatus = result.ipMatchStatus
            ipSuggestions = result.ipSuggestions
            ipConfirmed = result.ipName.isEmpty || result.ipMatchStatus == "matched"
        }
        if era == baseline.era { era = result.era }
        if conditionGrade == baseline.conditionGrade { conditionGrade = result.conditionGrade }
        if description == baseline.description { description = result.description }
        if price.isEmpty, let suggested = result.suggestedPrice {
            price = String(format: "%.2f", suggested)
        }
        recognitionConfidence = result.confidence
        recognitionWarning = result.warning
        recognitionRequestID = result.requestID
        classificationStatus = result.classificationStatus
        aiSuggestedPrice = result.suggestedPrice
    }

    var normalizedTags: [String] {
        var values: [String] = []
        var seen = Set<String>()
        for raw in tags {
            let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            let key = value.lowercased()
            guard !value.isEmpty, !seen.contains(key) else { continue }
            seen.insert(key)
            values.append(String(value.prefix(30)))
            if values.count == 10 { break }
        }
        return values
    }

    var normalizedFacetCodes: [String] {
        var values: [String] = []
        var seen = Set<String>()
        for raw in facetCodes ?? [] {
            let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !value.isEmpty, !seen.contains(value) else { continue }
            seen.insert(value)
            values.append(value)
            if values.count == 20 { break }
        }
        return values
    }

    var hasConfirmedCategory: Bool {
        !categoryCode.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && !category.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}

struct ProductCategoryOption: Identifiable, Hashable {
    var id: String { code }
    let code: String
    let name: String
    let parentName: String
    let parentCode: String

    var displayName: String {
        parentName.isEmpty ? name : "\(parentName) · \(name)"
    }
}

struct ProductFacetOption: Identifiable, Hashable {
    var id: String { code }
    let code: String
    let name: String
    let dimension: String
    let categoryCodes: [String]

    var dimensionName: String {
        switch dimension {
        case "object_type": "物件类型"
        case "function": "用途"
        case "origin": "产地"
        case "material": "材质"
        case "era": "年代"
        case "craft": "工艺"
        case "style": "风格"
        case "ip": "IP"
        case "character": "角色"
        case "series": "系列"
        case "release_method": "发行方式"
        default: "商品标签"
        }
    }
}

struct ProductTaxonomy {
    let categories: [ProductCategoryOption]
    let facets: [ProductFacetOption]

    func facets(for categoryCode: String) -> [ProductFacetOption] {
        guard let category = categories.first(where: { $0.code == categoryCode }) else { return [] }
        let scope = Set([category.code, category.parentCode].filter { !$0.isEmpty })
        return facets.filter { facet in
            facet.categoryCodes.isEmpty || facet.categoryCodes.contains(where: scope.contains)
        }
    }
}

enum ERPProductCategory: String, CaseIterable, Identifiable, Codable {
    case jpPorcelain = "jp_porcelain"
    case euPorcelain = "eu_porcelain"
    case vintageToy = "vintage_toy"
    case animeGoods = "anime_goods"
    case media
    case digital
    case jewelry
    case fashion
    case daily
    case antique

    var id: String { rawValue }

    var title: String {
        switch self {
        case .jpPorcelain: "日本瓷器"
        case .euPorcelain: "欧洲瓷器"
        case .vintageToy: "中古玩具"
        case .animeGoods: "二次元周边"
        case .media: "音像"
        case .digital: "数码家电"
        case .jewelry: "珠宝"
        case .fashion: "时尚配件"
        case .daily: "日用杂货"
        case .antique: "古美术"
        }
    }
}

enum ConditionGrade: String, CaseIterable, Codable, Identifiable {
    case n = "N"
    case s = "S"
    case a = "A"
    case b = "B"
    case c = "C"
    case j = "J"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .n: "全新/未拆封"
        case .s: "拆封无明显瑕疵"
        case .a: "轻微使用痕迹"
        case .b: "明显痕迹或轻微缺陷"
        case .c: "严重瑕疵但不影响使用"
        case .j: "垃圾级/功能不确定"
        }
    }

    var description: String {
        switch self {
        case .n: "全新/未拆封"
        case .s: "包装已拆封，功能完好，外观无明显瑕疵"
        case .a: "功能完好，外观有轻微使用痕迹"
        case .b: "功能完好，外观有明显使用痕迹或轻微缺陷"
        case .c: "功能完好，外观严重瑕疵，但不影响使用"
        case .j: "外观严重瑕疵，缺少零件，定义为垃圾，不确定功能是否正常"
        }
    }

    static func normalized(_ value: String?) -> ConditionGrade {
        guard let value else { return .a }
        return ConditionGrade(rawValue: value.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()) ?? .a
    }
}

enum ListingSubmissionAction {
    case listOnly
    case listAndPrint

    var shouldPrint: Bool {
        self == .listAndPrint
    }
}

enum ListingConfirmationRules {
    static func imageCount(urls: [String], localImages: [Data]) -> Int {
        max(urls.count, localImages.count)
    }

    static func pageLabel(index: Int, count: Int) -> String {
        guard count > 0 else { return "0 / 0" }
        return "\(min(max(index, 0), count - 1) + 1) / \(count)"
    }

    static func canSubmit(_ draft: ListingDraft, processedImageCount: Int) -> Bool {
        !draft.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && draft.hasConfirmedCategory
            && ConditionGrade(rawValue: draft.conditionGrade) != nil
            && (Double(draft.price) ?? 0) > 0
            && ListingUploadPlan.canCreate(rawPathCount: processedImageCount, imageCount: draft.images.count)
            && (draft.ipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || draft.ipConfirmed)
    }
}

enum ProductType: String, CaseIterable, Identifiable {
    case custom
    case bundle
    case standard

    var id: String { rawValue }
    var title: String {
        switch self {
        case .custom: "自定义"
        case .bundle: "组包"
        case .standard: "标准"
        }
    }
}

enum ListingStatus: String, CaseIterable, Identifiable {
    case all
    case selling
    case soldOut = "sold_out"
    case inWarehouse = "in_warehouse"

    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: "全部状态"
        case .selling: "销售中"
        case .soldOut: "已售罄"
        case .inWarehouse: "仓库中"
        }
    }
}
