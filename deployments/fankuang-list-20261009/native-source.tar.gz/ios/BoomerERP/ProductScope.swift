import Foundation

enum ProductViewScope: String {
    case currentLocation = "current_location"
    case all
}

enum ProductScopeError: LocalizedError {
    case mismatchedResponse
    var errorDescription: String? { "商品库位范围未能确认，请重新加载，不会显示其他门店商品。" }
}

struct ProductAccessError: LocalizedError {
    var errorDescription: String? { "当前账号无权查看该库位，请重新选择库位。" }
}

struct ProductListQuery: Hashable {
    let userID: String
    let locationID: String
    let authorization: String
    let scope: ProductViewScope
    let type: ProductType
    let status: ListingStatus
    let sort: String
    let search: String
    let onlyFankuang: Bool

    init(userID: String, location: Location, roles: [String], scope: ProductViewScope,
         type: ProductType = .custom, status: ListingStatus = .selling,
         sort: String = "updated_desc", search: String = "", onlyFankuang: Bool = false) {
        self.userID = userID
        locationID = location.id.lowercased()
        authorization = roles.sorted().joined(separator: ",")
        self.scope = HQToolVisibility.canShow(roles: roles, locationKind: location.kind) ? scope : .currentLocation
        self.type = type; self.status = status; self.sort = sort
        self.search = search.trimmingCharacters(in: .whitespacesAndNewlines)
        self.onlyFankuang = onlyFankuang
    }

    var marker: String { scope == .all ? "all" : "location:\(locationID)" }
    var cacheKey: ProductCacheKey {
        ProductCacheKey(userID: userID, locationID: locationID, type: type.rawValue,
                        status: status.rawValue, sort: sort, query: search,
                        scope: scope.rawValue, authorization: authorization, onlyFankuang: onlyFankuang)
    }

    func path(page: Int, pageSize: Int) -> String {
        var components = URLComponents()
        components.path = "products"
        components.queryItems = [
            .init(name: "scope", value: scope.rawValue),
            .init(name: "type", value: type.rawValue),
            .init(name: "status", value: status.rawValue),
            .init(name: "sort", value: sort),
            .init(name: "q", value: search),
            .init(name: "page", value: String(page)),
            .init(name: "page_size", value: String(pageSize)),
        ]
        if scope == .currentLocation {
            components.queryItems?.append(.init(name: "location_id", value: locationID))
        }
        if onlyFankuang { components.queryItems?.append(.init(name: "fankuang", value: "1")) }
        components.percentEncodedQuery = components.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        return components.string ?? ""
    }

    func detailPath(id: String) -> String {
        var components = URLComponents()
        let escapedID = id.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? ""
        components.percentEncodedPath = "items/\(escapedID)"
        components.queryItems = [.init(name: "scope", value: scope.rawValue)]
        if scope == .currentLocation {
            components.queryItems?.append(.init(name: "location_id", value: locationID))
        }
        return components.string ?? ""
    }

    func validateDetail(_ data: [String: Any]) throws {
        try validateResponse([
            "scope": data["scope"] ?? "",
            "items": [data],
            "counts": ["custom": 0, "bundle": 0, "standard": 0, "all": 0],
        ], checkEnrollment: false)
    }

    func validateResponse(_ data: [String: Any], checkEnrollment: Bool = true) throws {
        guard data["scope"] as? String == marker,
              let rows = data["items"] as? [[String: Any]],
              let counts = data["counts"] as? [String: Any],
              ["custom", "bundle", "standard", "all"].allSatisfy({ counts[$0] is NSNumber }) else {
            throw ProductScopeError.mismatchedResponse
        }
        for row in rows {
            if checkEnrollment && onlyFankuang && row["in_fankuang"] as? Bool != true { throw ProductScopeError.mismatchedResponse }
            guard let stocks = row["stocks"] as? [[String: Any]] else { throw ProductScopeError.mismatchedResponse }
            if scope == .currentLocation, row["product_type"] as? String != "standard",
               !stocks.contains(where: { ($0["location_id"] as? String)?.lowercased() == locationID }) {
                throw ProductScopeError.mismatchedResponse
            }
        }
    }
}

struct ProductLocationStock: Codable, Hashable, Identifiable {
    let id: String
    let name: String
    let kind: String
    let quantity: Int

    var displayName: String {
        if kind == "warehouse", name.contains("总部") || ["hq", "hq warehouse", "headquarters"].contains(name.lowercased()) {
            return "总部"
        }
        return name.isEmpty ? "库位未命名" : name
    }

    static func decode(_ rows: [[String: Any]]) -> [Self] {
        rows.compactMap { row in
            guard let id = row["location_id"] as? String, !id.isEmpty else { return nil }
            return Self(id: id, name: row["location_name"] as? String ?? "",
                        kind: row["location_kind"] as? String ?? "",
                        quantity: ((row["stock_qty"] ?? row["qty"]) as? NSNumber)?.intValue ?? 0)
        }
    }
}
