import CryptoKit
import ImageIO
import SwiftUI
import UIKit

enum ProductImageCacheKey {
    static func value(for url: URL) -> String {
        guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
            return url.absoluteString
        }
        let authKeys: Set<String> = ["token", "expires", "signature", "access_token"]
        components.queryItems = components.queryItems?.filter { !authKeys.contains($0.name.lowercased()) }
        if components.queryItems?.isEmpty == true { components.queryItems = nil }
        components.fragment = nil
        return components.url?.absoluteString ?? url.absoluteString
    }

    static func fileName(for url: URL) -> String {
        let digest = SHA256.hash(data: Data(value(for: url).utf8))
        return digest.map { String(format: "%02x", $0) }.joined() + ".img"
    }
}

actor ProductImageCache {
    static let shared = ProductImageCache()

    private let memory = NSCache<NSString, UIImage>()
    private let directory: URL
    private let session: URLSession
    private var downloads: [String: Task<Data?, Never>] = [:]

    init(directory: URL? = nil, session: URLSession = .shared) {
        self.session = session
        self.directory = directory ?? FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("product-images-v1", isDirectory: true)
        memory.countLimit = 160
        memory.totalCostLimit = 96 * 1024 * 1024
        try? FileManager.default.createDirectory(at: self.directory, withIntermediateDirectories: true)
    }

    func image(for url: URL, pixelSize: CGFloat) async -> UIImage? {
        // A list thumbnail must never satisfy a detail/zoom request.
        let resourceKey = ProductImageCacheKey.value(for: url)
        let key = "\(resourceKey)#pixels=\(Int(pixelSize.rounded(.up)))" as NSString
        let cached = memory.object(forKey: key)
        if let cached { return cached }

        guard let data = await originalData(for: url),
              let image = Self.downsample(data: data, pixelSize: pixelSize) else { return nil }
        store(image, for: key)
        return image
    }

    func originalData(for url: URL) async -> Data? {
        let resourceKey = ProductImageCacheKey.value(for: url)
        let fileURL = directory.appendingPathComponent(ProductImageCacheKey.fileName(for: url))
        if let data = try? Data(contentsOf: fileURL),
           CGImageSourceCreateWithData(data as CFData, nil) != nil {
            return data
        }

        let download: Task<Data?, Never>
        if let pending = downloads[resourceKey] {
            download = pending
        } else {
            download = Task { [session] in
                if url.isFileURL { return try? Data(contentsOf: url) }
                for attempt in 0..<3 {
                    var request = URLRequest(url: url, timeoutInterval: 25)
                    request.cachePolicy = attempt == 0 ? .returnCacheDataElseLoad : .reloadIgnoringLocalCacheData
                    do {
                        let (data, response) = try await session.data(for: request)
                        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
                        if status == 200 { return data }
                        guard status == 429 || (500...599).contains(status) else { return nil }
                    } catch {
                        if Task.isCancelled { return nil }
                    }
                    if attempt < 2 { try? await Task.sleep(for: .milliseconds(300 * (attempt + 1))) }
                }
                return nil
            }
            downloads[resourceKey] = download
        }
        let data = await download.value
        downloads[resourceKey] = nil
        guard let data, CGImageSourceCreateWithData(data as CFData, nil) != nil else { return nil }

        try? data.write(to: fileURL, options: .atomic)
        return data
    }

    func preserveOriginals(_ images: [Data], productID: String) -> [String] {
        images.enumerated().compactMap { index, data in
            let digest = SHA256.hash(data: Data("\(productID)-\(index)".utf8))
            let name = digest.map { String(format: "%02x", $0) }.joined()
            let url = directory.appendingPathComponent("original-\(name).jpg")
            do {
                try data.write(to: url, options: .atomic)
                return url.absoluteString
            } catch { return nil }
        }
    }

    private func store(_ image: UIImage, for key: NSString) {
        let cost = Int(image.size.width * image.size.height * image.scale * image.scale * 4)
        memory.setObject(image, forKey: key, cost: cost)
    }

    private static func downsample(data: Data, pixelSize: CGFloat) -> UIImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let cgImage = CGImageSourceCreateThumbnailAtIndex(
                source,
                0,
                [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceThumbnailMaxPixelSize: max(pixelSize, 120),
                    kCGImageSourceShouldCacheImmediately: true,
                ] as CFDictionary
              )
        else { return nil }
        return UIImage(cgImage: cgImage)
    }
}

struct CachedProductImage: View {
    let urlString: String
    var pixelSize: CGFloat = 240
    var contentMode: ContentMode = .fill
    var placeholderIcon = "photo"
    var fallbackData: Data? = nil
    var keepPreviousImageWhileLoading = false
    var fallbackURLString: String? = nil
    @State private var image: UIImage?
    @State private var loadedIdentity = ""
    @State private var failed = false
    @State private var loading = false
    @State private var retry = 0

    var body: some View {
        Group {
            if loadedIdentity == cacheIdentity || keepPreviousImageWhileLoading, let image {
                Image(uiImage: image)
                    .resizable()
                    .aspectRatio(contentMode: contentMode)
                    .accessibilityLabel("商品图片")
                    .accessibilityIdentifier("product-image-loaded")
            } else if let fallbackData, let original = UIImage(data: fallbackData) {
                Image(uiImage: original)
                    .resizable()
                    .aspectRatio(contentMode: contentMode)
            } else {
                ZStack {
                    BOColor.blueTint
                    Image(systemName: placeholderIcon)
                        .foregroundStyle(BOColor.navy.opacity(0.55))
                }
            }
        }
        .overlay(alignment: .bottom) {
            if failed {
                Button {
                    retry += 1
                } label: {
                    Label("图片加载失败，重试", systemImage: "arrow.clockwise")
                        .font(.caption2)
                        .padding(8)
                        .background(.regularMaterial, in: Capsule())
                }
                .buttonStyle(.plain)
                .padding(6)
            }
        }
        .overlay {
            if loading && image == nil && fallbackData == nil {
                ProgressView().tint(BOColor.navy)
            }
        }
        .task(id: "\(cacheIdentity)#retry=\(retry)") {
            let identity = cacheIdentity
            failed = false
            loading = !urlString.isEmpty
            guard let url = URL(string: urlString), !urlString.isEmpty else {
                loading = false
                image = nil
                loadedIdentity = identity
                return
            }
            var loaded = await ProductImageCache.shared.image(for: url, pixelSize: pixelSize)
            if loaded == nil, let fallbackURLString, let fallbackURL = URL(string: fallbackURLString), fallbackURL != url {
                loaded = await ProductImageCache.shared.image(for: fallbackURL, pixelSize: pixelSize)
            }
            guard !Task.isCancelled else { return }
            loading = false
            failed = loaded == nil
            if loaded != nil || !keepPreviousImageWhileLoading {
                image = loaded
                loadedIdentity = identity
            }
        }
    }

    private var cacheIdentity: String {
        "\(urlString)#\(pixelSize)"
    }
}

struct ProductsView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.scenePhase) private var scenePhase
    @State private var showSort = false
    @State private var isVisible = false
    @State private var searchText = ""
    @State private var selectingCards = false
    @State private var cardSelection: [Product] = []
    @State private var showCardPrint = false
    var switchMode: (() -> Void)? = nil

    private var refreshQuery: ProductListQuery? {
        isVisible && scenePhase == .active && model.selectedTab == 1 && model.secondTabMode == .products
            ? model.currentProductQuery : nil
    }

    var body: some View {
        VStack(spacing: 0) {
            ProductHeader()
            HStack {
                Button(selectingCards ? "取消选择" : "多选生成商品卡") {
                    selectingCards.toggle(); cardSelection = []
                }
                Spacer()
                if selectingCards {
                    Button("生成卡片（\(cardSelection.count)）") { showCardPrint = true }
                        .disabled(cardSelection.isEmpty)
                }
            }.font(.system(size: 13, weight: .semibold)).foregroundStyle(BOColor.red).padding(.horizontal, 20).padding(.vertical, 8)
            ScrollView {
                LazyVStack(spacing: 12) {
                    if !model.productsMatchCurrentQuery || (model.productsLoading && model.products.isEmpty) {
                        ProgressView("正在同步商品")
                            .tint(BOColor.red)
                            .padding(.top, 50)
                    } else if model.products.isEmpty && !model.productsError.isEmpty {
                        BOEmptyState(title: "商品读取失败", detail: model.productsError)
                        Button("重新加载") { Task { await model.loadProducts() } }
                            .foregroundStyle(BOColor.navy)
                    } else if model.products.isEmpty {
                        BOEmptyState(title: "暂无商品", detail: "当前库位和状态下没有商品")
                        if model.listingStatus != .all {
                            Button("查看全部状态") { model.listingStatus = .all }
                                .foregroundStyle(BOColor.navy)
                                .accessibilityIdentifier("product-empty-all-status")
                        }
                    } else if selectingCards {
                        ForEach(model.products) { product in
                            selectableCardRow(product)
                        }
                    } else if model.productType == .standard {
                        ForEach(model.standardProductGroups) { group in
                            NavigationLink(value: group) {
                                StandardProductGroupRow(group: group)
                            }
                            .buttonStyle(.plain)
                        }
                    } else {
                        ForEach(model.products) { product in
                            NavigationLink(value: product) {
                                ProductRow(product: product)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .id(selectingCards)
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 24)
            }
            .refreshable { await model.loadProducts() }
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { searchText = model.productQuery; isVisible = true }
        .onDisappear { isVisible = false }
        .onChange(of: model.productQuery) { _, value in searchText = value }
        .task(id: isVisible && scenePhase == .active ? searchText : nil) {
            guard isVisible, scenePhase == .active, searchText != model.productQuery else { return }
            await model.debounceProductSearch(searchText)
        }
        .task(id: refreshQuery) {
            if let query = refreshQuery { await model.watchProductImages(query: query) }
        }
        .navigationDestination(isPresented: $showCardPrint) { A4PrintView(products: cardSelection) }
        .onChange(of: model.selectedLocation?.id) { _, _ in cardSelection = []; showCardPrint = false; selectingCards = false }
        .onChange(of: model.user.id) { _, _ in cardSelection = []; showCardPrint = false; selectingCards = false }
        .onChange(of: model.productViewScope) { _, _ in cardSelection = []; showCardPrint = false }
        .navigationDestination(for: Product.self) { product in
            ProductDetailView(product: product)
        }
        .navigationDestination(for: StandardProductGroup.self) { group in
            StandardProductGroupDetailView(group: group)
        }
        .confirmationDialog("商品排序", isPresented: $showSort) {
            Button("最近更新") { selectSort("updated_desc") }
            Button("最新创建") { selectSort("created_desc") }
            Button("价格从高到低") { selectSort("price_desc") }
            Button("价格从低到高") { selectSort("price_asc") }
            Button("库存从高到低") { selectSort("stock_desc") }
            Button("取消", role: .cancel) {}
        }
    }

    private func toggleCard(_ product: Product) {
        if let index = cardSelection.firstIndex(where: { $0.id == product.id }) {
            cardSelection.remove(at: index)
        } else { cardSelection.append(product) }
    }
    private func selectableCardRow(_ product: Product) -> some View {
        let selected = cardSelection.contains(where: { $0.id == product.id })
        return Button { toggleCard(product) } label: {
            HStack {
                Image(systemName: selected ? "checkmark.circle.fill" : "circle").foregroundStyle(BOColor.red)
                ProductRow(product: product)
            }
        }.buttonStyle(.plain).accessibilityIdentifier("card-select-" + product.id)
    }

    private func selectSort(_ value: String) {
        model.productSort = value
    }

    @ViewBuilder
    private func ProductHeader() -> some View {
        VStack(spacing: 12) {
            HStack(alignment: .center, spacing: 10) {
                HStack(spacing: 6) {
                    Text("商品")
                        .font(BORootHeader.titleFont)
                        .fixedSize()
                    if let switchMode {
                        SecondTabTitleSwitch(mode: .products, action: switchMode)
                    }
                }
                Spacer(minLength: 0)
                ForEach(ProductType.allCases) { type in
                    Button {
                        model.productType = type
                    } label: {
                        VStack(spacing: 2) {
                            Text(type.title)
                                .font(.system(size: 12, weight: .bold, design: .rounded))
                            Text("\(count(type))")
                                .font(.system(size: 10, design: .rounded))
                        }
                        .foregroundStyle(model.productType == type ? BOColor.red : BOColor.secondary)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 6)
                        .background(model.productType == type ? BOColor.redTint : Color.clear)
                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                }
            }

            if model.canShowHQTools {
                HStack(spacing: 6) {
                    ScopeButton("当前总部", scope: .currentLocation)
                    ScopeButton("全部门店（含总部）", scope: .all)
                }
                .accessibilityIdentifier("product-location-scope")
            } else if let location = model.selectedLocation {
                Label("当前库位：\(location.name)", systemImage: "mappin.and.ellipse")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(BOColor.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundStyle(BOColor.secondary)
                TextField("搜索商品名称 / 条码 / SKU", text: $searchText)
                    .font(.system(size: 14, design: .rounded))
                    .submitLabel(.search)
                    .accessibilityIdentifier("product-search")
                    .onSubmit {
                        if model.productQuery != searchText { model.productQuery = searchText }
                        else { Task { await model.loadProducts() } }
                    }
                if !searchText.isEmpty {
                    Button {
                        searchText = ""
                        model.productQuery = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(BOColor.secondary)
                    }
                }
            }
            .padding(.horizontal, 14)
            .frame(height: 46)
            .background(BOColor.field)
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))

            HStack(spacing: 7) {
                ForEach(ListingStatus.allCases) { status in
                    Button {
                        model.listingStatus = status
                    } label: {
                        Text(status.title)
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(model.listingStatus == status ? .white : BOColor.secondary)
                            .frame(maxWidth: .infinity)
                            .frame(height: 34)
                            .background(model.listingStatus == status ? BOColor.navy : BOColor.field)
                            .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                    }
                    .accessibilityIdentifier("product-status-\(status.rawValue)")
                }
            }

            if model.productsMatchCurrentQuery && !model.products.isEmpty {
                if model.productsLoading {
                    ProgressView("正在更新商品状态")
                        .font(.caption)
                } else if !model.productsError.isEmpty {
                    Text("更新失败，当前为上次结果：\(model.productsError)")
                        .font(.caption)
                        .foregroundStyle(BOColor.orange)
                }
            }

            HStack {
                Button { showSort = true } label: {
                    Label(sortTitle, systemImage: "arrow.up.arrow.down")
                }
                FilterCapsule(title: "分类：全部")
                Button {
                    model.productOnlyFankuang.toggle()
                } label: {
                    Text("仅翻筐乐")
                        .padding(.horizontal, 10)
                        .frame(height: 34)
                        .foregroundStyle(model.productOnlyFankuang ? .white : BOColor.ink)
                        .background(model.productOnlyFankuang ? BOColor.navy : Color.white, in: Capsule())
                        .overlay(Capsule().stroke(BOColor.line))
                }
                .accessibilityIdentifier("product-fankuang-filter")
                .accessibilityValue(model.productOnlyFankuang ? "已开启" : "未开启")
                Spacer()
                Text(model.productType == .standard
                     ? "\(model.standardProductGroups.count) 组"
                     : "\(model.products.count) 件")
                    .font(.system(size: 12, design: .rounded))
                    .foregroundStyle(BOColor.secondary)
            }
            .font(.system(size: 12, weight: .semibold, design: .rounded))
            .foregroundStyle(BOColor.ink)
        }
        .padding(.horizontal, BORootHeader.horizontalInset)
        .padding(.top, BORootHeader.topInset)
        .padding(.bottom, 10)
        .background(Color.white)
    }

    private func ScopeButton(_ title: String, scope: ProductViewScope) -> some View {
        Button { model.selectProductScope(scope) } label: {
            Text(title)
                .font(.system(size: 12, weight: .semibold))
                .frame(maxWidth: .infinity)
                .frame(height: 32)
                .foregroundStyle(model.productViewScope == scope ? .white : BOColor.secondary)
                .background(model.productViewScope == scope ? BOColor.navy : BOColor.field)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
        }
        .accessibilityAddTraits(model.productViewScope == scope ? .isSelected : [])
    }

    private var sortTitle: String {
        switch model.productSort {
        case "created_desc": "最新创建"
        case "price_desc": "价格降序"
        case "price_asc": "价格升序"
        case "stock_desc": "库存降序"
        default: "最近更新"
        }
    }

    private func count(_ type: ProductType) -> Int {
        switch type {
        case .custom: model.productCounts.custom
        case .bundle: model.productCounts.bundle
        case .standard: model.productCounts.standard
        }
    }
}

private struct StandardProductGroupRow: View {
    let group: StandardProductGroup

    var body: some View {
        HStack(spacing: 14) {
            CachedProductImage(
                urlString: group.imageURL,
                placeholderIcon: "square.grid.2x2"
            )
            .frame(width: 74, height: 74)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

            VStack(alignment: .leading, spacing: 6) {
                Text(group.name)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .lineLimit(1)
                Text("\(group.tiers.count) 个价格档")
                    .font(.system(size: 12, design: .rounded))
                    .foregroundStyle(BOColor.secondary)
                Text(priceRange)
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(BOColor.red)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(BOColor.secondary.opacity(0.65))
        }
        .padding(12)
        .boCard()
    }

    private var priceRange: String {
        let minimum = money(group.minimumPrice)
        let maximum = money(group.maximumPrice)
        return minimum == maximum ? "¥\(minimum)" : "¥\(minimum) – ¥\(maximum)"
    }
}

private struct StandardProductGroupDetailView: View {
    let group: StandardProductGroup

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 14) {
                    CachedProductImage(
                        urlString: group.imageURL,
                        placeholderIcon: "square.grid.2x2"
                    )
                    .frame(width: 84, height: 84)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    VStack(alignment: .leading, spacing: 6) {
                        Text(group.name)
                            .font(.system(size: 22, weight: .heavy, design: .rounded))
                        Text("价格组 · \(group.tiers.count) 个档位")
                            .font(.system(size: 13, design: .rounded))
                            .foregroundStyle(BOColor.secondary)
                    }
                }
                .padding(14)
                .boCard()

                Text("选择价格档")
                    .font(.system(size: 16, weight: .bold, design: .rounded))

                ForEach(group.tiers) { tier in
                    NavigationLink(value: tier) {
                        HStack {
                            Text("¥\(money(tier.price))")
                                .font(.system(size: 18, weight: .heavy, design: .rounded))
                                .foregroundStyle(BOColor.red)
                            Spacer()
                            Text(tier.isUnlimitedStock ? "标准库存" : "库存 \(tier.stockQty)")
                                .font(.system(size: 12, design: .rounded))
                                .foregroundStyle(BOColor.secondary)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundStyle(BOColor.secondary.opacity(0.6))
                        }
                        .padding(.horizontal, 16)
                        .frame(height: 58)
                        .boCard(radius: 15)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(20)
        }
        .navigationTitle(group.name)
        .toolbar(.visible, for: .navigationBar)
        .navigationBarTitleDisplayMode(.inline)
    }
}

private func money(_ value: Double) -> String {
    formattedProductPrice(value)
}

private struct FilterCapsule: View {
    let title: String
    var body: some View {
        Text(title)
            .padding(.horizontal, 12)
            .frame(height: 34)
            .background(Color.white)
            .clipShape(Capsule())
            .overlay(Capsule().stroke(BOColor.line))
    }
}

private struct ProductRow: View {
    let product: Product

    var body: some View {
        HStack(spacing: 14) {
            CachedProductImage(urlString: product.imageURL)
            .frame(width: 74, height: 74)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

            VStack(alignment: .leading, spacing: 6) {
                Text(product.name.isEmpty ? "未命名商品" : product.name)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .lineLimit(1)
                Text(product.skuCode)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundStyle(BOColor.secondary)
                    .lineLimit(1)
                HStack(spacing: 5) {
                    BOStatusBadge(text: product.statusLabel, color: statusColor(product.listingStatus))
                    if product.inFankuang {
                        BOStatusBadge(text: "翻筐乐", color: BOColor.red)
                    }
                    if ProductImageProcessingPresentation.title(for: product.imageProcessingStatus) != nil {
                        BOStatusBadge(text: "主图修图中", color: BOColor.navy)
                    }
                    if !product.conditionGrade.isEmpty {
                        BOStatusBadge(text: "成色 \(product.conditionGrade)", color: BOColor.navy)
                    }
                }
                Text(locationSummary)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(BOColor.navy)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 10) {
                Text("¥\(formattedProductPrice(product.price))")
                    .font(.system(size: 18, weight: .heavy, design: .rounded))
                    .foregroundStyle(BOColor.red)
                Text(product.isUnlimitedStock ? "库存不限" : "库存 \(product.stockQty)")
                    .font(.system(size: 11, design: .rounded))
                    .foregroundStyle(BOColor.secondary)
            }
        }
        .padding(12)
        .boCard()
    }

    private func statusColor(_ status: String) -> Color {
        switch status {
        case "sold_out": BOColor.orange
        case "in_warehouse": BOColor.navy
        default: BOColor.green
        }
    }

    private var locationSummary: String {
        let stocks = product.locationStocks ?? []
        return stocks.isEmpty ? "未分配库位" : stocks.map { "\($0.displayName) · \($0.quantity)" }.joined(separator: "　")
    }
}

struct ProductDetailView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    let product: Product
    @State private var detail: Product
    @State private var showRestock = false
    @State private var restockQuantity = 1
    @State private var showingImagePreview = false
    @State private var selectedImageIndex = 0
    @State private var showingEditor = false
    @State private var confirmingDelete = false
    @State private var deleting = false
    @State private var detailLoaded = false
    @State private var detailRefreshToken = UUID()
    @State private var detailRequestID = UUID()
    @State private var deleteOperationID = "ios-delete-\(UUID().uuidString.lowercased())"

    init(product: Product) {
        self.product = product
        _detail = State(initialValue: product)
    }

    private var capabilities: ProductCapabilities {
        ProductCapabilities.menu(user: model.user, product: detail,
                                 query: model.currentProductQuery, serverConfirmed: detailLoaded)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                TabView {
                    ForEach(Array(displayImages.enumerated()), id: \.offset) { index, imageURL in
                        CachedProductImage(
                            urlString: imageURL,
                            pixelSize: 1200,
                            contentMode: .fit,
                            keepPreviousImageWhileLoading: true
                        )
                        .background(BOColor.field)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            selectedImageIndex = index
                            showingImagePreview = true
                        }
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: displayImages.count > 1 ? .automatic : .never))
                .aspectRatio(1, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))

                if let imageStatusTitle = ProductImageProcessingPresentation.title(
                    for: detail.imageProcessingStatus
                ) {
                    Label(imageStatusTitle, systemImage: "wand.and.stars")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(BOColor.navy)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(BOColor.field)
                        .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                }

                HStack(alignment: .firstTextBaseline) {
                    Text(detail.name)
                        .font(.system(size: 22, weight: .heavy, design: .rounded))
                    Spacer()
                    Text("¥\(formattedProductPrice(detail.price))")
                        .font(.system(size: 26, weight: .heavy, design: .rounded))
                        .foregroundStyle(BOColor.red)
                }

                HStack {
                    BOStatusBadge(text: detail.statusLabel, color: BOColor.green)
                    if !detail.conditionGrade.isEmpty {
                        BOStatusBadge(text: "成色 \(detail.conditionGrade)", color: BOColor.navy)
                    }
                }

                LazyVGrid(columns: [.init(.flexible()), .init(.flexible())], spacing: 12) {
                    DetailField(title: "商品编码", value: detail.skuCode)
                    DetailField(title: "商品条码", value: detail.barcode)
                    DetailField(title: "商品分类", value: detail.category)
                    DetailField(title: "当前库存", value: detail.isUnlimitedStock ? "不限" : "\(detail.stockQty) 件")
                    DetailField(title: "品牌", value: detail.brand)
                    DetailField(title: "年代", value: detail.era)
                    DetailField(title: "IP / 系列", value: detail.ipName)
                }

                if !detail.tags.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("商品标签")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(detail.tags, id: \.self) { tag in
                                    Text(tag)
                                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                                        .padding(.horizontal, 10)
                                        .frame(height: 30)
                                        .background(BOColor.field)
                                        .clipShape(Capsule())
                                }
                            }
                        }
                    }
                    .padding(15)
                    .boCard()
                }

                if !detail.description.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("价签简介")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                        Text(detail.description)
                            .font(.system(size: 13, design: .rounded))
                            .foregroundStyle(BOColor.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(15)
                    .boCard()
                }

                if ProductContentEligibility.canEdit(productType: detail.productType, permission: capabilities.canEdit),
                   let query = model.currentProductQuery {
                    NavigationLink {
                        ProductContentEditorView(product: detail, query: query)
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 6) {
                                Label("图文详情", systemImage: "doc.richtext")
                                    .font(.system(size: 15, weight: .bold, design: .rounded))
                                Text("编辑商城内容 · 与价签简介独立保存")
                                    .font(.caption).foregroundStyle(BOColor.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .foregroundStyle(BOColor.navy)
                        .padding(15)
                        .boCard()
                    }
                    .disabled(!detailLoaded)
                    .accessibilityIdentifier("product-content-detail-entry")
                }

                NavigationLink {
                    A4PrintView(products: [detail])
                } label: {
                    Label("生成商品卡 · 60 × 90 mm", systemImage: "doc.richtext")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(BOColor.red).frame(maxWidth: .infinity).frame(height: 50)
                        .background(BOColor.redTint).clipShape(RoundedRectangle(cornerRadius: 15))
                }.disabled(!detailLoaded).accessibilityIdentifier("product-card-entry")

                NavigationLink {
                    PrinterCenterView(product: detail)
                } label: {
                    Label("打印商品标签", systemImage: "printer.fill")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(BOColor.navy)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(BOColor.blueTint)
                        .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                }

                if detail.listingStatus == "sold_out" || detail.canRestock {
                    Button {
                        showRestock = true
                    } label: {
                        Label("补货入库", systemImage: "plus.circle.fill")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundStyle(BOColor.navy)
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(BOColor.blueTint)
                            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    }
                }

                BOPrimaryButton(title: detail.listingStatus == "selling" ? "转入仓库中" : "设为销售中") {
                    model.selectedProduct = detail
                    model.toggleSelectedProductVisibility()
                }
            }
            .padding(20)
        }
        .refreshable {
            await loadDetail(poll: false)
            detailRefreshToken = UUID()
        }
        .navigationTitle("商品详情")
        .toolbar(.visible, for: .navigationBar)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        if !capabilities.canEdit && !capabilities.canDelete {
                            Text("当前账号无编辑或删除权限")
                        }
                        if capabilities.canEdit {
                            Button(detailLoaded ? "编辑商品" : "编辑商品（读取详情中）", systemImage: "pencil") { showingEditor = true }
                                .disabled(!detailLoaded)
                        }
                        if capabilities.canDelete {
                            Button("删除商品", systemImage: "trash", role: .destructive) { confirmingDelete = true }
                        }
                    } label: {
                        if deleting { ProgressView() }
                        else {
                            Image(systemName: "ellipsis.circle")
                                .foregroundStyle(Color.primary)
                                .accessibilityLabel("更多商品操作")
                        }
                    }
                    .disabled(deleting)
            }
        }
        .confirmationDialog("删除商品？", isPresented: $confirmingDelete, titleVisibility: .visible) {
            Button("确认删除", role: .destructive) { deleteProduct() }
            Button("取消", role: .cancel) {}
        } message: {
            Text("\(detail.name)\n条码：\(detail.barcode)\n将从商品库和商城移除，并清退该商品所有库位的剩余库存、提交关联门店下架。历史订单及库存流水保留。未完成的订单或调拨需先处理。")
        }
        .sheet(isPresented: $showingEditor) {
            if let query = model.currentProductQuery {
                ProductEditView(product: detail, query: query) { updated in
                    model.productDidMutate(id: updated.id, updated: updated)
                    guard model.currentProductQuery == query else { return }
                    detail = updated
                    detailRefreshToken = UUID()
                }
            }
        }
        .task(id: "\(scenePhase == .active && model.selectedTab == 1 && model.secondTabMode == .products && !showingEditor)-\(detailRefreshToken)") {
            guard scenePhase == .active, model.selectedTab == 1, model.secondTabMode == .products, !showingEditor else { return }
            await loadDetail()
        }
        .onChange(of: model.currentProductQuery) { old, new in
            if old != new { dismiss() }
        }
        .fullScreenCover(isPresented: $showingImagePreview) {
            ProductImagePreview(
                urls: displayImages,
                initialIndex: selectedImageIndex,
                product: capabilities.canEdit && detailLoaded ? detail : nil,
                query: model.currentProductQuery,
                onSaved: { updated in
                    model.productDidMutate(id: updated.id, updated: updated)
                    detail = updated; detailRefreshToken = UUID()
                }
            )
        }
        .sheet(isPresented: $showRestock) {
            NavigationStack {
                Form {
                    Stepper("补货数量：\(restockQuantity)", value: $restockQuantity, in: 1...99)
                    Text("补货成功后会生成对应数量的标签，可在打印中心打印。")
                        .font(.system(size: 12, design: .rounded))
                        .foregroundStyle(BOColor.secondary)
                }
                .navigationTitle("补货入库")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("取消") { showRestock = false }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("确认") { restock() }.fontWeight(.bold)
                    }
                }
            }
            .presentationDetents([.medium])
        }
    }

    private var displayImages: [String] {
        let values = detail.images.isEmpty ? [detail.imageURL] : detail.images
        return values.filter { !$0.isEmpty }
    }

    private func loadDetail(poll: Bool = true) async {
        guard let query = model.currentProductQuery else { dismiss(); return }
        let requestID = UUID()
        detailRequestID = requestID
        var hasLoaded = false
        var networkFailures = 0
        while !Task.isCancelled, detailRequestID == requestID, model.currentProductQuery == query {
            do {
                let loaded = try await APIClient.shared.productDetail(id: product.id, query: query)
                guard !Task.isCancelled, detailRequestID == requestID, model.currentProductQuery == query else { return }
                detail = loaded
                model.productImagesDidRefresh(loaded, query: query)
                detailLoaded = true
                hasLoaded = true
                networkFailures = 0
                if !poll || !ProductImageProcessingPresentation.shouldPoll(loaded.imageProcessingStatus) { return }
                try await Task.sleep(for: .seconds(loaded.imageProcessingStatus == "partial_failed" ? 10 : 3))
            } catch {
                guard !Task.isCancelled, detailRequestID == requestID, model.currentProductQuery == query else { return }
                if poll, hasLoaded, error is URLError {
                    networkFailures += 1
                    if networkFailures <= 3 {
                        try? await Task.sleep(for: .seconds(3 * networkFailures))
                        continue
                    }
                    model.errorMessage = "图片状态刷新失败，请稍后重新进入商品查看；已加载的图片仍可浏览。"
                    return
                }
                model.errorMessage = error.localizedDescription
                return
            }
        }
    }

    private func restock() {
        guard let query = model.currentProductQuery else { return }
        let productID = detail.id
        Task {
            model.busy = true
            defer { model.busy = false }
            do {
                _ = try await APIClient.shared.restockProduct(
                    id: productID,
                    locationID: query.locationID,
                    quantity: restockQuantity,
                    printLabels: true,
                    templateID: nil
                )
                guard model.currentProductQuery == query else { return }
                showRestock = false
                model.toastMessage = "补货成功，已生成 \(restockQuantity) 张标签"
                do {
                    let updated = try await APIClient.shared.productDetail(id: productID, query: query)
                    guard model.currentProductQuery == query else { return }
                    detail = updated
                } catch {
                    guard model.currentProductQuery == query else { return }
                    model.errorMessage = "补货已完成，详情刷新失败，请返回商品列表刷新，不要重复补货。"
                }
                await model.loadProducts()
            } catch {
                guard model.currentProductQuery == query else { return }
                model.errorMessage = error.localizedDescription
            }
        }
    }

    private func deleteProduct() {
        guard !deleting, capabilities.canDelete, let query = model.currentProductQuery else { return }
        let id = detail.id
        deleting = true
        Task {
            defer { deleting = false }
            do {
                try await APIClient.shared.deleteProduct(id: id, locationID: query.locationID, operationID: deleteOperationID)
                model.productDidMutate(id: id, updated: nil)
                guard model.currentProductQuery == query else { return }
                model.toastMessage = "商品已删除"
                dismiss()
            } catch {
                guard model.currentProductQuery == query else { return }
                model.errorMessage = error.localizedDescription
            }
        }
    }
}

struct ProductEditView: View {
    @Environment(\.dismiss) private var dismiss
    let product: Product
    let query: ProductListQuery
    let onSaved: (Product) -> Void
    @State private var input: ProductEditInput
    @State private var saving = false
    @State private var pendingBody: [String: Any]?
    @State private var errorMessage = ""
    @State private var images: [ProductEditableImage]
    @State private var imagesChanged = false
    @State private var importingImages = false
    @State private var uploadProgress = ""
    @State private var confirmingCancel = false

    init(product: Product, query: ProductListQuery, onSaved: @escaping (Product) -> Void) {
        self.product = product
        self.query = query
        self.onSaved = onSaved
        _input = State(initialValue: ProductEditInput(name: product.name,
            price: String(format: "%.2f", product.price), grade: product.conditionGrade,
            description: product.description, fankuangOverride: product.fankuangOverride))
        _images = State(initialValue: (product.imageReferences ?? []).map(ProductEditableImage.init(reference:)))
    }

    var body: some View {
        NavigationStack {
            Form {
                if product.imageReferences != nil {
                    ProductEditImagesSection(images: $images, importing: $importingImages, errorMessage: $errorMessage) {
                        imagesChanged = true
                    }
                    .disabled(saving || pendingBody != nil)
                } else {
                    Section("商品图片") {
                        Text("暂未取得图片原始路径，请返回后重新打开商品详情再编辑图片。")
                            .foregroundStyle(BOColor.secondary)
                    }
                }
                if !uploadProgress.isEmpty {
                    Section { HStack { ProgressView(); Text(uploadProgress) } }
                }
                Section("商品资料") {
                    TextField("商品名称", text: $input.name)
                    HStack {
                        Text("售价（元）")
                        TextField("0.00", text: $input.price).keyboardType(.decimalPad).multilineTextAlignment(.trailing)
                    }
                    if product.productType == "custom" {
                        Toggle("加入翻筐乐", isOn: Binding(
                            get: { input.inFankuang },
                            set: { input.fankuangOverride = $0 }
                        ))
                        .tint(BOColor.red)
                        .accessibilityIdentifier("product-fankuang-toggle")
                    }
                    Picker("成色", selection: $input.grade) {
                        ForEach(ConditionGrade.allCases) { grade in Text(grade.title).tag(grade.rawValue) }
                    }
                }
                .disabled(saving || pendingBody != nil)
                Section {
                    TextField("用于商品价签的短简介", text: $input.description, axis: .vertical).lineLimit(3...6)
                } header: {
                    Text("价签简介")
                } footer: {
                    Text("建议约 20–40 字；图文详情不会写入价签。")
                }
                .disabled(saving || pendingBody != nil)
                if ProductContentEligibility.canEdit(productType: product.productType, permission: product.allowsEditing) {
                    Section {
                        NavigationLink {
                            ProductContentEditorView(product: product, query: query)
                        } label: {
                            Label("图文详情", systemImage: "doc.richtext")
                        }
                        .accessibilityIdentifier("product-content-edit-entry")
                    } footer: {
                        Text("图文详情独立保存。AI 使用已保存的商品事实，当前未保存的基础资料不参与生成。")
                    }
                    .disabled(saving || importingImages || pendingBody != nil)
                }
                Section {
                    LabeledContent("条码", value: product.barcode)
                    LabeledContent("编码", value: product.skuCode)
                } footer: {
                    Text("修改不会改变条码或库存。图片更新到 ERP 与线上商城。价格会在后台同步到已关联的有赞门店；图片、名称、成色和介绍的有赞同步暂未支持。")
                }
                if pendingBody != nil && !saving {
                    Section {
                        Text("尚未确认保存结果。再次保存会重试同一请求，不会重复建品。")
                            .foregroundStyle(BOColor.secondary)
                    }
                }
            }
            .navigationTitle("编辑商品")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { confirmingCancel = true }.disabled(saving || importingImages)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button { save() } label: {
                        if saving { ProgressView() }
                        else { Text(pendingBody == nil ? "保存" : "重试保存").fontWeight(.semibold) }
                    }
                    .disabled(saving || importingImages)
                }
            }
            .tint(BOColor.red)
            .interactiveDismissDisabled(true)
            .confirmationDialog("放弃本次编辑？", isPresented: $confirmingCancel, titleVisibility: .visible) {
                Button("退出编辑", role: .destructive) { dismiss() }
                Button("继续编辑", role: .cancel) {}
            } message: {
                Text(pendingBody == nil ? "未保存的图片和文字修改不会生效。" : "保存结果尚未确认，退出后请重新打开商品详情核对。")
            }
            .alert("无法保存", isPresented: Binding(get: { !errorMessage.isEmpty }, set: { if !$0 { errorMessage = "" } })) {
                Button("知道了", role: .cancel) {}
            } message: { Text(errorMessage) }
        }
    }

    private func save() {
        guard !saving, !importingImages else { return }
        saving = true
        Task {
            defer { saving = false; uploadProgress = "" }
            do {
                if pendingBody == nil {
                    guard product.allowsEditing, let version = product.updatedAt else { throw APIError.message("请重新打开商品详情获取编辑权限") }
                    var body = try input.fields()
                    if imagesChanged {
                        for index in images.indices where images[index].storagePath == nil {
                            guard let data = images[index].data else { throw APIError.message("照片无法读取，请重新选择") }
                            uploadProgress = "上传图片 \(index + 1)/\(images.count)…"
                            let path = try await APIClient.shared.uploadImage(data, bucket: "sku-listing")
                            images[index].storagePath = "sku-listing/\(path)"
                        }
                        body["image_paths"] = try ProductEditableImage.paths(images)
                    }
                    body["location_id"] = query.locationID
                    body["expected_updated_at"] = version
                    body["client_op_id"] = "ios-edit-\(UUID().uuidString.lowercased())"
                    pendingBody = body
                }
                guard let body = pendingBody else { return }
                uploadProgress = "保存商品…"
                try await APIClient.shared.updateProduct(id: product.id, body: body)
                var updated = product
                updated.name = body["name"] as? String ?? product.name
                updated.price = (body["price_tier"] as? NSNumber)?.doubleValue ?? product.price
                updated.conditionGrade = body["condition_grade"] as? String ?? product.conditionGrade
                updated.description = body["description"] as? String ?? product.description
                updated.fankuangOverride = body["fankuang_override"] as? Bool
                if let paths = body["image_paths"] as? [String] {
                    updated.images = images.map(\.url)
                    updated.imageURL = updated.images.first ?? ""
                    updated.imageReferences = zip(paths, updated.images).map { ProductImageReference(storagePath: $0, url: $1) }
                }
                updated.updatedAt = nil
                onSaved(updated)
                dismiss()
            } catch {
                if case APIError.productMutationRejected = error { pendingBody = nil }
                errorMessage = error.localizedDescription
            }
        }
    }
}

struct ProductImagePreview: View {
    @Environment(\.dismiss) private var dismiss
    let urls: [String]
    var product: Product?
    var query: ProductListQuery?
    var onSaved: ((Product) -> Void)?
    @State private var selectedIndex: Int
    @State private var retouching: ProductImageReference?

    init(urls: [String], initialIndex: Int, product: Product? = nil,
         query: ProductListQuery? = nil, onSaved: ((Product) -> Void)? = nil) {
        self.urls = urls
        self.product = product; self.query = query; self.onSaved = onSaved
        _selectedIndex = State(initialValue: min(max(initialIndex, 0), max(urls.count - 1, 0)))
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            TabView(selection: $selectedIndex) {
                ForEach(Array(urls.enumerated()), id: \.offset) { index, url in
                    ZoomableProductImage(urlString: url)
                        .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))

            VStack {
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 40, height: 40)
                            .background(.black.opacity(0.55))
                            .clipShape(Circle())
                    }
                    .accessibilityLabel("关闭大图")
                    Spacer()
                    Text("\(selectedIndex + 1) / \(max(urls.count, 1))")
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 13)
                        .frame(height: 34)
                        .background(.black.opacity(0.55))
                        .clipShape(Capsule())
                }
                Spacer()
                if let refs = product?.imageReferences, refs.indices.contains(selectedIndex), query != nil {
                    Button {
                        retouching = refs[selectedIndex]
                    } label: {
                        Label("微调图片 / 一键重修", systemImage: "wand.and.stars")
                            .font(.subheadline.bold()).padding(14).frame(maxWidth: .infinity)
                            .foregroundStyle(.white).background(BOColor.red)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }.accessibilityIdentifier("product-image-retouch")
                }
            }
            .padding(16)
        }
        .sheet(isPresented: Binding(get: { retouching != nil }, set: { if !$0 { retouching = nil } })) {
            if let reference = retouching, let product, let query {
                ProductImageRetouchView(product: product, reference: reference, query: query) { updated in
                    onSaved?(updated); retouching = nil; dismiss()
                }
            }
        }
    }
}

private struct ZoomableProductImage: View {
    let urlString: String

    var body: some View {
        ZoomablePhotoContainer(content: CachedProductImage(
            urlString: urlString,
            pixelSize: 2400,
            contentMode: .fit
        ))
        .modifier(ProductPhotoSaveMenu(urlString: urlString))
    }
}

private struct DetailField: View {
    let title: String
    let value: String
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title)
                .font(.system(size: 11, design: .rounded))
                .foregroundStyle(BOColor.secondary)
            Text(value.isEmpty ? "—" : value)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity, minHeight: 62, alignment: .leading)
        .padding(12)
        .background(BOColor.field)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
