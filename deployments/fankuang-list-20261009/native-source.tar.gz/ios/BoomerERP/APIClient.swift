import Foundation
import UIKit
import OSLog

struct BootstrapPayload {
    let user: ERPUser
    let locations: [Location]
    let selectedLocation: Location?
}

struct RecognitionPayload {
    let name: String
    let category: String
    let categoryCode: String
    let brand: String
    let ipName: String
    let ipMatchStatus: String
    let ipSuggestions: [IPRecognitionSuggestion]
    let tags: [String]
    let facetCodes: [String]
    let era: String
    let conditionGrade: String
    let description: String
    let suggestedPrice: Double?
    let confidence: Double?
    let warning: String
    let requestID: String
    let classificationStatus: String
    var brandID: String = ""
    var brandMatchStatus: String = "empty"
    var brandSuggestions: [IPRecognitionSuggestion] = []
}

enum RecognitionEraDisplay {
    static func normalized(_ raw: String) -> String {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let key = text.lowercased()
        switch key {
        case "heisei", "heisei period", "heisei era", "era_heisei": return "平成（1989-2019年）"
        case "showa", "showa period", "showa era", "era_showa": return "昭和"
        case "unknown", "unspecified", "n/a", "null", "vintage": return ""
        default: break
        }
        if key.range(of: #"^[a-z][a-z0-9]*(?:_[a-z0-9]+)+$"#, options: .regularExpression) != nil {
            return ""
        }
        // Translate names only; never infer a production year from a period or copyright mark.
        return text
            .replacingOccurrences(of: #"\b(?:era_)?heisei(?: (?:period|era))?\b"#, with: "平成", options: [.regularExpression, .caseInsensitive])
            .replacingOccurrences(of: #"\b(?:era_)?showa(?: (?:period|era))?\b"#, with: "昭和", options: [.regularExpression, .caseInsensitive])
            .replacingOccurrences(of: #"\bera_[a-z0-9_]+\b"#, with: "", options: [.regularExpression, .caseInsensitive])
            .replacingOccurrences(of: #"^((?:18|19|20)\d0)s$"#, with: "$1年代", options: [.regularExpression, .caseInsensitive])
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

struct IPRecognitionSuggestion: Codable, Identifiable, Equatable {
    let id: String
    let name: String
    let confidence: Double
}

enum APIError: LocalizedError {
    case message(String)
    case authenticationExpired(String)
    case listingRejected(String)
    case productMutationRejected(code: String, message: String)

    var errorDescription: String? {
        switch self {
        case .message(let message): message
        case .authenticationExpired(let message): message
        case .listingRejected(let message): message
        case .productMutationRejected(_, let message): message
        }
    }
}

struct LocationAccessError: LocalizedError {
    var errorDescription: String? { "当前账号的库位权限已变更，请重新选择可访问库位" }
}

enum SessionRestorePolicy {
    static func shouldClearAuthentication(for error: Error) -> Bool {
        guard case APIError.authenticationExpired = error else { return false }
        return true
    }
}

enum APIRequestAuthMode {
    case none
    case device
    case session
}

struct APIRequestAuthHeaders {
    static func values(
        mode: APIRequestAuthMode,
        deviceToken: String,
        sessionToken: String,
        accessToken: String
    ) -> [String: String] {
        switch mode {
        case .none:
            return [:]
        case .device:
            return deviceToken.isEmpty ? [:] : ["X-Device-Token": deviceToken]
        case .session:
            var headers: [String: String] = [:]
            if !deviceToken.isEmpty { headers["X-Device-Token"] = deviceToken }
            let currentSessionToken = accessToken.isEmpty ? sessionToken : accessToken
            if !currentSessionToken.isEmpty {
                headers["X-Session-Token"] = currentSessionToken
                headers["Authorization"] = "Bearer \(currentSessionToken)"
            }
            return headers
        }
    }
}

enum APIRequestTimeoutPolicy {
    static func value(path: String) -> TimeInterval {
        if path == "ai/recognize-title" { return 8 }
        if path == "ai/generate-summary" { return 25 }
        if path.hasPrefix("ai/") { return 180 }
        if path.contains("/pack-pieces/estimate-") { return 60 }
        if path.hasPrefix("items/"), path.hasSuffix("/recommendation-card") { return 45 }
        return 30
    }
}

enum APITransientRetryPolicy {
    static func shouldRetry(status: Int, path: String, retryAvailable: Bool) -> Bool {
        guard retryAvailable else { return false }
        if path == "location/switch" {
            return [502, 503, 504].contains(status)
        }
        let isPackPieces = path.hasPrefix("parcels/items/") && path.contains("/pack-pieces")
        return isPackPieces && [500, 502, 503, 504].contains(status)
    }
}

struct PreparedListingPayload {
    let storagePath: String
    let signedURL: String
    var bucket: String = "sku-listing"
}

final class APIClient {
    static let shared = APIClient()

    private let sessionStore: SessionStore
    private let session: URLSession
    private let refreshCoordinator = SessionRefreshCoordinator()
    private let handheldBase = URL(string: "https://erp.boomeroff.com/api/public/handheld/")!
    private let publicBase = URL(string: "https://erp.boomeroff.com/api/public/")!

    private init() {
        sessionStore = .shared
        let configuration = URLSessionConfiguration.default
        #if DEBUG && targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--test-product-image-editor") || ProcessInfo.processInfo.arguments.contains("--test-image-retouch") {
            configuration.protocolClasses = [ProductEditorFixtureProtocol.self]
        }
        #endif
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 120
        configuration.waitsForConnectivity = true
        session = URLSession(configuration: configuration)
    }

    init(session: URLSession, sessionStore: SessionStore) {
        self.session = session
        self.sessionStore = sessionStore
    }

    func sendOTP(phone: String) async throws -> Int {
        let data = try await request(
            base: publicBase,
            path: "auth/otp/send",
            method: "POST",
            body: ["phone": phone, "purpose": "login"],
            authenticated: false
        )
        return number(data["ttl"]) ?? 300
    }

    func verifyOTP(phone: String, code: String) async throws -> BootstrapPayload {
        let body: [String: Any] = [
            "phone": phone,
            "code": code,
            "install_id": sessionStore.installID,
            "device_label": UIDevice.current.name,
            "app_version": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0.0",
            "os_version": "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)",
            "capabilities": [
                "reader_model": "IPHONE",
                "has_camera": true,
                "has_printer": true,
                "has_rfid_reader": false,
                "has_barcode_scanner": true
            ]
        ]
        let data = try await request(
            base: publicBase,
            path: "auth/otp/verify",
            method: "POST",
            body: body,
            authenticated: false
        )
        return try saveBootstrap(data)
    }

    func bootstrap(identity: String, password: String) async throws -> BootstrapPayload {
        let normalizedIdentity = identity.trimmingCharacters(in: .whitespacesAndNewlines)
        var body: [String: Any] = [
            "password": password,
            "install_id": sessionStore.installID,
            "device_label": UIDevice.current.name,
            "app_version": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0.0",
            "os_version": "\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)",
            "capabilities": [
                "reader_model": "UNKNOWN",
                "has_camera": true,
                "has_printer": true,
                "has_rfid_reader": false,
                "has_barcode_scanner": true
            ]
        ]
        body[normalizedIdentity.contains("@") ? "email" : "phone"] = normalizedIdentity
        let data = try await request(
            path: "auth/bootstrap",
            method: "POST",
            body: body,
            authenticated: false
        )
        return try saveBootstrap(data)
    }

    func locations() async throws -> [Location] {
        let data = try await request(path: "locations")
        return dictionaries(data["items"]).compactMap(parseLocation)
    }

    func switchLocation(_ location: Location) async throws -> Location {
        let data = try await request(
            path: "location/switch",
            method: "POST",
            body: ["location_id": location.id],
            retryOnTransientGateway: true
        )
        let result = parseLocation(dictionary(data["location"])) ?? location
        sessionStore.selectedLocationID = result.id
        return result
    }

    func dashboard(locationID: String) async throws -> DashboardData {
        let data = try await request(path: "dashboard?location_id=\(encode(locationID))")
        let stats = dictionary(data["stats"])
        return DashboardData(
            stats: DashboardStats(
                stockCount: number(stats["stock_count"]) ?? 0,
                inventoryAccuracy: decimal(stats["inventory_accuracy"]),
                inTransitCount: number(stats["in_transit_count"]) ?? 0
            ),
            tasks: dictionaries(data["tasks"]).map { item in
                DashboardTask(
                    id: string(item["id"]),
                    type: string(item["type"]),
                    urgency: string(item["urgency"]),
                    title: string(item["title"]),
                    description: string(item["description"]),
                    action: string(item["action"]),
                    targetId: string(item["target_id"])
                )
            },
            unreadNotifications: number(data["unread_notifications"]) ?? 0
        )
    }

    func currentUser() async throws -> ERPUser {
        let data = try await request(path: "auth/me")
        return ERPUser.apiPayload(data)
    }

    func products(_ query: ProductListQuery) async throws -> ([Product], ProductCounts) {
        guard !query.userID.isEmpty, !query.locationID.isEmpty else { throw ProductScopeError.mismatchedResponse }
        let pageSize = 500
        let firstPage = try await productPage(
            query: query,
            page: 1,
            pageSize: pageSize
        )
        let additionalPages = ProductPagePlan.additionalPages(total: firstPage.total, pageSize: pageSize)
        guard !additionalPages.isEmpty else { return (firstPage.products, firstPage.counts) }

        let remaining = try await withThrowingTaskGroup(of: (Int, ProductPageResult).self) { group in
            for page in additionalPages {
                group.addTask { [self] in
                    let result = try await productPage(
                        query: query,
                        page: page,
                        pageSize: pageSize
                    )
                    return (page, result)
                }
            }
            var values: [(Int, ProductPageResult)] = []
            for try await value in group { values.append(value) }
            return values.sorted { $0.0 < $1.0 }
        }
        return (
            firstPage.products + remaining.flatMap { $0.1.products },
            firstPage.counts
        )
    }

    private struct ProductPageResult {
        let products: [Product]
        let counts: ProductCounts
        let total: Int
    }

    private func productPage(
        query: ProductListQuery,
        page: Int,
        pageSize: Int
    ) async throws -> ProductPageResult {
        let data = try await request(path: query.path(page: page, pageSize: pageSize))
        try query.validateResponse(data)
        let countsJSON = dictionary(data["counts"])
        let counts = ProductCounts(
            custom: number(countsJSON["custom"]) ?? 0,
            bundle: number(countsJSON["bundle"]) ?? 0,
            standard: number(countsJSON["standard"]) ?? 0,
            all: number(countsJSON["all"]) ?? 0
        )
        return ProductPageResult(
            products: dictionaries(data["items"]).map(parseProduct),
            counts: counts,
            total: number(data["total"]) ?? 0
        )
    }

    func productDetail(id: String, query: ProductListQuery) async throws -> Product {
        let data = try await request(path: query.detailPath(id: id))
        try query.validateDetail(data)
        return parseProduct(data)
    }

    func productCapabilities(id: String, query: ProductListQuery) async throws -> ProductCapabilities {
        let data = try await request(path: query.detailPath(id: id) + "&capabilities_only=1")
        return try ProductCapabilities(data: data, productID: id, scope: query.marker)
    }

    func updateProduct(id: String, body: [String: Any]) async throws {
        _ = try await request(path: "items/\(encode(id))", method: "PATCH", body: body,
                              clientOperationID: body["client_op_id"] as? String)
    }

    func deleteProduct(id: String, locationID: String, operationID: String) async throws {
        _ = try await request(path: "items/\(encode(id))", method: "DELETE",
                              body: ["location_id": locationID, "client_op_id": operationID, "confirm": true],
                              clientOperationID: operationID)
    }

    func globalStock(
        type: ProductType,
        query: String = "",
        stockState: String = "all",
        status: String = "all"
    ) async throws -> GlobalStockData {
        var parts = [
            "type=\(type.rawValue)",
            "stock_state=\(stockState)",
            "status=\(status)",
            "page_size=100"
        ]
        if !query.isEmpty { parts.append("q=\(encode(query))") }
        let data = try await request(path: "global-stock?\(parts.joined(separator: "&"))")
        let summary = dictionary(data["summary"])
        return GlobalStockData(
            locations: dictionaries(data["locations"]).map {
                StockLocation(id: string($0["id"]), name: string($0["name"]), kind: string($0["kind"]))
            },
            items: dictionaries(data["items"]).map { item in
                let stockJSON = dictionary(item["stocks"])
                var stocks: [String: Int] = [:]
                for (key, value) in stockJSON { stocks[key] = number(value) ?? 0 }
                let status = string(item["listing_status"])
                return GlobalStockItem(
                    id: string(item["sku_id"]),
                    name: string(item["name"]),
                    skuCode: string(item["sku_code"]),
                    barcode: string(item["barcode"]),
                    category: string(item["category"]),
                    productType: string(item["product_type"]),
                    imageURL: string(item["image_url"]),
                    price: decimal(item["price"]) ?? 0,
                    totalQty: number(item["total_qty"]) ?? 0,
                    listingStatus: status,
                    statusLabel: string(item["status_label"]).isEmpty ? statusTitle(status) : string(item["status_label"]),
                    stocks: stocks,
                    isUnlimitedStock: boolean(item["is_unlimited_stock"])
                )
            },
            skuCount: number(summary["sku_count"]) ?? 0,
            totalQty: number(summary["total_qty"]) ?? 0,
            outOfStock: number(summary["out_of_stock"]) ?? 0,
            lowStock: number(summary["low_stock"]) ?? 0
        )
    }

    func setProductDisplay(id: String, visible: Bool) async throws -> Product {
        let data = try await request(
            path: "items/\(encode(id))/set-status",
            method: "POST",
            body: ["is_display": visible]
        )
        return parseProduct(dictionary(data["sku"]).isEmpty ? data : dictionary(data["sku"]))
    }

    func restockProduct(
        id: String,
        locationID: String?,
        quantity: Int,
        printLabels: Bool,
        templateID: String?
    ) async throws -> Product {
        var body: [String: Any] = [
            "delta": max(quantity, 1),
            "print_labels": printLabels,
            "note": "iOS 手持终端补货入库"
        ]
        if let locationID, !locationID.isEmpty { body["location_id"] = locationID }
        if let templateID, !templateID.isEmpty { body["label_template_id"] = templateID }
        let data = try await request(
            path: "items/\(encode(id))/restock",
            method: "POST",
            body: body,
            clientOperationID: "ios-restock-\(UUID().uuidString.lowercased())"
        )
        let sku = dictionary(data["sku"])
        return parseProduct(sku.isEmpty ? data : sku)
    }

    func productContent(id: String, body: [String: Any]) async throws -> [String: Any] {
        try await request(path: "items/\(encode(id))/content", method: "POST", body: body)
    }

    func recommendationCard(id: String, query: ProductListQuery) async throws -> (A4CardCopy, String) {
        let data = try await request(path: "items/\(encode(id))/recommendation-card", method: "POST",
                                     body: ["location_id": query.locationID])
        return try A4CardCopy.fromRecommendation(data)
    }

    func customPrintCardRequest(method: String, suffix: String, body: [String: Any]?) async throws -> [String: Any] {
        try await request(path: "print/custom-cards" + suffix, method: method, body: body)
    }

    func printStoreQR(locationID: String) async throws -> A4StoreQR {
        let data = try await request(path: "print/store-qr", method: "POST",
                                     body: ["action": "get", "location_id": locationID])
        return try A4StoreQR(data: data, expectedLocationID: locationID)
    }

    func savePrintStoreQR(locationID: String, channel: String, image: Data, mime: String) async throws {
        _ = try await request(path: "print/store-qr", method: "POST",
                              body: ["action": "save", "location_id": locationID, "channel": channel,
                                     "image_base64": image.base64EncodedString(), "mime_type": mime])
    }

    func recognizeTitle(image: Data) async throws -> String {
        let data = try await request(path: "ai/recognize-title", method: "POST",
                                     body: ["image_base64": image.base64EncodedString()])
        return string(data["name"])
    }

    func uploadImage(
        _ imageData: Data,
        bucket: String = "sku-raw"
    ) async throws -> String {
        let filename = "\(UUID().uuidString.lowercased()).jpg"
        let signed: [String: Any]
        do {
            signed = try await request(
                path: "items/upload-image",
                method: "POST",
                body: [
                    "bucket": bucket,
                    "filename": filename,
                    "content_type": "image/jpeg",
                    "mode": "signed"
                ]
            )
        } catch {
            if error is CancellationError { throw error }
            if case APIError.authenticationExpired = error { throw error }
            throw APIError.message("获取图片上传凭证失败：\(error.localizedDescription)")
        }
        guard let uploadURL = URL(string: string(signed["upload_url"])),
              uploadURL.scheme == "https", uploadURL.host != nil else {
            throw APIError.message("ERP 未返回图片上传地址")
        }
        let storagePath = string(signed["storage_path"]).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !storagePath.isEmpty else { throw APIError.message("ERP 未返回图片保存路径") }
        var uploadRequest = URLRequest(url: uploadURL)
        uploadRequest.httpMethod = "PUT"
        uploadRequest.httpBody = imageData
        uploadRequest.setValue("image/jpeg", forHTTPHeaderField: "Content-Type")
        for (key, value) in dictionary(signed["headers"]) {
            uploadRequest.setValue(string(value), forHTTPHeaderField: key)
        }
        let response: URLResponse
        do {
            (_, response) = try await session.data(for: uploadRequest)
        } catch {
            if error is CancellationError { throw error }
            if let error = error as? URLError {
                if error.code == .cancelled { throw error }
                // Never expose a signed URL or storage response body in diagnostics.
                let reason: String
                switch error.code {
                case .timedOut: reason = "上传超时"
                case .notConnectedToInternet: reason = "网络未连接"
                case .networkConnectionLost: reason = "网络连接中断"
                case .cannotFindHost, .dnsLookupFailed: reason = "无法解析图片服务器"
                case .cannotConnectToHost: reason = "无法连接图片服务器"
                default: reason = "网络连接失败"
                }
                throw APIError.message("商品图片直传失败（\(reason)，NSURLError \(error.code.rawValue)），请检查网络后重试")
            }
            throw APIError.message("商品图片直传失败，请重试")
        }
        guard let response = response as? HTTPURLResponse else {
            throw APIError.message("商品图片直传未收到有效响应，请重试")
        }
        guard (200..<300).contains(response.statusCode) else {
            throw APIError.message("商品图片直传失败（HTTP \(response.statusCode)），请重试")
        }
        return storagePath
    }

    func signReadURL(bucket: String, storagePath: String) async throws -> String {
        let data = try await request(
            path: "items/sign-read-url",
            method: "POST",
            body: [
                "bucket": bucket,
                "storage_path": storagePath,
                "expires_in": 3600
            ]
        )
        let url = string(data["read_url"])
        guard !url.isEmpty else {
            throw APIError.message("ERP 未返回商品图片预览地址")
        }
        return url
    }

    func recognizeItem(
        paths: [String],
        bucket: String = "sku-raw",
        primaryIndex: Int = 0,
        previewImages: [Data] = []
    ) async throws -> RecognitionPayload {
        let images = paths.prefix(6).map {
            ["bucket": bucket, "storage_path": $0]
        }
        var body: [String: Any] = [
            "primary_index": min(primaryIndex, max(0, max(paths.count, previewImages.count) - 1)),
            "hint": "识别中古杂货商品，生成鲜活有吸引力的准确名称、ERP分类、品牌、具体IP角色、丰富多维标签、年代和N/S/A/B/C/J成色。价签简介约20至30字，优先包含有依据的年代范围、物件类型与可见特点；没有依据时省略年代，不写待确认，不能把IP诞生年或版权年份当作生产年，不编造限定、绝版或收藏价值。"
        ]
        if previewImages.isEmpty {
            body["image_storage_paths"] = images
        } else {
            body["images"] = previewImages.prefix(6).map { ["image_base64": $0.base64EncodedString()] }
        }
        let data = try await request(
            path: "ai/recognize-item",
            method: "POST",
            body: body
        )
        let categoryCode = string(data["category_code"]).isEmpty
            ? string(data["category"])
            : string(data["category_code"])
        let category = string(data["category_name"]).isEmpty
            ? ERPProductCategory(rawValue: categoryCode)?.title ?? ""
            : string(data["category_name"])
        return RecognitionPayload(
            name: string(data["name"]),
            category: category,
            categoryCode: categoryCode,
            brand: string(data["brand"]),
            ipName: string(data["ip_name"]),
            ipMatchStatus: string(data["ip_match_status"]),
            ipSuggestions: dictionaries(data["ip_suggestions"]).map {
                IPRecognitionSuggestion(
                    id: string($0["id"]),
                    name: string($0["name"]),
                    confidence: decimal($0["score"]) ?? 0
                )
            },
            tags: strings(data["tags"]),
            facetCodes: strings(data["facet_codes"]),
            era: RecognitionEraDisplay.normalized(string(data["era"])),
            conditionGrade: ConditionGrade.normalized(string(data["condition_grade"])).rawValue,
            description: string(data["description"]),
            suggestedPrice: decimal(data["suggested_price_cny"]),
            confidence: decimal(data["confidence"]),
            warning: string(data["warning"]),
            requestID: string(data["request_id"]),
            classificationStatus: string(data["status"]),
            brandID: string(data["brand_id"]),
            brandMatchStatus: string(data["brand_match_status"]),
            brandSuggestions: dictionaries(data["brand_suggestions"]).map {
                IPRecognitionSuggestion(id: string($0["id"]), name: string($0["name"]),
                                        confidence: decimal($0["score"]) ?? 0)
            }
        )
    }

    func generateListingSummary(_ input: ListingSummaryInput) async throws -> String {
        let data = try await request(path: "ai/generate-summary", method: "POST", body: input.body)
        return string(data["description"])
    }

    func prepareListingImage(rawStoragePath: String) async throws -> PreparedListingPayload {
        let sourceURL = try await signReadURL(bucket: "sku-raw", storagePath: rawStoragePath)
        let data = try await request(
            path: "ai/prepare-listing-image",
            method: "POST",
            body: [
                "image_url": sourceURL,
                "instruction": "输出严格为 1:1 正方形；保留商品本体、文字、Logo、条码、瑕疵和颜色，只优化背景、角度、白平衡与曝光。"
            ]
        )
        let storagePath = string(data["storage_path"])
        let signedURL = string(data["signed_url"])
        guard !storagePath.isEmpty, !signedURL.isEmpty else {
            throw APIError.message("ERP 未返回处理后的商品图片")
        }
        return PreparedListingPayload(storagePath: storagePath, signedURL: signedURL)
    }

    func retouchProductImage(storageKey: String, instruction: String) async throws -> PreparedListingPayload {
        let source = try ProductImageRetouch.source(storageKey)
        let sourceURL = try await signReadURL(bucket: source.bucket, storagePath: source.path)
        let data = try await request(path: "ai/prepare-listing-image", method: "POST",
                                     body: ["image_url": sourceURL, "instruction": instruction])
        let path = string(data["storage_path"]), url = string(data["signed_url"])
        guard !path.isEmpty, !url.isEmpty else { throw APIError.message("修图服务未返回图片，请重试；原图未修改") }
        if data["preserved_original"] as? Bool == true {
            throw APIError.message("检测到外部测量工具，为保护真实刻度，本次只保留原图，没有进行修图；可补充具体要求或使用其他角度照片。")
        }
        return PreparedListingPayload(storagePath: path, signedURL: url)
    }

    func productTaxonomy() async throws -> ProductTaxonomy {
        let data = try await request(
            base: publicBase,
            path: "storefront/taxonomy",
            authenticated: false
        )
        var options: [ProductCategoryOption] = []
        for parent in dictionaries(data["primary_categories"]) {
            let parentName = string(parent["name"])
            let parentCode = string(parent["code"])
            for child in dictionaries(parent["children"]) {
                let code = string(child["code"])
                let name = string(child["name"])
                guard !code.isEmpty, !name.isEmpty else { continue }
                options.append(ProductCategoryOption(code: code, name: name, parentName: parentName, parentCode: parentCode))
            }
        }
        let facets = dictionaries(data["facets"]).compactMap { row -> ProductFacetOption? in
            let code = string(row["code"])
            let name = string(row["name"])
            guard !code.isEmpty, !name.isEmpty else { return nil }
            return ProductFacetOption(
                code: code,
                name: name,
                dimension: string(row["dimension"]),
                categoryCodes: strings(row["category_codes"])
            )
        }
        return ProductTaxonomy(categories: options, facets: facets)
    }

    func productCategories() async throws -> [ProductCategoryOption] {
        (try await productTaxonomy()).categories
    }

    func smartCreate(
        _ draft: ListingDraft,
        locationID: String,
        preserveOriginals: ([Data], String) async -> [String] = { images, key in
            await ProductImageCache.shared.preserveOriginals(images, productID: key)
        }
    ) async throws -> Product {
        guard let submission = draft.submission, submission.locationID == locationID,
              let body = try JSONSerialization.jsonObject(with: submission.body) as? [String: Any] else {
            throw APIError.message("上架草稿尚未安全保存，请重试")
        }
        // Original files do not depend on the server SKU. Use the persisted operation ID
        // so cache writes overlap the request and retries reuse the same local files.
        async let originalURLs = preserveOriginals(draft.images, submission.operationID)
        let data = try await request(
            path: "items/smart-create",
            method: "POST",
            body: body,
            clientOperationID: submission.operationID
        )
        let imageProcessing = dictionary(data["image_processing"])
        let localOriginalURLs = await originalURLs
        let previewURLs = draft.listingURLs.isEmpty ? localOriginalURLs : draft.listingURLs
        return Product(
            id: string(data["sku_id"]),
            name: string(body["name"]),
            skuCode: string(data["sku_code"]),
            barcode: string(data["barcode"]),
            category: draft.category,
            productType: "custom",
            imageURL: previewURLs.first ?? "",
            price: (body["price_tier"] as? NSNumber)?.doubleValue ?? 0,
            stockQty: 1,
            conditionGrade: draft.conditionGrade,
            listingStatus: "selling",
            statusLabel: "销售中",
            editable: true,
            canRestock: false,
            images: previewURLs,
            description: draft.description,
            brand: draft.brand,
            era: draft.era,
            ipName: draft.ipName,
            tags: draft.normalizedTags,
            imageProcessingStatus: firstNonEmpty(
                string(imageProcessing["status"]),
                "idle"
            )
        )
    }

    func customTransfers(_ input: [String: Any]) async throws -> CustomTransferResponse {
        let data = try await request(path: "custom-transfers", method: "POST", body: input)
        return try JSONDecoder().decode(CustomTransferResponse.self, from: JSONSerialization.data(withJSONObject: data))
    }

    func transfers(locationID: String, role: String? = nil) async throws -> [TransferRecord] {
        var parts = ["location_id=\(encode(locationID))"]
        if let role { parts.append("role=\(role)") }
        let data = try await request(path: "transfers?\(parts.joined(separator: "&"))")
        return dictionaries(data["items"]).map {
            TransferRecord(
                id: string($0["id"]),
                code: string($0["code"]),
                status: string($0["status"]),
                qty: number($0["qty"]) ?? 0,
                fromLocationID: string($0["from_location_id"]),
                toLocationID: string($0["to_location_id"]),
                createdAt: string($0["created_at"]),
                notes: string($0["notes"])
            )
        }
    }

    func transferDetail(id: String) async throws -> TransferDetail {
        let data = try await request(path: "transfers/\(encode(id))")
        return TransferDetail(
            summary: parseTransfer(data),
            lines: dictionaries(data["lines"]).map {
                TransferLine(
                    skuID: string($0["sku_id"]),
                    expectedQty: number($0["expected_qty"]) ?? 0,
                    shippedQty: number($0["shipped_qty"]) ?? 0,
                    receivedQty: number($0["received_qty"]) ?? 0
                )
            },
            epcs: dictionaries(data["epcs"]).map {
                TransferEPC(
                    epc: string($0["epc"]),
                    skuID: string($0["sku_id"]),
                    shipScannedAt: string($0["ship_scanned_at"]),
                    receiveScannedAt: string($0["receive_scanned_at"])
                )
            }
        )
    }

    func transferScan(
        transfer: TransferRecord,
        currentLocationID: String,
        epcs: [String]
    ) async throws -> TransferScanResult {
        let cleaned = Array(Set(epcs.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }))
        let isShipping = currentLocationID == transfer.fromLocationID
        let isReceiving = currentLocationID == transfer.toLocationID
        guard isShipping || isReceiving else {
            throw APIError.message("当前库位不是该调拨单的发货方或收货方")
        }
        let data = try await request(
            path: isShipping ? "transfer/ship-scan" : "transfer/receive-scan",
            method: "POST",
            body: ["transfer_id": transfer.id, "epcs": cleaned]
        )
        return TransferScanResult(
            side: isShipping ? "ship" : "receive",
            received: number(data["received"]) ?? cleaned.count,
            unknown: strings(data["unknown"])
        )
    }

    func confirmTransfer(_ transfer: TransferRecord, currentLocationID: String) async throws -> String {
        let isShipping = currentLocationID == transfer.fromLocationID
        let isReceiving = currentLocationID == transfer.toLocationID
        guard isShipping || isReceiving else {
            throw APIError.message("当前库位不是该调拨单的发货方或收货方")
        }
        _ = try await request(
            path: isShipping ? "transfer/ship-confirm" : "transfer/receive-confirm",
            method: "POST",
            body: ["transfer_id": transfer.id],
            clientOperationID: "ios-transfer-\(UUID().uuidString.lowercased())"
        )
        return isShipping ? "已确认发货" : "已确认收货"
    }

    func stocktakes(locationID: String) async throws -> [StocktakeRecord] {
        let data = try await request(path: "stocktakes?location_id=\(encode(locationID))")
        return dictionaries(data["items"]).map {
            StocktakeRecord(
                id: string($0["id"]),
                code: string($0["code"]),
                status: string($0["status"]),
                openedAt: string($0["opened_at"]),
                submittedAt: string($0["submitted_at"]),
                notes: string($0["notes"])
            )
        }
    }

    func openStocktake() async throws -> StocktakeRecord {
        parseStocktake(try await request(path: "stocktake/open", method: "POST", body: [:]))
    }

    func scanStocktake(id: String, epcs: [String]) async throws -> Int {
        let cleaned = Array(Set(epcs.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }))
        let data = try await request(
            path: "stocktake/scan",
            method: "POST",
            body: ["stocktake_id": id, "epcs": cleaned]
        )
        return number(data["scanned"]) ?? cleaned.count
    }

    func submitStocktake(id: String) async throws {
        _ = try await request(
            path: "stocktake/submit",
            method: "POST",
            body: ["stocktake_id": id],
            clientOperationID: "ios-stocktake-\(UUID().uuidString.lowercased())"
        )
    }

    func serviceConversations(locationID: String?, queue: String, cursor: String?, query: String = "") async throws -> ServiceConversationPage {
        let started = ProcessInfo.processInfo.systemUptime
        defer { Logger(subsystem: "top.boomeroff.erp", category: "service-performance").info("list elapsed_ms=\(Int((ProcessInfo.processInfo.systemUptime - started) * 1000), privacy: .public)") }
        let path = "support/conversations?queue=\(Self.serviceQueryValue(queue))&limit=50"
            + (locationID.map { "&location_id=\(Self.serviceQueryValue($0))" } ?? "")
            + (cursor.map { "&cursor=\(Self.serviceQueryValue($0))" } ?? "")
            + (query.isEmpty ? "" : "&q=\(Self.serviceQueryValue(String(query.prefix(80))))")
        let data = try await request(path: path)
        guard let items = data["items"] as? [[String: Any]] else { throw APIError.message("ERP 客服接口格式不匹配，请联系总部更新服务") }
        let conversations = items.map(ServiceConversation.fromJSON)
        if let locationID, conversations.contains(where: { $0.locationID != locationID }) {
            throw ServiceAccessError()
        }
        return ServiceConversationPage(items: conversations, nextCursor: data["next_cursor"] as? String)
    }

    static func serviceQueryValue(_ value: String) -> String {
        value.addingPercentEncoding(withAllowedCharacters: CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")) ?? ""
    }

    func serviceConversation(id: String, locationID: String? = nil, window: ServiceMessageWindow = .latest) async throws -> ServiceConversationDetail {
        let started = ProcessInfo.processInfo.systemUptime
        defer { Logger(subsystem: "top.boomeroff.erp", category: "service-performance").info("detail elapsed_ms=\(Int((ProcessInfo.processInfo.systemUptime - started) * 1000), privacy: .public)") }
        var path = "support/conversations/\(encode(id))?limit=50"
        if let locationID { path += "&location_id=\(Self.serviceQueryValue(locationID))" }
        switch window {
        case .latest: break
        case .older(let cursor): path += "&before=\(Self.serviceQueryValue(cursor))"
        case .newer(let cursor): path += "&after=\(Self.serviceQueryValue(cursor))"
        }
        let data = try await request(path: path)
        guard (data["conversation"] as? [String: Any])?["id"] as? String == id,
              data["messages"] is [[String: Any]] else { throw APIError.message("客服会话读取不完整，请重试") }
        let conversation = ServiceConversation.fromJSON(dictionary(data["conversation"]))
        if let locationID, conversation.locationID != locationID { throw ServiceAccessError() }
        return ServiceConversationDetail(conversation: conversation,
            messages: dictionaries(data["messages"]).map(ServiceMessage.fromJSON), hasMore: data["has_more"] as? Bool ?? false,
            olderCursor: data["older_cursor"] as? String, latestCursor: data["latest_cursor"] as? String,
            hasNewer: data["has_newer"] as? Bool ?? false)
    }

    func sendServiceMessage(id: String, body: String, internalNote: Bool, operationID: String, assignmentVersion: Int?, locationID: String? = nil) async throws {
        var payload: [String: Any] = [
            "body": body, "internal": internalNote, "client_op_id": operationID,
        ]
        if let assignmentVersion { payload["assignment_version"] = assignmentVersion }
        if let locationID { payload["location_id"] = locationID }
        _ = try await request(path: "support/conversations/\(encode(id))", method: "POST", body: payload)
    }

    func updateServiceAssignment(id: String, action: String, version: Int, locationID: String? = nil) async throws {
        var payload: [String: Any] = [
            "action": action, "assignment_version": version,
        ]
        if let locationID { payload["location_id"] = locationID }
        _ = try await request(path: "support/conversations/\(encode(id))/assignment", method: "POST", body: payload)
    }

    func orderCenter(query: OrderCenterQuery, page: Int) async throws -> OrderCenterPage {
        guard !query.userID.isEmpty, query.isHQ || !query.locationID.isEmpty else {
            throw APIError.message("请先登录并选择有权限的门店")
        }
        let data = try await request(path: query.path(page: page))
        guard query.accepts(scope: data["scope"] as? String) else {
            throw APIError.message("订单返回的门店范围不一致，已阻止显示，请刷新重试")
        }
        return try OrderCenterPage.decode(data, mode: query.mode)
    }

    func parentOrder(id: String) async throws -> OrderCenterRecord {
        let order = try OrderCenterRecord.parent(try await request(path: "orders/\(encode(id))"))
        guard order.id == id else { throw OrderCenterDecodingError.incomplete }
        return order
    }

    func fulfillments(locationID: String) async throws -> [FulfillmentOrder] {
        let data = try await request(path: "fulfillments?format=items&location_id=\(encode(locationID))")
        return dictionaries(data["items"] ?? data["data"]).map(FulfillmentOrder.fromJSON)
    }

    func fulfillment(id: String) async throws -> FulfillmentOrder {
        let data = try await request(path: "fulfillments/\(encode(id))")
        guard data["id"] as? String == id, data["items"] is [[String: Any]], data["status"] is String else {
            throw OrderCenterDecodingError.incomplete
        }
        return FulfillmentOrder.fromJSON(data)
    }

    func fulfillmentTicket(id: String) async throws -> OrderTicket {
        let ticket = OrderTicket.fromJSON(try await request(path: "fulfillments/\(encode(id))/ticket"))
        guard ticket.fulfillmentID == id, !ticket.lines.isEmpty,
              ticket.lines.allSatisfy({ !$0.title.isEmpty && !$0.barcode.isEmpty && $0.quantity > 0 }) else {
            throw APIError.message("订单条缺少商品标题、条码或数量，请在 ERP 核对后重试")
        }
        return ticket
    }

    func pickFulfillmentItem(id: String, lineID: String, barcode: String, operationID: String) async throws {
        let result = try await request(path: "fulfillments/\(encode(id))/pick-scan", method: "POST",
                                       body: ["code": barcode, "fulfillment_item_id": lineID, "client_op_id": operationID])
        guard result["accepted"] as? Bool == true else { throw APIError.message("条码与待拣商品不匹配，未计入拣货") }
    }

    func completeFulfillmentPick(id: String) async throws {
        let result = try await request(path: "fulfillments/\(encode(id))/pick-complete", method: "POST", body: [:])
        guard result["id"] as? String == id, result["status"] as? String == "picked" else {
            throw APIError.message("尚未确认拣货完成，请刷新订单状态")
        }
    }

    func reportFulfillmentShortage(id: String, lineID: String, quantity: Int, reason: String, operationID: String) async throws {
        let result = try await request(path: "fulfillments/\(encode(id))/shortage", method: "POST", body: [
            "fulfillment_item_id": lineID, "quantity": quantity, "reason": reason, "client_op_id": operationID,
        ])
        guard let shortage = result["shortage"] as? [String: Any],
              shortage["fulfillment_id"] as? String == id,
              shortage["fulfillment_item_id"] as? String == lineID,
              !(shortage["id"] as? String ?? "").isEmpty,
              shortage["status"] as? String == "pending_customer" else {
            throw APIError.message("尚未确认缺货申报结果，请刷新订单后重试")
        }
    }

    func notifications(locationID: String, limit: Int = 50) async throws -> [NotificationRecord] {
        let data = try await request(path: "notifications?location_id=\(encode(locationID))&limit=\(limit)")
        return dictionaries(data["items"]).map(NotificationRecord.fromJSON)
    }

    func readAllNotifications() async throws {
        _ = try await request(path: "notifications/read-all", method: "POST", body: [:])
    }

    func lookupRFID(_ epc: String) async throws -> RFIDLookupResult {
        let data = try await request(path: "rfid/\(encode(epc))")
        let location = dictionary(data["location"])
        return RFIDLookupResult(
            known: boolean(data["known"]),
            epc: string(data["epc"]).isEmpty ? epc : string(data["epc"]),
            currentLocationID: firstNonEmpty(string(data["current_location_id"]), string(location["id"])),
            currentLocationName: string(location["name"]),
            skuID: string(data["sku_id"])
        )
    }

    func stockInRFID(_ epc: String) async throws -> RFIDStockInResult {
        let data = try await request(
            path: "inbound/scan",
            method: "POST",
            body: ["epcs": [epc]],
            clientOperationID: "ios-inbound-\(UUID().uuidString.lowercased())"
        )
        return RFIDStockInResult(
            accepted: (number(data["accepted_count"]) ?? 0) + (number(data["unclaimed_count"]) ?? 0),
            duplicated: dictionaries(data["duplicated"]).map { string($0["epc"]) }
        )
    }

    func transferRFID(_ epc: String, to locationID: String) async throws {
        let operationID = "ios-rfid-move-\(UUID().uuidString.lowercased())"
        _ = try await request(
            path: "rfid/transfer-location",
            method: "POST",
            body: [
                "epc": epc,
                "to_location_id": locationID,
                "reason": "iOS 手持终端现场确认转仓",
                "client_op_id": operationID
            ],
            clientOperationID: operationID
        )
    }

    func bindRFID(skuID: String, epc: String, locationID: String?) async throws -> RFIDBindResult {
        var body: [String: Any] = [
            "sku_id": skuID,
            "epc": epc,
            "client_op_id": "ios-rfid-bind-\(UUID().uuidString.lowercased())"
        ]
        if let locationID, !locationID.isEmpty { body["location_id"] = locationID }
        let data = try await request(
            path: "items/bind-rfid",
            method: "POST",
            body: body,
            clientOperationID: body["client_op_id"] as? String
        )
        return RFIDBindResult(
            epc: string(data["epc"]),
            skuID: string(data["sku_id"]),
            locationID: string(data["location_id"]),
            stockAfter: number(data["stock_after"]) ?? 0
        )
    }

    func labelTemplates() async throws -> LabelTemplateCollection {
        let data = try await request(path: "label-templates")
        let defaultID = string(data["default_template_id"])
        let defaultIDs = dictionary(data["default_template_ids"])
        return LabelTemplateCollection(
            defaultTemplateID: defaultID,
            defaultTemplateIDs: [
                .label: firstNonEmpty(string(defaultIDs["label"]), defaultID),
                .receipt: string(defaultIDs["receipt"])
            ],
            items: dictionaries(data["items"]).map { parseLabelTemplate($0, defaultID: defaultID) },
            canManage: boolean(data["can_manage"])
        )
    }

    func saveLabelTemplate(_ template: LabelTemplate) async throws -> LabelTemplate {
        let body = labelTemplateBody(template)
        let data = try await request(
            path: "label-templates/\(encode(template.id))",
            method: "PUT",
            body: body
        )
        return parseLabelTemplate(data, defaultID: template.isDefault ? template.id : "")
    }

    func createLabelTemplate(_ template: LabelTemplate) async throws -> LabelTemplate {
        let data = try await request(
            path: "label-templates",
            method: "POST",
            body: labelTemplateBody(template).merging(["is_default": template.isDefault]) { _, new in new }
        )
        return parseLabelTemplate(data, defaultID: template.isDefault ? string(data["id"]) : "")
    }

    func deleteLabelTemplate(id: String) async throws {
        _ = try await request(path: "label-templates/\(encode(id))", method: "DELETE")
    }

    func setDefaultLabelTemplate(id: String) async throws {
        _ = try await request(
            path: "label-templates/\(encode(id))/set-default",
            method: "POST",
            body: [:]
        )
    }

    func syncRecords(status: String? = nil) async throws -> [SyncRecord] {
        let suffix = status.map { "?status=\($0)&limit=50" } ?? "?limit=50"
        let data = try await request(path: "sync-records\(suffix)")
        return dictionaries(data["items"]).map {
            SyncRecord(
                id: string($0["id"]),
                skuID: string($0["sku_id"]),
                targetStock: number($0["target_stock"]) ?? 0,
                reason: string($0["reason"]),
                status: string($0["status"]),
                attempts: number($0["attempts"]) ?? 0,
                lastError: string($0["last_error"]),
                updatedAt: string($0["updated_at"])
            )
        }
    }

    func parcelCounts() async throws -> ParcelCounts {
        let data = try await request(path: "parcels/counts")
        return ParcelCounts(
            pending: number(data["pending"]) ?? 0,
            received: number(data["received"]) ?? 0
        )
    }

    func parcels(
        bucket: ParcelBucket,
        mode: ParcelListMode,
        query: String,
        limit: Int = 30,
        offset: Int = 0
    ) async throws -> ParcelListResult {
        var parts = [
            "bucket=\(bucket.rawValue)",
            "mode=\(mode.rawValue)",
            "limit=\(min(max(limit, 1), 50))",
            "offset=\(max(offset, 0))"
        ]
        if !query.isEmpty { parts.append("q=\(encode(query))") }
        let data = try await request(path: "parcels?\(parts.joined(separator: "&"))")
        let resultMode = ParcelListMode(rawValue: string(data["mode"])) ?? mode
        return ParcelListResult(
            mode: resultMode,
            items: dictionaries(data["items"]).map { parseParcelItem($0) },
            rows: dictionaries(data["rows"]).map(parseParcelRow),
            hasMore: boolean(data["has_more"]),
            nextOffset: number(data["next_offset"])
        )
    }

    func parcelDetail(id: String) async throws -> ParcelDetail {
        let data = try await request(path: "parcels/\(encode(id))")
        let parcelJSON = dictionary(data["parcel"]).isEmpty ? data : dictionary(data["parcel"])
        let parcel = parseParcelRow(parcelJSON)
        let totalsJSON = dictionary(data["totals"])
        let totals = ParcelTotals(
            goodsTotalCNY: decimal(totalsJSON["goods_total_cny"]) ?? parcel.goodsTotalCNY,
            freightCNY: decimal(totalsJSON["freight_cny"]) ?? parcel.internationalFreightCNY,
            tariffCNY: decimal(totalsJSON["tariff_cny"]) ?? parcel.tariffCNY,
            grandTotalCNY: decimal(totalsJSON["grand_total_cny"]) ?? parcel.grandTotalCNY,
            totalQuantity: number(totalsJSON["total_qty"]) ?? parcel.totalQuantity,
            itemCount: number(totalsJSON["item_count"]) ?? parcel.itemCount
        )
        return ParcelDetail(
            parcel: parcel,
            totals: totals,
            items: dictionaries(data["items"]).map { parseParcelItem($0, fallbackParcelID: parcel.id) }
        )
    }

    func estimateParcelPackPieces(itemID: String, source: String) async throws -> PackPiecesEstimate {
        let normalizedSource = source == "image" ? "image" : "title"
        let data = try await request(
            path: "parcels/items/\(encode(itemID))/pack-pieces/estimate-\(normalizedSource)",
            method: "POST",
            body: [:],
            retryOnTransientGateway: true
        )
        return PackPiecesEstimate(
            pieces: number(data["pieces"]),
            confidence: decimal(data["confidence"]),
            reasoning: string(data["reasoning"]),
            unit: string(data["unit"])
        )
    }

    func saveParcelPackPieces(
        itemID: String,
        pieces: Int?,
        source: String,
        unit: String
    ) async throws -> PackPiecesResult {
        let operationID = "ios-pack-\(UUID().uuidString.lowercased())"
        let data = try await request(
            path: "parcels/items/\(encode(itemID))/pack-pieces",
            method: "POST",
            body: [
                "pack_pieces": pieces ?? NSNull(),
                "pack_pieces_source": source,
                "pack_unit_note": unit,
                "client_op_id": operationID
            ],
            clientOperationID: operationID,
            retryOnTransientGateway: true
        )
        return PackPiecesResult(
            id: string(data["id"]),
            packPieces: number(data["pack_pieces"]),
            source: string(data["pack_pieces_source"]),
            unit: string(data["pack_unit_note"]),
            piecePriceCNY: decimal(data["piece_price_cny"]),
            piecePriceJPY: decimal(data["piece_price_jpy"])
        )
    }

    func posBootstrap(locationID: String) async throws -> POSBootstrap {
        let data = try await request(
            base: publicBase,
            path: "pos/bootstrap?location_id=\(encode(locationID))"
        )
        let locations = dictionaries(data["locations"]).compactMap(parseLocation)
        let openShift = dictionaries(data["open_shifts"])
            .first { string($0["location_id"]) == locationID }
            .map(parsePOSShift)
        return POSBootstrap(locations: locations, openShift: openShift)
    }

    func posOpenShift(location: Location) async throws -> POSShift {
        let code = "APP-\(sessionStore.installID.prefix(8).uppercased())"
        let data = try await request(
            base: publicBase,
            path: "pos/shifts/open",
            method: "POST",
            body: [
                "location_id": location.id,
                "register_code": code,
                "register_name": "\(UIDevice.current.model) 移动收银"
            ]
        )
        return parsePOSShift(data)
    }

    func posStandardCatalog(locationID: String) async throws -> POSStandardCatalog {
        let data = try await request(base: publicBase, path: "pos/standard-catalog?location_id=\(encode(locationID))")
        var catalog = try JSONDecoder().decode(POSStandardCatalog.self, from: JSONSerialization.data(withJSONObject: data))
        guard catalog.locationID == locationID else {
            throw APIError.message("标准目录门店不匹配，请重试")
        }
        var categories = Set<String>()
        var skuIDs = Set<String>()
        for index in catalog.groups.indices {
            let group = catalog.groups[index]
            guard !group.categoryCode.isEmpty, !group.categoryName.isEmpty,
                  categories.insert(group.categoryCode).inserted else {
                throw APIError.message("标准目录分类数据无效")
            }
            for tier in group.prices {
                guard !tier.skuID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                      tier.price >= 0, tier.price < Decimal(Int.max / 100),
                      skuIDs.insert(tier.skuID).inserted else {
                    throw APIError.message("标准目录价格档数据无效")
                }
            }
            catalog.groups[index].locationID = locationID
            catalog.groups[index].prices.sort { $0.price == $1.price ? $0.skuID < $1.skuID : $0.price < $1.price }
        }
        return catalog
    }

    func posProducts(locationID: String, query: String = "") async throws -> [POSProduct] {
        try await posCustomProducts(locationID: locationID, query: query).items
    }

    func posCustomProducts(locationID: String, query: String = "", offset: Int = 0) async throws -> POSProductPage {
        var path = "pos/products?location_id=\(encode(locationID))&type=custom&offset=\(offset)"
        if !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            path += "&q=\(encode(query.trimmingCharacters(in: .whitespacesAndNewlines)))"
        }
        let data = try await request(base: publicBase, path: path)
        return POSProductPage(items: dictionaries(data["items"]).map(parsePOSProduct), nextOffset: number(data["next_offset"]))
    }

    func posResolveCode(locationID: String, code: String) async throws -> POSResolvedCode {
        let data = try await request(
            base: publicBase,
            path: "pos/resolve-code?code=\(encode(code.trimmingCharacters(in: .whitespacesAndNewlines)))&location_id=\(encode(locationID))"
        )
        switch string(data["code_type"]) {
        case "product":
            return .product(parsePOSProduct(dictionary(data["product"])))
        case "customer":
            return .customer(phone: string(dictionary(data["customer"])["phone"]))
        case "coupon":
            return .coupon(name: firstNonEmpty(string(dictionary(data["coupon"])["name"]), "优惠券"))
        default:
            throw APIError.message("无法识别该条码")
        }
    }

    func posSearchCustomers(query: String) async throws -> [POSCustomer] {
        let data = try await request(
            base: publicBase,
            path: "pos/customers/search?q=\(encode(query.trimmingCharacters(in: .whitespacesAndNewlines)))"
        )
        return dictionaries(data["items"]).map { item in
            let wallet = dictionary(item["wallet"])
            return POSCustomer(
                id: string(item["id"]),
                phone: string(item["phone"]),
                nickname: string(item["nickname"]),
                points: number(wallet["points"]),
                storeCreditCents: moneyCents(wallet["store_credit"]),
                memberLevel: string(wallet["member_level"])
            )
        }
    }

    func posPreviewDiscount(
        locationID: String,
        cart: POSCart,
        type: String,
        value: Double,
        reason: String,
        customerID: String? = nil,
        pointsToRedeem: Int = 0
    ) async throws -> POSDiscountPreview {
        var body: [String: Any] = [
            "location_id": locationID,
            "items": cart.lines.map { ["sku_id": $0.product.skuID, "quantity": $0.quantity] },
            "discount": ["type": type, "value": value, "reason": reason],
            "points_to_redeem": pointsToRedeem
        ]
        if let customerID { body["customer_id"] = customerID }
        let data = try await request(
            base: publicBase,
            path: "pos/discounts/preview",
            method: "POST",
            body: body
        )
        let points: POSPointsRedemption?
        if let payload = data["points_redemption"] as? [String: Any] {
            points = try JSONDecoder().decode(POSPointsRedemption.self, from: JSONSerialization.data(withJSONObject: payload))
        } else { points = nil }
        return POSDiscountPreview(
            subtotalCents: moneyCents(data["subtotal"]),
            discountCents: moneyCents(data["discount_total"]),
            payableCents: moneyCents(data["payable_total"]),
            requiresAuthorization: boolean(data["requires_authorization"]),
            authorizationRule: string(data["authorization_rule"]),
            pointsRedemption: points
        )
    }

    func posPaymentProfile(locationID: String) async throws -> POSPaymentProfile {
        let data = try await request(
            base: publicBase,
            path: "pos/payment-code?location_id=\(encode(locationID))"
        )
        return POSPaymentProfile(
            ready: boolean(data["ready_for_payment"]),
            subjectName: string(data["subject_name"]),
            merchantIDMasked: string(data["merchant_id_masked"]),
            message: string(data["message"])
        )
    }

    func posStartMicropay(
        locationID: String,
        shiftID: String,
        cart: POSCart,
        provider: String,
        authCode: String,
        customerID: String?,
        discountType: String,
        discountValue: Double,
        discountReason: String
    ) async throws -> POSPaymentAttempt {
        var body = posPaymentBody(
            locationID: locationID,
            shiftID: shiftID,
            cart: cart,
            provider: provider,
            customerID: customerID,
            discountType: discountType,
            discountValue: discountValue,
            discountReason: discountReason
        )
        body["auth_code"] = authCode.trimmingCharacters(in: .whitespacesAndNewlines)
        let data = try await request(base: publicBase, path: "pos/payments/micropay", method: "POST", body: body)
        return parsePOSPaymentAttempt(data)
    }

    func posCreateQRPayment(
        locationID: String,
        shiftID: String,
        cart: POSCart,
        provider: String,
        customerID: String?,
        discountType: String,
        discountValue: Double,
        discountReason: String
    ) async throws -> POSPaymentAttempt {
        let data = try await request(
            base: publicBase,
            path: "pos/payments/qr-order",
            method: "POST",
            body: posPaymentBody(
                locationID: locationID,
                shiftID: shiftID,
                cart: cart,
                provider: provider,
                customerID: customerID,
                discountType: discountType,
                discountValue: discountValue,
                discountReason: discountReason
            )
        )
        return parsePOSPaymentAttempt(data)
    }

    func posPaymentStatus(id: String) async throws -> POSPaymentAttempt {
        parsePOSPaymentAttempt(try await request(base: publicBase, path: "pos/payments/\(encode(id))"))
    }

    func posClosePayment(id: String) async throws -> POSPaymentAttempt {
        parsePOSPaymentAttempt(
            try await request(base: publicBase, path: "pos/payments/\(encode(id))/close", method: "POST", body: [:])
        )
    }

    func posHeldCarts(locationID: String) async throws -> [POSHeldCart] {
        let data = try await request(base: publicBase, path: "pos/carts/held?location_id=\(encode(locationID))")
        return try dictionaries(data["items"]).map { item in
            var held = try JSONDecoder().decode(POSHeldCart.self, from: JSONSerialization.data(withJSONObject: item))
            held.locationID = locationID
            return held
        }
    }

    func posLookupProduct(skuID: String, locationID: String) async throws -> POSProduct {
        let data = try await request(base: publicBase, path: "pos/products/lookup?code=\(encode(skuID))&location_id=\(encode(locationID))")
        let product = parsePOSProduct(data)
        guard product.skuID == skuID, product.locationID == locationID else {
            throw APIError.message("挂单商品与当前门店不匹配")
        }
        return product
    }

    func posCustomerBenefits(customerID: String) async throws -> POSCustomer {
        let data = try await request(base: publicBase, path: "pos/customers/\(encode(customerID))/benefits")
        let member = dictionary(data["customer"])
        let wallet = dictionary(data["wallet"])
        guard string(member["id"]) == customerID else { throw APIError.message("会员信息不匹配") }
        return POSCustomer(id: customerID, phone: string(member["phone"]), nickname: string(member["nickname"]),
                           points: number(wallet["points"]), storeCreditCents: moneyCents(wallet["store_credit"]),
                           memberLevel: string(wallet["member_level"]))
    }

    func posResumeHeldCart(_ held: POSHeldCart) async throws {
        let data = try await request(base: publicBase, path: "pos/carts/\(encode(held.id))/resume", method: "POST", body: [:])
        let resumed = try JSONDecoder().decode(POSHeldCart.self, from: JSONSerialization.data(withJSONObject: data))
        guard string(data["location_id"]) == held.locationID, resumed.id == held.id,
              resumed.customerID == held.customerID,
              resumed.items.sorted(by: { $0.skuID < $1.skuID }) == held.items.sorted(by: { $0.skuID < $1.skuID })
        else { throw APIError.message("挂单内容已变化，请到 ERP 核对") }
    }

    func posHoldCart(shiftID: String, cart: POSCart, customerID: String?,
                     discountType: String = "amount", discountValue: Double = 0, discountReason: String = "",
                     clientOperationID: String? = nil) async throws -> String {
        var body: [String: Any] = [
            "shift_id": shiftID,
            "client_op_id": clientOperationID ?? "ios-pos-hold-\(UUID().uuidString.lowercased())",
            "items": cart.lines.map { ["sku_id": $0.product.skuID, "quantity": $0.quantity] }
        ]
        if let customerID, !customerID.isEmpty { body["customer_id"] = customerID }
        if discountValue > 0 {
            body["discount_snapshot"] = ["type": discountType, "value": discountValue, "reason": discountReason]
        }
        let data = try await request(base: publicBase, path: "pos/carts/hold", method: "POST", body: body)
        return string(data["id"])
    }

    private func posPaymentBody(
        locationID: String,
        shiftID: String,
        cart: POSCart,
        provider: String,
        customerID: String?,
        discountType: String,
        discountValue: Double,
        discountReason: String
    ) -> [String: Any] {
        var body: [String: Any] = [
            "location_id": locationID,
            "shift_id": shiftID,
            "provider": provider,
            "client_op_id": "ios-pos-payment-\(UUID().uuidString.lowercased())",
            "items": cart.lines.map { ["sku_id": $0.product.skuID, "quantity": $0.quantity] }
        ]
        if let customerID, !customerID.isEmpty { body["customer_id"] = customerID }
        if cart.discountCents > 0 {
            body["discount"] = [
                "type": discountType,
                "value": discountValue,
                "reason": discountReason.isEmpty ? "移动收银优惠" : discountReason
            ]
        }
        return body
    }

    private func parsePOSPaymentAttempt(_ data: [String: Any]) -> POSPaymentAttempt {
        POSPaymentAttempt(
            id: string(data["id"]),
            provider: string(data["provider"]),
            mode: POSPaymentMode(rawValue: string(data["mode"])) ?? .merchantScan,
            status: POSPaymentStatus(rawValue: string(data["status"])) ?? .pending,
            amountCents: moneyCents(data["amount"]),
            outTradeNo: string(data["out_trade_no"]),
            providerTransactionID: string(data["provider_transaction_id"]),
            qrContent: firstNonEmpty(string(data["qr_content"]), string(data["code_url"])),
            expiresAt: string(data["expires_at"]),
            message: string(data["message"]),
            receipt: dictionary(data["receipt"]).isEmpty ? nil : parsePOSReceipt(dictionary(data["receipt"]))
        )
    }

    private func parsePOSReceipt(_ data: [String: Any]) -> POSReceipt {
        POSReceipt(
            orderID: firstNonEmpty(string(data["order_id"]), string(data["id"])),
            orderNo: string(data["order_no"]),
            receiptNo: string(data["receipt_no"]),
            totalCents: max(moneyCents(data["total_amount"]), moneyCents(data["total"])),
            paymentProvider: firstNonEmpty(string(data["payment_provider"]), string(data["provider"])),
            providerTransactionID: string(data["provider_transaction_id"]),
            paidAt: string(data["paid_at"]),
            locationName: string(data["location_name"]),
            cashierName: string(data["cashier_name"]),
            subtotalCents: moneyCents(data["subtotal"]),
            discountCents: moneyCents(data["discount_total"]),
            items: dictionaries(data["items"]).map {
                POSReceiptLine(
                    name: string($0["name"]),
                    skuCode: string($0["sku_code"]),
                    quantity: number($0["quantity"]) ?? 1,
                    unitPriceCents: moneyCents($0["unit_price"]),
                    lineTotalCents: moneyCents($0["line_total"])
                )
            },
            customerName: string(data["customer_name"])
        )
    }

    var posUserID: String { sessionStore.cachedUser?.id ?? "" }

    func posCashSaleAttempt(locationID: String, shiftID: String, cart: POSCart, customerID: String?,
                           discountType: String, discountValue: Double, discountReason: String,
                           pointsToRedeem: Int, operationID: String) throws -> POSCashSaleAttempt {
        let body = posSaleBody(shiftID: shiftID, cart: cart, provider: "cash", transactionID: "",
                              customerID: customerID, discountType: discountType, discountValue: discountValue,
                              discountReason: discountReason, pointsToRedeem: pointsToRedeem, clientOperationID: operationID)
        return try POSCashSaleAttempt(userID: posUserID, locationID: locationID, body: body, cart: cart)
    }

    func posRetryCashSale(_ attempt: POSCashSaleAttempt) async throws -> POSReceipt {
        guard posUserID == attempt.userID else { throw APIError.message("请使用原收银员账号确认现金收款") }
        let data = try await request(base: publicBase, path: "pos/sales", method: "POST", body: attempt.validatedBody())
        guard posUserID == attempt.userID else { throw CancellationError() }
        return try posConfirmedSaleReceipt(data, provider: "cash", subtotalCents: attempt.subtotalCents,
                                           discountCents: attempt.discountCents)
    }

    func posReconcileOrCancelCashSale(_ attempt: POSCashSaleAttempt) async throws -> POSCashRecoveryResult {
        guard posUserID == attempt.userID else { throw APIError.message("请使用原收银员账号核对现金收款") }
        let original = try attempt.validatedBody()
        let data = try await request(base: publicBase, path: "pos/sales/recover/cancel", method: "POST",
            body: ["shift_id": string(original["shift_id"]), "client_op_id": attempt.operationID])
        guard posUserID == attempt.userID, string(data["client_op_id"]) == attempt.operationID else {
            throw APIError.message("原收款核对结果不匹配，请保留保护记录")
        }
        if string(data["status"]) == "completed" {
            return .completed(try posConfirmedSaleReceipt(dictionary(data["order"]), provider: "cash",
                subtotalCents: attempt.subtotalCents, discountCents: attempt.discountCents))
        }
        guard string(data["status"]) == "cancelled", data["order"] is NSNull else {
            throw APIError.message("服务端尚未确认原单取消，请保留保护记录")
        }
        return .cancelled
    }

    private func posSaleBody(shiftID: String, cart: POSCart, provider: String, transactionID: String,
                             customerID: String?, discountType: String, discountValue: Double,
                             discountReason: String, pointsToRedeem: Int, clientOperationID: String?) -> [String: Any] {
        var tender: [String: Any] = [
            "provider": provider,
            "amount": Double(cart.payableCents) / 100
        ]
        if provider != "cash" { tender["provider_transaction_id"] = transactionID }
        var body: [String: Any] = [
            "shift_id": shiftID,
            "client_op_id": clientOperationID ?? "ios-pos-sale-\(UUID().uuidString.lowercased())",
            "items": cart.lines.map { ["sku_id": $0.product.skuID, "quantity": $0.quantity] },
            "tenders": [tender]
        ]
        if pointsToRedeem > 0 { body["points_to_redeem"] = pointsToRedeem }
        if let customerID, !customerID.isEmpty { body["customer_id"] = customerID }
        if discountValue > 0 {
            body["discount"] = [
                "type": discountType,
                "value": discountValue,
                "reason": discountReason.isEmpty ? "移动收银优惠" : discountReason
            ]
        }
        return body
    }

    private func posConfirmedSaleReceipt(_ data: [String: Any], provider: String, subtotalCents: Int, discountCents: Int) throws -> POSReceipt {
        let orderID = firstNonEmpty(data["order_id"] as? String ?? "", data["id"] as? String ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !orderID.isEmpty else { throw APIError.message("收款响应缺少订单号，结果尚未确认，请重试原单") }
        return POSReceipt(
            orderID: orderID,
            orderNo: string(data["order_no"]),
            receiptNo: string(data["receipt_no"]),
            totalCents: data["total_amount"] == nil ? subtotalCents - discountCents : moneyCents(data["total_amount"]),
            paymentProvider: provider,
            subtotalCents: data["subtotal"] == nil ? subtotalCents : moneyCents(data["subtotal"]),
            discountCents: data["discount_total"] == nil ? discountCents : moneyCents(data["discount_total"])
        )
    }

    func posCashDrawer(shiftID: String) async throws -> POSCashDrawer {
        let data = try await request(
            base: publicBase,
            path: "pos/cash-movements?shift_id=\(encode(shiftID))"
        )
        return POSCashDrawer(
            balanceCents: moneyCents(data["balance"]),
            movements: dictionaries(data["items"]).map { item in
                POSCashMovement(
                    id: string(item["id"]),
                    type: string(item["type"]),
                    amountCents: moneyCents(item["amount"]),
                    reason: string(item["reason"]),
                    createdAt: string(item["created_at"])
                )
            }
        )
    }

    private func saveBootstrap(_ data: [String: Any]) throws -> BootstrapPayload {
        let device = dictionary(data["device"])
        let deviceToken = string(data["device_token"]).isEmpty ? string(device["device_token"]) : string(data["device_token"])
        let sessionToken = string(data["session_token"]).isEmpty ? string(data["access_token"]) : string(data["session_token"])
        guard !deviceToken.isEmpty, !sessionToken.isEmpty else {
            throw APIError.message("ERP 登录成功但没有返回设备凭证")
        }
        sessionStore.deviceToken = deviceToken
        sessionStore.sessionToken = sessionToken
        sessionStore.accessToken = string(data["access_token"])
        sessionStore.refreshToken = string(data["refresh_token"])

        let user = ERPUser.apiPayload(data)
        sessionStore.cachedUser = user
        let locations = dictionaries(data["locations"]).compactMap(parseLocation)
        let selected = parseLocation(dictionary(device["location"]))
            ?? {
                let locationID = string(device["location_id"])
                guard !locationID.isEmpty else { return nil }
                return Location(
                    id: locationID,
                    name: string(device["location_name"]),
                    kind: string(device["location_kind"])
                )
            }()
        if let selected { sessionStore.selectedLocationID = selected.id }
        return BootstrapPayload(user: user, locations: locations, selectedLocation: selected)
    }

    private func request(
        base: URL? = nil,
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        authenticated: Bool = true,
        deviceAuthenticated: Bool = false,
        clientOperationID: String? = nil,
        retryOnUnauthorized: Bool = true,
        retryOnTransientGateway: Bool = false
    ) async throws -> [String: Any] {
        guard let url = URL(string: path, relativeTo: base ?? handheldBase) else {
            throw APIError.message("请求地址无效")
        }
        var urlRequest = URLRequest(url: url)
        urlRequest.timeoutInterval = APIRequestTimeoutPolicy.value(path: path)
        urlRequest.httpMethod = method
        urlRequest.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            urlRequest.httpBody = try JSONSerialization.data(withJSONObject: body)
            urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        let authMode: APIRequestAuthMode = authenticated ? .session : (deviceAuthenticated ? .device : .none)
        let authHeaders = APIRequestAuthHeaders.values(
            mode: authMode,
            deviceToken: sessionStore.deviceToken,
            sessionToken: sessionStore.sessionToken,
            accessToken: sessionStore.accessToken
        )
        let sentSessionToken = authHeaders["X-Session-Token"] ?? ""
        let sentRefreshToken = sessionStore.refreshToken
        let sentUserID = sessionStore.cachedUser?.id
        for (name, value) in authHeaders {
            urlRequest.setValue(value, forHTTPHeaderField: name)
        }
        if let clientOperationID {
            urlRequest.setValue(clientOperationID, forHTTPHeaderField: "ClientOpId")
        }
        let (raw, response) = try await session.data(for: urlRequest)
        try Task.checkCancellation()
        if authenticated, sessionStore.cachedUser?.id != sentUserID {
            throw CancellationError()
        }
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        if APITransientRetryPolicy.shouldRetry(
            status: status,
            path: path,
            retryAvailable: retryOnTransientGateway
        ) {
            try await Task.sleep(for: .milliseconds(500))
            return try await request(
                base: base,
                path: path,
                method: method,
                body: body,
                authenticated: authenticated,
                deviceAuthenticated: deviceAuthenticated,
                clientOperationID: clientOperationID,
                retryOnUnauthorized: retryOnUnauthorized,
                retryOnTransientGateway: false
            )
        }
        let json = try? JSONSerialization.jsonObject(with: raw) as? [String: Any]
        if status == 401, authenticated {
            if retryOnUnauthorized && (!sentRefreshToken.isEmpty || currentSessionToken != sentSessionToken) {
                do {
                    if currentSessionToken == sentSessionToken && !sentRefreshToken.isEmpty {
                        try await refreshCoordinator.refresh(key: sentRefreshToken) { [self] in
                            guard currentSessionToken == sentSessionToken,
                                  sessionStore.refreshToken == sentRefreshToken else { return }
                            let refresh = try await request(
                                path: "auth/refresh", method: "POST",
                                body: ["refresh_token": sentRefreshToken],
                                authenticated: false, deviceAuthenticated: true,
                                retryOnUnauthorized: false
                            )
                            let accessToken = string(refresh["access_token"])
                            guard !accessToken.isEmpty else {
                                throw APIError.message("ERP 续期响应不完整，登录凭证已保留，请重试")
                            }
                            // Ignore a late response after logout or another successful login.
                            guard currentSessionToken == sentSessionToken,
                                  sessionStore.refreshToken == sentRefreshToken else { return }
                            sessionStore.accessToken = accessToken
                            sessionStore.sessionToken = firstNonEmpty(string(refresh["session_token"]), accessToken)
                            let nextRefreshToken = string(refresh["refresh_token"])
                            if !nextRefreshToken.isEmpty { sessionStore.refreshToken = nextRefreshToken }
                        }
                    }
                } catch {
                    guard currentSessionToken == sentSessionToken,
                          sessionStore.cachedUser?.id == sentUserID else { throw CancellationError() }
                    if SessionRestorePolicy.shouldClearAuthentication(for: error) {
                        expireAuthentication(ifTokenMatches: sentSessionToken)
                    }
                    throw error
                }
                try Task.checkCancellation()
                guard sessionStore.cachedUser?.id == sentUserID else { throw CancellationError() }
                // Business errors on this retry are not refresh failures.
                return try await request(
                    base: base,
                    path: path,
                    method: method,
                    body: body,
                    authenticated: authenticated,
                    deviceAuthenticated: deviceAuthenticated,
                    clientOperationID: clientOperationID,
                    retryOnUnauthorized: false,
                    retryOnTransientGateway: retryOnTransientGateway
                )
            }
            guard currentSessionToken == sentSessionToken else {
                throw APIError.message("登录状态已更新，请重试当前操作")
            }
            expireAuthentication(ifTokenMatches: sentSessionToken)
            throw APIError.authenticationExpired("登录已过期，请重新登录")
        }
        if status == 401, path == "auth/refresh" {
            throw APIError.authenticationExpired("登录已过期，请重新登录")
        }
        if status == 403, path.hasPrefix("products?") {
            throw ProductAccessError()
        }
        if status == 403, path == "locations" { throw LocationAccessError() }
        if status == 403, path.hasPrefix("support/conversations") { throw ServiceAccessError() }
        guard let json else {
            let message: String
            switch status {
            case 404:
                message = "ERP 接口未发布或地址未命中"
            case 502, 503, 504:
                message = "ERP 服务正在重启，请稍后再试（\(status)）"
            default:
                message = "ERP 返回了非 JSON 响应（HTTP \(status)）"
            }
            throw APIError.message(message)
        }
        if ["pos/sales", "pos/sales/recover/cancel"].contains(path), (200..<300).contains(status) {
            guard json["ok"] as? Bool == true, json["data"] is [String: Any] else {
                throw APIError.message("现金收款响应格式不完整，结果尚未确认，请保留原单核对")
            }
        }
        let ok = json["ok"] as? Bool ?? (200..<300).contains(status)
        if !ok || !(200..<300).contains(status) {
            let message = string(json["message"]).isEmpty
                    ? (string(json["error"]).isEmpty ? "请求失败（\(status)）" : string(json["error"]))
                    : string(json["message"])
            if path == "items/smart-create", [400, 422].contains(status) {
                throw APIError.listingRejected(message)
            }
            if path == "custom-transfers", (400..<500).contains(status) {
                throw CustomTransferRejection(message: message)
            }
            if path == "pos/sales", json["ok"] as? Bool == false,
               [400, 403, 404, 409, 422].contains(status), !message.contains("idempotency_conflict") {
                throw POSCashSaleRejected(message: message)
            }
            if path.hasPrefix("items/"), ["PATCH", "DELETE"].contains(method), (400..<500).contains(status) {
                throw APIError.productMutationRejected(code: string(json["code"]), message: message)
            }
            throw APIError.message(message)
        }
        return dictionary(json["data"]).isEmpty ? json : dictionary(json["data"])
    }

    private var currentSessionToken: String {
        firstNonEmpty(sessionStore.accessToken, sessionStore.sessionToken)
    }

    private func expireAuthentication(ifTokenMatches token: String) {
        guard currentSessionToken == token else { return }
        sessionStore.clearAuth()
        NotificationCenter.default.post(name: .erpAuthenticationExpired, object: sessionStore)
    }

    private func parseLocation(_ json: [String: Any]) -> Location? {
        let id = string(json["id"])
        let name = string(json["name"])
        guard !id.isEmpty, !name.isEmpty else { return nil }
        if let isActive = json["is_active"] as? Bool, !isActive { return nil }
        let normalizedName = name
            .lowercased()
            .replacingOccurrences(of: "-", with: " ")
            .replacingOccurrences(of: "·", with: " ")
            .split(whereSeparator: \.isWhitespace)
            .joined(separator: " ")
        if ["boomer off vintage", "boomer off", "vintage"].contains(normalizedName) {
            return nil
        }
        return Location(id: id, name: name, kind: string(json["kind"]))
    }

    private func parseProduct(_ json: [String: Any]) -> Product {
        let status = string(json["listing_status"]).isEmpty ? "selling" : string(json["listing_status"])
        let imageItems = dictionaries(json["images"])
        let images = imageItems.compactMap {
            firstNonEmpty(string($0["read_url"]), string($0["image_url"]), string($0["signed_url"])).isEmpty
                ? nil
                : firstNonEmpty(string($0["read_url"]), string($0["image_url"]), string($0["signed_url"]))
        }
        let imageURL = firstNonEmpty(string(json["image_url"]), images.first ?? "")
        return Product(
            id: string(json["id"]).isEmpty ? string(json["sku_id"]) : string(json["id"]),
            name: string(json["name"]),
            skuCode: string(json["sku_code"]),
            barcode: string(json["barcode"]),
            category: string(json["category"]),
            productType: string(json["product_type"]).isEmpty ? string(json["type"]) : string(json["product_type"]),
            imageURL: imageURL,
            price: decimal(json["price"]) ?? decimal(json["price_tier"]) ?? 0,
            stockQty: number(json["total_stock_qty"]) ?? number(json["stock_qty"]) ?? number(json["stock"]) ?? 0,
            conditionGrade: string(json["condition_grade"]).isEmpty ? string(json["grade"]) : string(json["condition_grade"]),
            listingStatus: status,
            statusLabel: string(json["status_label"]).isEmpty ? statusTitle(status) : string(json["status_label"]),
            editable: json["editable"] as? Bool ?? true,
            canRestock: json["can_restock"] as? Bool ?? false,
            images: images.isEmpty ? (imageURL.isEmpty ? [] : [imageURL]) : images,
            description: firstNonEmpty(string(json["notes"]), string(json["description"]), string(json["detail"])),
            brand: string(json["brand"]),
            era: string(json["era"]),
            ipName: string(json["ip_name"]),
            tags: strings(json["tags"]),
            isUnlimitedStock: boolean(json["is_unlimited_stock"]),
            imageProcessingStatus: firstNonEmpty(string(json["image_processing_status"]), "idle"),
            locationStocks: ProductLocationStock.decode(dictionaries(json["stocks"])),
            canEdit: json["can_edit"] as? Bool,
            canDelete: json["can_delete"] as? Bool,
            updatedAt: json["updated_at"] as? String,
            imageReferences: ProductImageReference.decode(json),
            fankuangOverride: json["fankuang_override"] as? Bool,
            fankuangMembership: json["in_fankuang"] as? Bool
        )
    }

    private func parsePOSProduct(_ json: [String: Any]) -> POSProduct {
        POSProduct(
            skuID: firstNonEmpty(string(json["sku_id"]), string(json["id"])),
            name: string(json["name"]),
            unitPriceCents: moneyCents(json["unit_price"]),
            availableQuantity: number(json["available_qty"]) ?? 0,
            productType: POSProductType(rawValue: string(json["product_type"])) ?? .custom,
            skuCode: string(json["sku_code"]),
            barcode: string(json["barcode"]),
            epc: string(json["epc"]),
            conditionGrade: string(json["condition_grade"]),
            imageURL: string(json["image_url"]),
            locationID: string(json["location_id"]),
            saleOwnership: firstNonEmpty(string(json["sale_ownership"]), "owned"),
            discountEligible: json["discount_eligible"] == nil || boolean(json["discount_eligible"]),
            isUnlimitedStock: boolean(json["is_unlimited_stock"])
        )
    }

    private func parsePOSShift(_ json: [String: Any]) -> POSShift {
        let register = dictionary(json["register"])
        return POSShift(
            id: string(json["id"]),
            locationID: string(json["location_id"]),
            status: firstNonEmpty(string(json["status"]), "open"),
            registerName: firstNonEmpty(string(register["name"]), "移动收银")
        )
    }

    private func parseTransfer(_ json: [String: Any]) -> TransferRecord {
        TransferRecord(
            id: string(json["id"]),
            code: string(json["code"]),
            status: string(json["status"]),
            qty: number(json["qty"]) ?? 0,
            fromLocationID: string(json["from_location_id"]),
            toLocationID: string(json["to_location_id"]),
            createdAt: string(json["created_at"]),
            notes: string(json["notes"])
        )
    }

    private func parseStocktake(_ json: [String: Any]) -> StocktakeRecord {
        StocktakeRecord(
            id: string(json["id"]),
            code: string(json["code"]),
            status: string(json["status"]),
            openedAt: string(json["opened_at"]),
            submittedAt: string(json["submitted_at"]),
            notes: string(json["notes"])
        )
    }

    private func parseLabelTemplate(_ json: [String: Any], defaultID: String) -> LabelTemplate {
        let id = string(json["id"]).isEmpty ? "default" : string(json["id"])
        let printType = PrintTemplateType(rawValue: string(json["print_type"])) ?? .label
        let parsedElements = dictionaries(json["elements"]).map { element in
            let rawType = string(element["type"]).uppercased()
            let elementType: LabelElementType = rawType == "ITEM_LINES"
                ? .description
                : (LabelElementType(rawValue: rawType) ?? .customText)
            return LabelElement(
                id: string(element["id"]).isEmpty ? UUID().uuidString : string(element["id"]),
                type: elementType,
                x: decimal(element["x"]) ?? 0,
                y: decimal(element["y"]) ?? 0,
                width: decimal(element["width"]) ?? 80,
                height: decimal(element["height"]) ?? 24,
                textSize: decimal(element["textSize"]) ?? decimal(element["text_size"]) ?? 16,
                bold: boolean(element["bold"]),
                enabled: element["enabled"] == nil ? true : boolean(element["enabled"]),
                customText: {
                    let value = firstNonEmpty(
                        string(element["customText"]),
                        string(element["custom_text"])
                    )
                    return elementType == .logo && value.isEmpty
                        ? LabelLogoPreset.horizontal.rawValue
                        : value
                }(),
                alignment: string(element["align"]).isEmpty ? "center" : string(element["align"]),
                fontFamily: firstNonEmpty(string(element["fontFamily"]), string(element["font_family"]), "sans"),
                italic: boolean(element["italic"]),
                underline: boolean(element["underline"]),
                boxed: boolean(element["boxed"])
            )
        }
        let elements = parsedElements.isEmpty
            ? (printType == .receipt ? LabelTemplate.localReceipt.elements : LabelTemplate.localDefault.elements)
            : parsedElements
        return LabelTemplate(
            id: id,
            name: firstNonEmpty(string(json["name"]), string(json["templateName"]), "默认模板"),
            widthMM: number(json["width_mm"]) ?? number(json["widthMm"]) ?? 53,
            heightMM: number(json["height_mm"]) ?? number(json["heightMm"]) ?? 35,
            elements: elements,
            isDefault: boolean(json["is_default"]) || id == defaultID,
            version: number(json["version"]) ?? 1,
            printType: printType
        )
    }

    private func labelTemplateBody(_ template: LabelTemplate) -> [String: Any] {
        [
            "name": template.name,
            "print_type": template.printType.rawValue,
            "width_mm": template.widthMM,
            "height_mm": template.heightMM,
            "elements": template.elements.map {
                [
                    "id": $0.id,
                    "type": $0.type.rawValue,
                    "x": $0.x,
                    "y": $0.y,
                    "width": $0.width,
                    "height": $0.height,
                    "textSize": $0.textSize,
                    "bold": $0.bold,
                    "enabled": $0.enabled,
                    "customText": $0.customText,
                    "align": $0.alignment,
                    "fontFamily": $0.fontFamily,
                    "italic": $0.italic,
                    "underline": $0.underline,
                    "boxed": $0.boxed
                ] as [String: Any]
            }
        ]
    }

    private func parseParcelRow(_ json: [String: Any]) -> ParcelRow {
        let firstItem = dictionaries(json["items"]).first ?? dictionary(json["first_item"])
        let itemName = firstNonEmpty(
            string(json["first_item_name"]),
            string(firstItem["item_title_cn"]),
            string(firstItem["item_title"]),
            string(firstItem["name"]),
            string(firstItem["title"])
        )
        return ParcelRow(
            id: firstNonEmpty(string(json["id"]), string(json["parcel_id"])),
            trackingNo: firstNonEmpty(string(json["tracking_no"]), string(json["international_tracking_no"])),
            sourceOrderNo: firstNonEmpty(string(json["source_order_no"]), string(json["order_no"])),
            firstItemName: itemName.isEmpty ? "未命名商品" : itemName,
            firstImageURL: firstNonEmpty(extractImageURL(json), extractImageURL(firstItem)),
            seller: string(json["seller"]),
            warehouseLocation: firstNonEmpty(string(json["warehouse_location"]), string(json["location"])),
            status: string(json["status"]),
            isProblem: boolean(json["is_problem"]),
            grandTotalCNY: firstDecimal(json, keys: ["grand_total_cny", "total_cny", "landed_cny"]),
            averageUnitCNY: decimal(json["avg_unit_cny"]),
            itemCount: number(json["item_count"]) ?? dictionaries(json["items"]).count,
            totalQuantity: number(json["total_qty"]) ?? number(json["quantity"]) ?? 0,
            purchasedAt: string(json["purchased_at"]),
            paidAt: string(json["paid_at"]),
            receivedAt: string(json["received_at"]),
            createdAt: firstNonEmpty(string(json["created_at"]), string(json["added_at"])),
            note: firstNonEmpty(string(json["note"]), string(json["remarks"])),
            internationalFreightCNY: firstDecimal(json, keys: ["international_freight_cny", "freight_cny", "shipping_cny"]),
            tariffCNY: firstDecimal(json, keys: ["tariff_cny", "duty_cny"]),
            goodsTotalCNY: firstDecimal(json, keys: ["goods_total_cny", "item_total_cny"]),
            weight: firstNonEmpty(string(json["weight"]), string(json["weight_g"])),
            systemCode: firstNonEmpty(string(json["system_code"]), string(json["code"]))
        )
    }

    private func parseParcelItem(_ json: [String: Any], fallbackParcelID: String = "") -> ParcelItem {
        let landed = dictionary(json["landed"])
        let quantity = max(number(json["quantity"]) ?? number(json["qty"]) ?? 1, 1)
        let itemTotal = firstDecimal(json, keys: ["item_total_cny", "total_cny", "subtotal_cny"])
        let name = firstNonEmpty(
            string(json["item_title_cn"]),
            string(json["cn_name"]),
            string(json["name"]),
            string(json["item_title"]),
            string(json["title"])
        )
        return ParcelItem(
            id: firstNonEmpty(string(json["id"]), string(json["item_id"])),
            parcelID: firstNonEmpty(string(json["parcel_id"]), fallbackParcelID),
            name: name.isEmpty ? "未命名商品" : name,
            originalName: firstNonEmpty(
                string(json["item_title"]),
                string(json["original_name"]),
                string(json["original_title"]),
                string(json["title_original"])
            ),
            imageURL: extractImageURL(json),
            subOrderNo: firstNonEmpty(string(json["sub_order_no"]), string(json["source_item_no"])),
            systemCode: firstNonEmpty(string(json["system_code"]), string(json["sku_code"]), string(json["code"])),
            addedBy: firstNonEmpty(string(json["added_by"]), string(json["created_by"]), string(json["parcel_created_by"])),
            addedAt: firstNonEmpty(string(json["added_at"]), string(json["created_at"])),
            quantity: quantity,
            itemTotalCNY: itemTotal,
            averageCNY: decimal(json["avg_cny"]) ?? itemTotal.map { $0 / Double(quantity) },
            landedCNY: decimal(json["landed_cny"]) ?? decimal(landed["landed_cny"]),
            piecePriceCNY: decimal(json["piece_price_cny"]),
            piecePriceJPY: decimal(json["piece_price_jpy"]),
            packPieces: number(json["pack_pieces"]),
            packPiecesSource: string(json["pack_pieces_source"]),
            packUnitNote: firstNonEmpty(string(json["pack_unit_note"]), string(json["unit"])),
            jpySubtotal: firstDecimal(json, keys: ["jpy_subtotal", "subtotal_jpy", "item_total_jpy"]),
            unitPriceJPY: firstDecimal(json, keys: ["unit_price_jpy", "price_jpy"]),
            weight: firstNonEmpty(string(json["weight"]), string(json["weight_g"])),
            exchangeRate: decimal(json["exchange_rate"]) ?? decimal(landed["exchange_rate"]),
            serviceFeeCNY: decimal(json["service_fee_cny"]) ?? decimal(landed["service_fee_cny"]),
            domesticShippingCNY: decimal(json["domestic_shipping_cny"]) ?? decimal(landed["domestic_shipping_cny"]),
            shippingAdjustmentCNY: decimal(json["shipping_adjustment_cny"]) ?? decimal(landed["shipping_adjustment_cny"]),
            tariffCategory: firstNonEmpty(string(json["tariff_category"]), string(landed["tariff_category"])),
            taxRate: decimal(json["tax_rate"]) ?? decimal(landed["tax_rate"]),
            tariffJPY: decimal(json["tariff_jpy"]) ?? decimal(landed["tariff_jpy"]),
            allocatedFreightCNY: firstDecimal(json, keys: ["allocated_freight_cny"])
                ?? firstDecimal(landed, keys: ["allocated_freight_cny", "freight_share_cny"]),
            tariffCNY: decimal(json["tariff_cny"]) ?? decimal(landed["tariff_cny"]),
            paymentMethod: firstNonEmpty(string(json["payment_method"]), string(json["pay_method"])),
            paidAt: firstNonEmpty(string(json["paid_at"]), string(json["payment_at"]), string(json["pay_at"])),
            merchantOrderNo: firstNonEmpty(string(json["merchant_order_no"]), string(json["seller_order_no"])),
            platform: firstNonEmpty(string(json["platform"]), string(json["source_platform"])),
            condition: firstNonEmpty(string(json["condition"]), string(json["condition_grade"])),
            extraService: firstNonEmpty(string(json["extra_service"]), string(json["additional_service"]), string(json["addon_service"])),
            note: firstNonEmpty(string(json["note"]), string(json["notes"]), string(json["remarks"]))
        )
    }

    private func statusTitle(_ value: String) -> String {
        switch value {
        case "sold_out": "已售罄"
        case "in_warehouse": "仓库中"
        default: "销售中"
        }
    }

    private func dictionary(_ value: Any?) -> [String: Any] { value as? [String: Any] ?? [:] }
    private func dictionaries(_ value: Any?) -> [[String: Any]] { value as? [[String: Any]] ?? [] }
    private func string(_ value: Any?) -> String {
        if let value = value as? String { return value }
        if let value = value as? NSNumber { return value.stringValue }
        return ""
    }
    private func strings(_ value: Any?) -> [String] { value as? [String] ?? [] }
    private func boolean(_ value: Any?) -> Bool {
        if let value = value as? Bool { return value }
        if let value = value as? NSNumber { return value.boolValue }
        if let value = value as? String { return ["1", "true", "yes"].contains(value.lowercased()) }
        return false
    }
    private func number(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? String { return Int(value) }
        return nil
    }
    private func decimal(_ value: Any?) -> Double? {
        if let value = value as? Double { return value }
        if let value = value as? NSNumber { return value.doubleValue }
        if let value = value as? String { return Double(value) }
        return nil
    }
    private func moneyCents(_ value: Any?) -> Int {
        Int(((decimal(value) ?? 0) * 100).rounded())
    }
    private func encode(_ value: String) -> String {
        value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? value
    }
    private func firstNonEmpty(_ values: String...) -> String {
        values.first(where: { !$0.isEmpty }) ?? ""
    }
    private func firstDecimal(_ json: [String: Any], keys: [String]) -> Double? {
        keys.lazy.compactMap { self.decimal(json[$0]) }.first
    }
    private func extractImageURL(_ json: [String: Any]) -> String {
        let firstImage = dictionaries(json["images"]).first ?? [:]
        let image = dictionary(json["image"])
        let cover = dictionary(json["cover"])
        return firstNonEmpty(
            string(json["image_url"]),
            string(json["imageUrl"]),
            string(json["item_image_url"]),
            string(json["first_image_url"]),
            string(json["thumbnail_url"]),
            string(json["thumb_url"]),
            string(json["main_image_url"]),
            string(json["cover_image_url"]),
            string(firstImage["image_url"]),
            string(firstImage["url"]),
            string(image["image_url"]),
            string(image["url"]),
            string(cover["image_url"]),
            string(cover["url"])
        )
    }
}
