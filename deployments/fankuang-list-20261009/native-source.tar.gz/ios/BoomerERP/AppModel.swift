import CoreImage
import CoreImage.CIFilterBuiltins
import Foundation
import ImageIO
import SwiftUI
import UIKit
import Vision

enum HQToolVisibility {
    static func canShow(roles: [String], locationKind: String?) -> Bool {
        let hasHQRole = roles.contains("super_admin") || roles.contains("hq_operator")
        return hasHQRole && locationKind == "warehouse"
    }
}

enum ListingCapturePlan {
    static let maximumImages = 6
    static let minimumRequiredImages = 1
    private static let angles = ["正面", "侧面", "背面", "细节", "底部/标签", "瑕疵特写"]

    static func canProcess(imageCount: Int) -> Bool {
        (minimumRequiredImages ... maximumImages).contains(imageCount)
    }

    static func angleName(for index: Int) -> String {
        guard angles.indices.contains(index) else { return "补充角度" }
        return angles[index]
    }
}

struct ListingImageReference: Equatable {
    let bucket: String
    let storagePath: String
}

enum ListingUploadPlan {
    static func rawImageReferences(paths: [String]) -> [ListingImageReference] {
        paths.map { ListingImageReference(bucket: "sku-raw", storagePath: $0) }
    }

    static func canCreate(rawPathCount: Int, imageCount: Int) -> Bool {
        imageCount >= ListingCapturePlan.minimumRequiredImages && rawPathCount == imageCount
    }
}

enum ListingAutoPrintAction: Equatable {
    case printLabel
    case connectThenPrint
}

enum ListingAutoPrintPolicy {
    static func action(isPrinterConnected: Bool) -> ListingAutoPrintAction {
        isPrinterConnected ? .printLabel : .connectThenPrint
    }
}

enum ListingImageProcessor {
    static func recognitionImageData(_ data: Data) throws -> Data {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let bitmap = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 1280,
              ] as CFDictionary),
              let jpeg = UIImage(cgImage: bitmap).jpegData(compressionQuality: 0.8)
        else { throw APIError.message("照片无法读取，请重新拍摄") }
        return jpeg
    }

    static func normalizedUploadImage(
        _ image: UIImage,
        maxDimension: CGFloat = 2048
    ) -> UIImage {
        let orientedSize: CGSize
        if let cgImage = image.cgImage {
            switch image.imageOrientation {
            case .left, .leftMirrored, .right, .rightMirrored:
                orientedSize = CGSize(width: cgImage.height, height: cgImage.width)
            default:
                orientedSize = CGSize(width: cgImage.width, height: cgImage.height)
            }
        } else {
            orientedSize = image.size
        }

        let longestSide = max(orientedSize.width, orientedSize.height)
        let scale = longestSide > maxDimension ? maxDimension / longestSide : 1
        let targetSize = CGSize(
            width: max(1, (orientedSize.width * scale).rounded()),
            height: max(1, (orientedSize.height * scale).rounded())
        )
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true
        return UIGraphicsImageRenderer(size: targetSize, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: targetSize))
        }
    }

    static func prepareAll(
        _ images: [Data],
        transform: (Data) async throws -> Data
    ) async rethrows -> [Data] {
        var results: [Data] = []
        results.reserveCapacity(images.count)
        for image in images {
            results.append(try await transform(image))
        }
        return results
    }

    static func preparedListingImageData(
        _ data: Data,
        outputSide: CGFloat = 1024
    ) throws -> Data {
        guard let input = UIImage(data: data) else {
            throw APIError.message("商品图片无法读取")
        }
        let source = normalizedUploadImage(input, maxDimension: 2048)
        let prepared = removeBackgroundPreservingProduct(
            source,
            outputSide: outputSide
        )
        guard let jpeg = prepared.jpegData(compressionQuality: 0.92) else {
            throw APIError.message("商品图片处理失败")
        }
        return jpeg
    }

    private static func removeBackgroundPreservingProduct(
        _ source: UIImage,
        outputSide: CGFloat
    ) -> UIImage {
        guard let cgImage = source.cgImage else {
            return aspectFitOnCleanCanvas(source, outputSide: outputSide)
        }

        do {
            let request = VNGenerateForegroundInstanceMaskRequest()
            let handler = VNImageRequestHandler(cgImage: cgImage)
            try handler.perform([request])
            guard let observation = request.results?.first,
                  !observation.allInstances.isEmpty
            else {
                return aspectFitOnCleanCanvas(source, outputSide: outputSide)
            }

            let maskBuffer = try observation.generateScaledMaskForImage(
                forInstances: observation.allInstances,
                from: handler
            )
            let sourceImage = CIImage(cgImage: cgImage)
            var maskImage = CIImage(cvPixelBuffer: maskBuffer)
            if maskImage.extent.size != sourceImage.extent.size {
                let xScale = sourceImage.extent.width / maskImage.extent.width
                let yScale = sourceImage.extent.height / maskImage.extent.height
                maskImage = maskImage.transformed(
                    by: CGAffineTransform(scaleX: xScale, y: yScale)
                )
            }

            let morphology = CIFilter.morphologyMaximum()
            morphology.inputImage = maskImage
            morphology.radius = 2

            let background = CIImage(
                color: CIColor(red: 0.965, green: 0.965, blue: 0.965)
            ).cropped(to: sourceImage.extent)
            let blend = CIFilter.blendWithMask()
            blend.inputImage = sourceImage
            blend.backgroundImage = background
            blend.maskImage = morphology.outputImage?.cropped(to: sourceImage.extent)

            let context = CIContext(options: [.useSoftwareRenderer: false])
            guard let output = blend.outputImage,
                  let rendered = context.createCGImage(output, from: sourceImage.extent)
            else {
                return aspectFitOnCleanCanvas(source, outputSide: outputSide)
            }
            return aspectFitOnCleanCanvas(
                UIImage(cgImage: rendered),
                outputSide: outputSide
            )
        } catch {
            return aspectFitOnCleanCanvas(source, outputSide: outputSide)
        }
    }

    private static func aspectFitOnCleanCanvas(
        _ image: UIImage,
        outputSide: CGFloat
    ) -> UIImage {
        let canvasSize = CGSize(width: outputSide, height: outputSide)
        let availableSide = outputSide * 0.88
        let scale = min(
            availableSide / max(image.size.width, 1),
            availableSide / max(image.size.height, 1)
        )
        let drawSize = CGSize(
            width: image.size.width * scale,
            height: image.size.height * scale
        )
        let drawRect = CGRect(
            x: (outputSide - drawSize.width) / 2,
            y: (outputSide - drawSize.height) / 2,
            width: drawSize.width,
            height: drawSize.height
        )
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true
        return UIGraphicsImageRenderer(size: canvasSize, format: format).image { context in
            UIColor(white: 0.965, alpha: 1).setFill()
            context.fill(CGRect(origin: .zero, size: canvasSize))
            image.draw(in: drawRect)
        }
    }
}

@MainActor
final class AppModel: ObservableObject {
    enum RootState {
        case login
        case location
        case app
    }

    @Published var root: RootState
    @Published var selectedTab = 0
    @Published var secondTabMode: SecondTabMode = .products
    @Published var busy = false
    @Published var errorMessage = ""
    @Published var toastMessage = ""

    @Published var phone = ""
    @Published var otp = ""
    @Published var otpSeconds = 0
    @Published var otpSending = false
    @Published var loginIdentity = ""
    @Published var password = ""

    @Published var user = ERPUser(id: "", displayName: "", roles: []) {
        didSet {
            if oldValue.id != user.id || oldValue.roles != user.roles {
                productViewScope = .currentLocation
                invalidateProducts()
            }
        }
    }
    @Published var locations: [Location] = []
    @Published var selectedLocation: Location? {
        didSet {
            if oldValue != selectedLocation {
                productViewScope = .currentLocation
                invalidateProducts()
            }
        }
    }
    @Published var dashboard = DashboardData()

    @Published var products: [Product] = []
    @Published var productCounts = ProductCounts()
    @Published var productQuery = ""
    @Published var productOnlyFankuang = false
    @Published var productType: ProductType = .custom
    @Published var listingStatus: ListingStatus = .selling
    @Published var productSort = "updated_desc"
    @Published var selectedProduct: Product?
    @Published var productCategories: [ProductCategoryOption] = []
    @Published var productFacets: [ProductFacetOption] = []
    @Published var productsLoading = false
    @Published var productsError = ""
    @Published var productViewScope: ProductViewScope = .currentLocation {
        didSet { if oldValue != productViewScope { invalidateProducts() } }
    }
    @Published var globalStock = GlobalStockData()
    @Published var globalStockLoading = false
    @Published var globalStockType: ProductType = .custom
    @Published var globalStockQuery = ""

    @Published var transfers: [TransferRecord] = []
    @Published var stocktakes: [StocktakeRecord] = []
    @Published var syncRecords: [SyncRecord] = []
    @Published var operationsLoading = false

    @Published var listingDraft: ListingDraft
    @Published var listingStage = 0
    @Published var listingProgress = ""
    @Published var listingRecognitionActive = false
    @Published private(set) var listingSummaryActive = false
    @Published private(set) var listingSummaryStatus = ""
    @Published var listingUploadProgress = ""
    @Published var listingUploadActive = false
    @Published var listingUploadFailed = false
    @Published private(set) var listingSubmissionActive = false
    private var listingGeneration = UUID()
    private var listingRecognitionTask: Task<Void, Never>?
    private var listingUploadTask: Task<Void, Never>?

    private let api = APIClient.shared
    private let store: SessionStore
    private let productCache = ProductSnapshotCache.shared
    private var otpTimer: Task<Void, Never>?
    private var productRequestID = UUID()
    private var productLoadTask: Task<Void, Never>?
    private var productLoadQuery: ProductListQuery?
    private var globalStockRequestID = UUID()
    private var displayedProductCacheKey: ProductCacheKey?
    private let productsLoader: (ProductListQuery) async throws -> ([Product], ProductCounts)
    private let listingCreator: (ListingDraft, String) async throws -> Product
    private let listingTitleRecognizer: (Data) async throws -> String
    private let listingRecognizer: ([Data]) async throws -> RecognitionPayload
    private let listingImageUploader: (Data) async throws -> String
    private let listingSummaryGenerator: (ListingSummaryInput) async throws -> String
    private let sessionRestorer: () async throws -> ([Location], ERPUser)
    private var sessionRestoreID = UUID()

    init(restoringSession: Bool = true,
         productsLoader: @escaping (ProductListQuery) async throws -> ([Product], ProductCounts) = { try await APIClient.shared.products($0) },
         listingCreator: @escaping (ListingDraft, String) async throws -> Product = { try await APIClient.shared.smartCreate($0, locationID: $1) },
         sessionStore: SessionStore = .shared,
         listingTitleRecognizer: @escaping (Data) async throws -> String = { try await APIClient.shared.recognizeTitle(image: $0) },
         listingRecognizer: @escaping ([Data]) async throws -> RecognitionPayload = { try await APIClient.shared.recognizeItem(paths: [], previewImages: $0) },
         listingImageUploader: @escaping (Data) async throws -> String = { try await APIClient.shared.uploadImage($0, bucket: "sku-raw") },
         listingSummaryGenerator: @escaping (ListingSummaryInput) async throws -> String = { try await APIClient.shared.generateListingSummary($0) },
         sessionRestorer: @escaping () async throws -> ([Location], ERPUser) = {
             async let locations = APIClient.shared.locations()
             async let user = APIClient.shared.currentUser()
             return try await (locations, user)
         }) {
        store = sessionStore
        self.productsLoader = productsLoader
        self.listingCreator = listingCreator
        self.listingTitleRecognizer = listingTitleRecognizer
        self.listingRecognizer = listingRecognizer
        self.listingImageUploader = listingImageUploader
        self.listingSummaryGenerator = listingSummaryGenerator
        self.sessionRestorer = sessionRestorer
        listingDraft = Self.loadListingDraft()
        user = store.cachedUser ?? ERPUser(id: "", displayName: "", roles: [])
        let cachedLocations = sessionStore.hasAuth ? sessionStore.cachedLocations : []
        let cachedLocationID = sessionStore.selectedLocationID
        let cachedLocation = cachedLocations.first { $0.id == cachedLocationID }
        locations = cachedLocations
        selectedLocation = cachedLocation
        root = sessionStore.hasAuth ? (cachedLocation == nil ? .location : .app) : .login
        if listingDraft.submission != nil { listingStage = 2 }
        if restoringSession && store.hasAuth {
            if selectedLocation != nil { Task { await loadHome() } }
            Task { await restoreSession() }
        }
    }

    var isHQ: Bool {
        user.roles.contains("super_admin") || user.roles.contains("hq_operator")
    }

    var canShowHQTools: Bool {
        HQToolVisibility.canShow(
            roles: user.roles,
            locationKind: selectedLocation?.kind
        )
    }

    func sendOTP() {
        let normalizedPhone = phone.trimmingCharacters(in: .whitespacesAndNewlines)
        guard normalizedPhone.count == 11, normalizedPhone.allSatisfy(\.isNumber) else {
            errorMessage = "请输入正确的 11 位手机号"
            return
        }
        guard otpSeconds == 0, !otpSending else { return }
        phone = normalizedPhone
        otpSending = true
        Task {
            defer { otpSending = false }
            do {
                _ = try await api.sendOTP(phone: normalizedPhone)
                startOTPTimer()
                toastMessage = "验证码已发送"
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func login() {
        guard phone.count == 11, otp.count == 6 else {
            errorMessage = "请输入手机号和 6 位验证码"
            return
        }
        busy = true
        Task {
            defer { busy = false }
            do {
                let result = try await api.verifyOTP(phone: phone, code: otp)
                try await completeLogin(result)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func loginWithPassword() {
        let identity = loginIdentity.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !identity.isEmpty, !password.isEmpty else {
            errorMessage = "请输入 ERP 手机号或邮箱及密码"
            return
        }
        busy = true
        Task {
            defer { busy = false }
            do {
                let result = try await api.bootstrap(identity: identity, password: password)
                try await completeLogin(result)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func completeLogin(_ result: BootstrapPayload) async throws {
        sessionRestoreID = UUID()
        selectedLocation = nil
        user = result.user
        store.cachedUser = result.user
        locations = result.locations
        store.cachedLocations = locations
        if let selected = result.selectedLocation {
            selectedLocation = selected
            store.selectedLocationID = selected.id
            root = .app
            busy = false
            await loadHome()
        } else if result.locations.count == 1, let only = result.locations.first {
            try await chooseLocation(only)
        } else {
            root = .location
        }
    }

    func chooseLocation(_ location: Location) async throws {
        sessionRestoreID = UUID()
        busy = true
        errorMessage = ""
        invalidateProducts()
        do {
            selectedLocation = try await api.switchLocation(location)
            store.cachedLocations = locations
            root = .app
            busy = false
            await loadHome()
        } catch {
            busy = false
            throw error
        }
    }

    func chooseLocationFromUI(_ location: Location) {
        Task {
            do {
                try await chooseLocation(location)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    func restoreSession() async {
        let requestID = UUID()
        sessionRestoreID = requestID
        let accountID = store.cachedUser?.id
        let hadCachedLocation = selectedLocation != nil
        busy = !hadCachedLocation
        do {
            let restored = try await sessionRestorer()
            guard sessionRestoreID == requestID, store.hasAuth,
                  store.cachedUser?.id == accountID else { return }
            guard accountID == nil || restored.1.id == accountID else {
                logout()
                errorMessage = "账号已变化，请重新登录"
                return
            }
            locations = restored.0
            user = restored.1
            store.cachedUser = restored.1
            store.cachedLocations = locations
            if let id = store.selectedLocationID,
               let location = locations.first(where: { $0.id == id }) {
                selectedLocation = location
                root = .app
                busy = false
                await loadHome()
            } else if !hadCachedLocation, locations.count == 1, let location = locations.first {
                busy = false
                try await chooseLocation(location)
            } else {
                selectedLocation = nil
                store.selectedLocationID = nil
                dashboard = DashboardData()
                globalStock = GlobalStockData()
                root = .location
                busy = false
            }
        } catch {
            guard sessionRestoreID == requestID, store.cachedUser?.id == accountID else { return }
            busy = false
            if SessionRestorePolicy.shouldClearAuthentication(for: error) {
                logout()
                errorMessage = error.localizedDescription
            } else if error is LocationAccessError {
                selectedLocation = nil
                store.selectedLocationID = nil
                store.cachedLocations = []
                locations = []
                dashboard = DashboardData()
                globalStock = GlobalStockData()
                root = .location
                errorMessage = error.localizedDescription
            } else {
                root = hadCachedLocation ? .app : .location
                if hadCachedLocation {
                    toastMessage = "暂未连接 ERP，已保留上次库位；操作时仍会验证权限"
                } else {
                    errorMessage = "ERP 暂时连接失败，登录凭证已保留，请点击重新加载。\n\(error.localizedDescription)"
                }
            }
        }
    }

    func refreshEmployeeProfile() async {
        let accountID = user.id
        guard store.hasAuth, !accountID.isEmpty else { return }
        do {
            let refreshed = try await api.currentUser()
            guard store.hasAuth, user.id == accountID, refreshed.id == accountID else { return }
            user = refreshed
            store.cachedUser = refreshed
        } catch { /* Keep the last same-account profile during temporary network failures. */ }
    }

    func loadHome() async {
        async let dashboardCall: Void = loadDashboard()
        async let productCall: Void = loadProducts()
        async let categoryCall: Void = loadProductCategories()
        _ = await (dashboardCall, productCall, categoryCall)
    }

    func loadProductCategories() async {
        do {
            let taxonomy = try await api.productTaxonomy()
            productCategories = taxonomy.categories
            productFacets = taxonomy.facets
            reconcileListingFacetSelection()
        } catch {
            // Recognition still returns a valid leaf code; keep the current draft usable offline.
        }
    }

    func loadDashboard() async {
        guard let location = selectedLocation else { return }
        do {
            dashboard = try await api.dashboard(locationID: location.id)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func loadProducts(showSyncToast: Bool = true) async {
        guard !Task.isCancelled else { return }
        guard let query = currentProductQuery else {
            invalidateProducts()
            return
        }
        if productLoadQuery == query, let task = productLoadTask, !task.isCancelled {
            await task.value
            return
        }
        cancelProductLoad()
        let requestID = UUID()
        productRequestID = requestID
        productLoadQuery = query
        let task = Task { await fetchProducts(query: query, requestID: requestID, showSyncToast: showSyncToast) }
        productLoadTask = task
        await withTaskCancellationHandler {
            await task.value
        } onCancel: {
            task.cancel()
        }
    }

    private func fetchProducts(query: ProductListQuery, requestID: UUID, showSyncToast: Bool) async {
        defer {
            if productRequestID == requestID {
                productsLoading = false
                productLoadTask = nil
                productLoadQuery = nil
            }
        }
        guard !Task.isCancelled, productRequestID == requestID, currentProductQuery == query else { return }
        let cacheKey = query.cacheKey
        if displayedProductCacheKey != cacheKey {
            if let snapshot = try? productCache.load(for: cacheKey) {
                products = snapshot.products
                productCounts = snapshot.counts
            } else {
                products = []
                productCounts = ProductCounts()
            }
            displayedProductCacheKey = cacheKey
        }
        productsLoading = true
        productsError = ""
        do {
            let result = try await productsLoader(query)
            guard !Task.isCancelled, productRequestID == requestID, currentProductQuery == query else { return }
            products = result.0
            productCounts = result.1
            try? productCache.save(
                ProductSnapshot(products: result.0, counts: result.1),
                for: cacheKey
            )
        } catch {
            guard !Task.isCancelled, productRequestID == requestID, currentProductQuery == query else { return }
            if error is ProductScopeError || SessionRestorePolicy.shouldClearAuthentication(for: error) || error is ProductAccessError {
                products = []
                productCounts = ProductCounts()
                try? productCache.remove(for: cacheKey)
            }
            productsError = error.localizedDescription
            if showSyncToast && !products.isEmpty {
                toastMessage = "已显示本机商品，后台同步稍后重试"
            }
        }
    }

    var productsMatchCurrentQuery: Bool {
        displayedProductCacheKey == nil || displayedProductCacheKey == currentProductQuery?.cacheKey
    }

    func debounceProductSearch(_ search: String) async {
        guard let original = currentProductQuery else { return }
        do { try await Task.sleep(for: .milliseconds(300)) }
        catch { return }
        guard !Task.isCancelled, let current = currentProductQuery,
              current.userID == original.userID, current.locationID == original.locationID,
              current.authorization == original.authorization, current.scope == original.scope,
              current.search == original.search else { return }
        if productQuery != search { productQuery = search }
    }

    private func cancelProductLoad() {
        productLoadTask?.cancel()
        productLoadTask = nil
        productLoadQuery = nil
        productRequestID = UUID()
    }

    func watchProductImages(query: ProductListQuery,
                            pause: (Duration) async throws -> Void = { try await Task.sleep(for: $0) }) async {
        guard !Task.isCancelled, currentProductQuery == query else { return }
        await loadProducts(showSyncToast: false)
        while !Task.isCancelled, currentProductQuery == query {
            let processing = products.contains { ProductImageProcessingPresentation.shouldPoll($0.imageProcessingStatus) }
            let interval: Duration = !productsError.isEmpty ? .seconds(60) : (processing ? .seconds(15) : .seconds(30))
            do { try await pause(interval) }
            catch { return }
            guard !Task.isCancelled, currentProductQuery == query else { return }
            await loadProducts(showSyncToast: false)
        }
    }

    func productImagesDidRefresh(_ fresh: Product, query: ProductListQuery) {
        guard currentProductQuery == query else { return }
        // Detail reads refresh media only; never replace scoped quantity or list permissions.
        func update(_ item: Product) -> Product {
            guard item.id == fresh.id else { return item }
            var result = item
            result.imageURL = fresh.imageURL
            result.images = fresh.images
            result.imageReferences = fresh.imageReferences
            result.imageProcessingStatus = fresh.imageProcessingStatus
            return result
        }
        let refreshed = products.map(update)
        if let selectedProduct { self.selectedProduct = update(selectedProduct) }
        guard refreshed != products else { return }
        cancelProductLoad()
        productsLoading = false
        products = refreshed
        try? productCache.invalidate(productID: fresh.id)
        if displayedProductCacheKey == query.cacheKey {
            try? productCache.save(ProductSnapshot(products: products, counts: productCounts), for: query.cacheKey)
        }
    }

    var currentProductQuery: ProductListQuery? {
        guard !user.id.isEmpty, let location = selectedLocation,
              locations.contains(where: { $0.id == location.id }) else { return nil }
        return ProductListQuery(userID: user.id, location: location, roles: user.roles,
                                scope: productViewScope, type: productType, status: listingStatus,
                                sort: productSort, search: productQuery, onlyFankuang: productOnlyFankuang)
    }

    private func invalidateProducts() {
        cancelProductLoad()
        displayedProductCacheKey = nil
        products = []
        productCounts = ProductCounts()
        selectedProduct = nil
        productsLoading = false
        productsError = ""
    }

    func productDidMutate(id: String, updated: Product?) {
        cancelProductLoad()
        try? productCache.invalidate(productID: id)
        if let updated {
            products = products.map { $0.id == id ? updated : $0 }
            if selectedProduct?.id == id { selectedProduct = updated }
        } else {
            products.removeAll { $0.id == id }
            if selectedProduct?.id == id { selectedProduct = nil }
        }
        Task { await loadProducts() }
    }

    func productsDidTransfer(ids: Set<String>) {
        cancelProductLoad()
        for id in ids { try? productCache.invalidate(productID: id) }
        products.removeAll { ids.contains($0.id) }
        if let selectedProduct, ids.contains(selectedProduct.id) { self.selectedProduct = nil }
        Task { await loadProducts(); await loadDashboard() }
    }

    func selectProductScope(_ scope: ProductViewScope) {
        guard scope != productViewScope, scope != .all || canShowHQTools else { return }
        productViewScope = scope
    }

    var standardProductGroups: [StandardProductGroup] {
        StandardProductGrouping.groups(from: products)
    }

    func openProduct(_ product: Product) {
        selectedProduct = product
    }

    func loadGlobalStock() async {
        let requestID = UUID()
        globalStockRequestID = requestID
        guard isHQ else {
            globalStock = GlobalStockData()
            return
        }
        globalStockLoading = true
        defer { if globalStockRequestID == requestID { globalStockLoading = false } }
        do {
            let result = try await api.globalStock(
                type: globalStockType,
                query: globalStockQuery
            )
            guard !Task.isCancelled, globalStockRequestID == requestID, isHQ else { return }
            globalStock = result
        } catch {
            guard globalStockRequestID == requestID,
                  !(error is CancellationError), (error as? URLError)?.code != .cancelled else { return }
            globalStock = GlobalStockData()
            errorMessage = error.localizedDescription
        }
    }

    func loadOperations(section: Int? = nil) async {
        guard let location = selectedLocation else { return }
        let userID = user.id
        operationsLoading = true
        defer { operationsLoading = false }
        do {
            if let section {
                switch section {
                case 0:
                    transfers = []
                    let result = try await api.transfers(locationID: location.id)
                    guard !Task.isCancelled, selectedLocation?.id == location.id, user.id == userID else { return }
                    transfers = result
                case 1:
                    stocktakes = []
                    let result = try await api.stocktakes(locationID: location.id)
                    guard !Task.isCancelled, selectedLocation?.id == location.id, user.id == userID else { return }
                    stocktakes = result
                default:
                    syncRecords = []
                    let result = try await api.syncRecords()
                    guard !Task.isCancelled, selectedLocation?.id == location.id, user.id == userID else { return }
                    syncRecords = result
                }
                return
            }
            async let transfersCall = api.transfers(locationID: location.id)
            async let stocktakesCall = api.stocktakes(locationID: location.id)
            async let syncCall = api.syncRecords()
            let result = try await (transfersCall, stocktakesCall, syncCall)
            guard !Task.isCancelled, selectedLocation?.id == location.id, user.id == userID else { return }
            transfers = result.0
            stocktakes = result.1
            syncRecords = result.2
        } catch {
            guard !Task.isCancelled, selectedLocation?.id == location.id, user.id == userID else { return }
            errorMessage = error.localizedDescription
        }
    }

    func toggleSelectedProductVisibility() {
        guard let product = selectedProduct, let query = currentProductQuery else { return }
        busy = true
        Task {
            defer { busy = false }
            do {
                _ = try await api.setProductDisplay(
                    id: product.id,
                    visible: product.listingStatus != "selling"
                )
                guard currentProductQuery == query else { return }
                do {
                    let updated = try await api.productDetail(id: product.id, query: query)
                    guard currentProductQuery == query else { return }
                    selectedProduct = updated
                } catch {
                    guard currentProductQuery == query else { return }
                    errorMessage = "商品状态已更新，详情刷新失败，请返回商品列表刷新。"
                }
                await loadProducts()
            } catch {
                guard currentProductQuery == query else { return }
                errorMessage = error.localizedDescription
            }
        }
    }

    func addCapturedImage(_ image: UIImage) {
        guard listingDraft.submission == nil,
              listingDraft.images.count < ListingCapturePlan.maximumImages,
              let data = ListingImageProcessor.normalizedUploadImage(image)
              .jpegData(compressionQuality: 0.9)
        else { return }
        cancelListingWork()
        listingDraft.invalidateProcessedImages()
        listingDraft.images.append(data)
        listingStage = 0
        listingProgress = ""
        saveListingDraft()
    }

    func removeListingImage(at index: Int) {
        guard listingDraft.submission == nil, listingDraft.images.indices.contains(index) else { return }
        cancelListingWork()
        listingDraft.invalidateProcessedImages()
        listingDraft.images.remove(at: index)
        listingStage = 0
        listingProgress = ""
        saveListingDraft()
    }

    func processListingImages() {
        guard listingDraft.submission == nil else { listingStage = 2; return }
        guard ListingCapturePlan.canProcess(imageCount: listingDraft.images.count) else {
            errorMessage = "请先拍摄至少一张商品图片"
            return
        }
        listingStage = 2
        if listingUploadFailed || (listingDraft.uploadedImagePaths != nil &&
            listingDraft.uploadedPaths.count != listingDraft.images.count) {
            retryListingUploads()
            return
        }
        guard !listingRecognitionActive, !listingUploadActive else { return }
        cancelListingWork()
        listingDraft.clearRecognition()
        let sourceImages = listingDraft.images
        let baseline = listingDraft
        let generation = listingGeneration
        listingProgress = "AI 正在识别，可先填写价格"
        listingRecognitionActive = true
        saveListingDraft()
        listingRecognitionTask = Task {
            let started = Date()
            defer {
                if listingGeneration == generation { listingRecognitionActive = false }
            }
            do {
                let previews = try await Task.detached(priority: .userInitiated) {
                    try sourceImages.map(ListingImageProcessor.recognitionImageData)
                }.value
                try Task.checkCancellation()
                var recognitionBaseline = baseline
                // A slow quick request must not hold the full result (or its completion state) hostage.
                let quickTitleTask = Task {
                    if let first = previews.first, let title = try? await listingTitleRecognizer(first) {
                        guard !Task.isCancelled, listingGeneration == generation else { return }
                        if listingDraft.submission == nil, listingDraft.name == baseline.name {
                            listingDraft.applyQuickTitle(title, baseline: baseline)
                            // Full recognition may refine our title, but not a subsequent human edit.
                            recognitionBaseline.name = listingDraft.name
                        }
                        saveListingDraft()
                        listingProgress = "标题已生成，正在补全分类、品牌和标签"
                    }
                }
                defer { quickTitleTask.cancel() }
                let result = try await listingRecognizer(previews)
                guard !Task.isCancelled, listingGeneration == generation else { return }
                listingDraft.applyRecognition(result, baseline: recognitionBaseline)
                if listingDraft.normalizedFacetCodes.isEmpty, listingDraft.categoryCode == result.categoryCode {
                    listingDraft.facetCodes = productFacets.filter { listingDraft.tags.contains($0.name) }.map(\.code)
                }
                if let option = productCategories.first(where: { $0.code == listingDraft.categoryCode }) {
                    listingDraft.category = option.displayName
                }
                reconcileListingFacetSelection()
                saveListingDraft()
                listingProgress = "AI 识别完成（\(Int(Date().timeIntervalSince(started)))秒），请确认信息和售价"
            } catch {
                guard !Task.isCancelled, listingGeneration == generation else { return }
                listingProgress = "AI 识别未完成，可手动填写或重新识别"
                listingDraft.recognitionWarning = error.localizedDescription
                saveListingDraft()
            }
        }
        retryListingUploads()
    }

    func refreshListingSummary() async {
        guard !listingSummaryActive, !listingRecognitionActive,
              !listingSubmissionActive, listingDraft.submission == nil else { return }
        let input = ListingSummaryInput(listingDraft)
        guard !input.name.isEmpty else {
            listingSummaryStatus = "请先填写商品名称，再刷新简介"
            return
        }
        let generation = listingGeneration
        listingSummaryActive = true
        listingSummaryStatus = "正在生成简介，其他资料保持不变"
        defer {
            if listingGeneration == generation { listingSummaryActive = false }
        }
        do {
            let summary = try await listingSummaryGenerator(input)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard !Task.isCancelled, listingGeneration == generation,
                  listingDraft.submission == nil else { return }
            guard !summary.isEmpty, summary.count <= 80 else {
                throw APIError.message("未生成有效简介，请重试；原有内容已保留")
            }
            // A response must never replace text edited after the request started.
            guard ListingSummaryInput(listingDraft) == input else {
                listingSummaryStatus = "商品资料已修改，已保留你的内容，可再次刷新简介"
                return
            }
            listingDraft.description = summary
            saveListingDraft()
            listingSummaryStatus = "简介已更新"
        } catch {
            guard !Task.isCancelled, listingGeneration == generation,
                  listingDraft.submission == nil else { return }
            listingSummaryStatus = "简介刷新失败：\(error.localizedDescription)。可重试，原有内容已保留"
        }
    }

    func retryListingUploads() {
        guard listingDraft.submission == nil, !listingSubmissionActive, !listingUploadActive,
              ListingCapturePlan.canProcess(imageCount: listingDraft.images.count) else { return }
        let sourceImages = listingDraft.images
        let generation = listingGeneration
        listingUploadFailed = false
        if ListingUploadPlan.canCreate(rawPathCount: listingDraft.uploadedPaths.count, imageCount: sourceImages.count) {
            listingUploadProgress = "原图已备份 \(sourceImages.count)/\(sourceImages.count)"
            return
        }
        // Persist an attempted batch even if every upload fails before a path exists.
        listingDraft.uploadedImagePaths = listingDraft.rawUploadSlots
        saveListingDraft()
        listingUploadActive = true
        listingUploadTask = Task {
            defer {
                if listingGeneration == generation { listingUploadActive = false }
            }
            do {
                try await uploadRawListingImages(sourceImages, generation: generation)
                guard !Task.isCancelled, listingGeneration == generation else { return }
                listingUploadProgress = "原图已备份 \(listingDraft.uploadedPaths.count)/\(sourceImages.count)"
                saveListingDraft()
            } catch {
                guard !Task.isCancelled, listingGeneration == generation else { return }
                listingUploadFailed = true
                listingUploadProgress = "原图备份失败：\(error.localizedDescription)。照片已保留，请重试原图备份"
                saveListingDraft()
            }
        }
    }

    private func uploadRawListingImages(_ images: [Data], generation: UUID) async throws {
        let pending = images.indices.filter { listingDraft.rawUploadSlots[$0] == nil }
        var index = 0
        while index < pending.count {
            try Task.checkCancellation()
            guard listingGeneration == generation else { throw CancellationError() }
            listingUploadProgress = "正在备份原图，已完成 \(listingDraft.rawUploadSlots.compactMap { $0 }.count)/\(images.count)"
            if index + 1 < pending.count {
                async let first = uploadRawListingImage(images[pending[index]], at: pending[index], generation: generation)
                async let second = uploadRawListingImage(images[pending[index + 1]], at: pending[index + 1], generation: generation)
                // Await both outcomes so one failure cannot discard the successful sibling.
                let errors = await [first, second].compactMap { $0 }
                if let error = errors.first { throw error }
                index += 2
            } else {
                if let error = await uploadRawListingImage(images[pending[index]], at: pending[index], generation: generation) {
                    throw error
                }
                index += 1
            }
        }
    }

    private func uploadRawListingImage(_ data: Data, at index: Int, generation: UUID) async -> Error? {
        do {
            let path = try await listingImageUploader(data).trimmingCharacters(in: .whitespacesAndNewlines)
            try Task.checkCancellation()
            guard listingGeneration == generation, listingDraft.submission == nil,
                  listingDraft.images.indices.contains(index), listingDraft.images[index] == data else {
                throw CancellationError()
            }
            guard !path.isEmpty else { throw APIError.message("图片上传未返回路径") }
            listingDraft.recordRawUpload(path, at: index)
            saveListingDraft()
            return nil
        } catch { return error }
    }

    private func signRawListingImages(_ paths: [String]) async throws -> [String] {
        var urls: [String] = []
        for path in paths {
            urls.append(try await api.signReadURL(bucket: "sku-raw", storagePath: path))
        }
        return urls
    }

    private func prepareListingAngles(
        rawPaths: [String],
        sourceImages: [Data]
    ) async throws -> (items: [PreparedListingPayload], fallbackCount: Int) {
        guard rawPaths.count == sourceImages.count else {
            throw APIError.message("原图上传数量不一致")
        }
        var output: [PreparedListingPayload] = []
        var fallbackCount = 0
        var index = 0
        while index < rawPaths.count {
            listingProgress = "AI 正在处理 \(index + 1)-\(min(index + 2, rawPaths.count))/\(rawPaths.count)"
            let firstIndex = index
            if index + 1 < rawPaths.count {
                let secondIndex = index + 1
                async let first = prepareListingAngle(
                    rawPath: rawPaths[firstIndex],
                    sourceData: sourceImages[firstIndex]
                )
                async let second = prepareListingAngle(
                    rawPath: rawPaths[secondIndex],
                    sourceData: sourceImages[secondIndex]
                )
                let pair = try await [first, second]
                output.append(contentsOf: pair.map(\.payload))
                fallbackCount += pair.filter { $0.usedFallback }.count
                index += 2
            } else {
                let item = try await prepareListingAngle(
                    rawPath: rawPaths[firstIndex],
                    sourceData: sourceImages[firstIndex]
                )
                output.append(item.payload)
                fallbackCount += item.usedFallback ? 1 : 0
                index += 1
            }
        }
        return (output, fallbackCount)
    }

    private func prepareListingAngle(
        rawPath: String,
        sourceData: Data
    ) async throws -> (payload: PreparedListingPayload, usedFallback: Bool) {
        do {
            return (try await api.prepareListingImage(rawStoragePath: rawPath), false)
        } catch {
            let preparedData = try await Task.detached(priority: .userInitiated) {
                try ListingImageProcessor.preparedListingImageData(sourceData)
            }.value
            let path = try await api.uploadImage(preparedData, bucket: "sku-listing")
            let url = try await api.signReadURL(bucket: "sku-listing", storagePath: path)
            return (PreparedListingPayload(storagePath: path, signedURL: url), true)
        }
    }

    func createListing(onSubmitting: (() -> Void)? = nil, onCreated: ((Product) -> Void)? = nil) {
        guard !busy, !listingSubmissionActive else { return }
        guard let location = selectedLocation else {
            errorMessage = "请先选择上架门店"
            return
        }
        guard !listingDraft.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            errorMessage = "请填写商品名称"
            return
        }
        guard listingDraft.hasConfirmedCategory else {
            errorMessage = "请确认 ERP 商品分类"
            return
        }
        if !productCategories.isEmpty,
           !productCategories.contains(where: { $0.code == listingDraft.categoryCode }) {
            errorMessage = "该商品分类已停用，请重新选择 ERP 商品分类"
            return
        }
        let allowedFacetCodes = Set(listingFacetsForCurrentCategory().map(\.code))
        if listingDraft.normalizedFacetCodes.contains(where: { !allowedFacetCodes.contains($0) }) {
            errorMessage = "部分商品标签不适用于当前分类，请重新选择"
            return
        }
        guard ConditionGrade(rawValue: listingDraft.conditionGrade) != nil else {
            errorMessage = "请选择 N、S、A、B、C、J 中的商品成色"
            return
        }
        do {
            _ = try ProductPriceInput.amount(listingDraft.price)
        } catch {
            errorMessage = error.localizedDescription
            return
        }
        guard ListingUploadPlan.canCreate(
            rawPathCount: listingDraft.uploadedPaths.count,
            imageCount: listingDraft.images.count
        ) else {
            errorMessage = "商品原图尚未上传完成"
            return
        }
        if !listingDraft.ipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
           !listingDraft.ipConfirmed {
            errorMessage = "请确认识别到的 IP，或修改后确认新建"
            return
        }
        let previousSubmission = listingDraft.submission
        do {
            try listingDraft.prepareSubmission(locationID: location.id, userID: user.id)
            // Persist before sending: a timeout, process exit or restart must replay this operation.
            try JSONEncoder().encode(listingDraft).write(to: Self.listingDraftURL, options: .atomic)
        } catch {
            listingDraft.submission = previousSubmission
            errorMessage = error.localizedDescription
            return
        }
        cancelListingWork()
        let submittedDraft = listingDraft
        let generation = listingGeneration
        let submittingUserID = user.id
        busy = true
        listingSubmissionActive = true
        onSubmitting?()
        Task {
            do {
                let product = try await listingCreator(submittedDraft, location.id)
                busy = false
                listingSubmissionActive = false
                if listingGeneration == generation { resetListing(completed: true) }
                guard user.id == submittingUserID, selectedLocation?.id == location.id else { return }
                selectedProduct = product
                productType = .custom
                listingStatus = .selling
                productQuery = ""
                productSort = "updated_desc"
                secondTabMode = .products
                selectedTab = 1
                toastMessage = "商品已上架到 \(location.name)"
                onCreated?(product)
                Task { await loadProducts() }
            } catch {
                busy = false
                listingSubmissionActive = false
                if case APIError.listingRejected = error, listingGeneration == generation {
                    listingDraft.submission = nil
                    saveListingDraft()
                    errorMessage = error.localizedDescription
                } else {
                    errorMessage = "尚未确认上架结果，请在原门店点击重试，不要重新建品。\(error.localizedDescription)"
                }
            }
        }
    }

    func listingFacetsForCurrentCategory() -> [ProductFacetOption] {
        ProductTaxonomy(categories: productCategories, facets: productFacets)
            .facets(for: listingDraft.categoryCode)
    }

    func toggleListingFacet(_ code: String) {
        guard listingFacetsForCurrentCategory().contains(where: { $0.code == code }) else { return }
        var codes = listingDraft.normalizedFacetCodes
        if let index = codes.firstIndex(of: code) {
            codes.remove(at: index)
        } else if codes.count < 20 {
            codes.append(code)
        }
        listingDraft.facetCodes = codes
        listingDraft.tags = productFacets.filter { codes.contains($0.code) }.map(\.name)
        saveListingDraft()
    }

    func reconcileListingFacetSelection() {
        let allowed = Set(listingFacetsForCurrentCategory().map(\.code))
        let codes = listingDraft.normalizedFacetCodes.filter(allowed.contains)
        listingDraft.facetCodes = codes
        listingDraft.tags = productFacets.filter { codes.contains($0.code) }.map(\.name)
        saveListingDraft()
    }

    func resetListing(completed: Bool = false) {
        guard completed || listingDraft.submission == nil else {
            listingStage = 2
            errorMessage = "这份草稿正在确认上架结果，请先重试确认，避免重复入库"
            return
        }
        cancelListingWork()
        listingDraft = ListingDraft()
        saveListingDraft()
        listingStage = 0
        listingProgress = ""
        listingRecognitionActive = false
    }

    func returnToListingCapture() {
        saveListingDraft()
        guard listingDraft.submission == nil else { return }
        listingStage = 0
    }

    private func cancelListingWork() {
        listingGeneration = UUID()
        listingRecognitionTask?.cancel()
        listingUploadTask?.cancel()
        listingRecognitionActive = false
        listingUploadActive = false
        listingSummaryActive = false
        listingSummaryStatus = ""
        listingUploadFailed = false
        listingUploadProgress = ""
    }

    func logout() {
        sessionRestoreID = UUID()
        cancelListingWork()
        store.clearAuth()
        user = ERPUser(id: "", displayName: "", roles: [])
        selectedLocation = nil
        locations = []
        products = []
        dashboard = DashboardData()
        root = .login
    }

    func handleAuthenticationExpiry() {
        guard !store.hasAuth else { return }
        sessionRestoreID = UUID()
        saveListingDraft()
        cancelListingWork()
        invalidateProducts()
        globalStockRequestID = UUID()
        globalStockLoading = false
        user = ERPUser(id: "", displayName: "", roles: [])
        selectedLocation = nil
        locations = []
        globalStock = GlobalStockData()
        dashboard = DashboardData()
        busy = false
        root = .login
        errorMessage = "登录已过期，请重新登录。未完成的上架草稿已保留。"
    }

    private func startOTPTimer() {
        otpTimer?.cancel()
        otpSeconds = 60
        otpTimer = Task {
            while !Task.isCancelled, otpSeconds > 0 {
                try? await Task.sleep(for: .seconds(1))
                if !Task.isCancelled { otpSeconds -= 1 }
            }
        }
    }

    func saveListingDraft() {
        guard let data = try? JSONEncoder().encode(listingDraft) else { return }
        try? data.write(to: Self.listingDraftURL, options: .atomic)
    }

    private static func loadListingDraft() -> ListingDraft {
        guard let data = try? Data(contentsOf: listingDraftURL),
              let draft = try? JSONDecoder().decode(ListingDraft.self, from: data)
        else { return ListingDraft() }
        return draft
    }

    private static var listingDraftURL: URL {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("listing-draft.json")
    }
}
