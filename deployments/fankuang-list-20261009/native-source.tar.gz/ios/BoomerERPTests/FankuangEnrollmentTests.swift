import XCTest
@testable import BOOMER_ERP

final class FankuangEnrollmentTests: XCTestCase {
    func testProductBadgeUsesCanonicalMembershipAndDoesNotEnrollStandardOrUnlimited() throws {
        var product = ProductScopeTests.product("test")
        XCTAssertTrue(product.inFankuang)
        product.fankuangOverride = false
        XCTAssertFalse(product.inFankuang)
        product.fankuangMembership = true
        product.price = 199
        XCTAssertTrue(product.inFankuang)
        product.productType = "standard"
        XCTAssertFalse(product.inFankuang)
        product.productType = "custom"
        product.isUnlimitedStock = true
        XCTAssertFalse(product.inFankuang)
        let restored = try JSONDecoder().decode(Product.self, from: JSONEncoder().encode(product))
        XCTAssertEqual(restored.fankuangMembership, true)
    }

    func testFilterChangesRequestAndCacheButPreservesStoreAndStatus() throws {
        let plain = ProductListQuery(userID: "staff", location: Location(id: "xtd", name: "新天地", kind: "shop"), roles: ["shop_manager"], scope: .all, status: .soldOut, search: "杯")
        let filtered = ProductListQuery(userID: "staff", location: Location(id: "xtd", name: "新天地", kind: "shop"), roles: ["shop_manager"], scope: .all, status: .soldOut, search: "杯", onlyFankuang: true)
        XCTAssertNotEqual(plain.cacheKey.storageKey, filtered.cacheKey.storageKey)
        let parts = try XCTUnwrap(URLComponents(string: filtered.path(page: 2, pageSize: 50)))
        let values = Dictionary(uniqueKeysWithValues: try XCTUnwrap(parts.queryItems).map { ($0.name, $0.value ?? "") })
        XCTAssertEqual(values["fankuang"], "1")
        XCTAssertEqual(values["location_id"], "xtd")
        XCTAssertEqual(values["scope"], "current_location")
        XCTAssertEqual(values["status"], "sold_out")
        XCTAssertEqual(values["page"], "2")
        XCTAssertFalse(plain.path(page: 1, pageSize: 50).contains("fankuang="))
        XCTAssertThrowsError(try filtered.validateResponse(["scope": "location:xtd", "counts": ["custom": 1, "standard": 0, "bundle": 0, "all": 1], "items": [["product_type": "custom", "in_fankuang": false, "stocks": [["location_id": "xtd"]]]]]))
    }

    func testAutomaticBoundaryAndManualPriority() {
        var draft = ListingDraft()
        for (price, expected) in [("49.9", true), ("49.91", false), ("50", false), ("", false)] {
            draft.price = price
            XCTAssertEqual(draft.inFankuang, expected)
        }
        draft.fankuangOverride = false
        draft.price = "9.9"
        XCTAssertFalse(draft.inFankuang)
        draft.fankuangOverride = true
        draft.price = "199"
        XCTAssertTrue(draft.inFankuang)
    }

    func testRecognitionResetAndDraftRestorePreserveManualChoice() throws {
        var draft = ListingDraft()
        draft.price = "9.9"
        draft.fankuangOverride = false
        draft.clearRecognition()
        XCTAssertEqual(draft.fankuangOverride, false)
        draft.invalidateProcessedImages()
        XCTAssertEqual(draft.fankuangOverride, false)
        let restored = try JSONDecoder().decode(ListingDraft.self, from: JSONEncoder().encode(draft))
        XCTAssertFalse(restored.inFankuang)
        var legacy = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(draft)) as? [String: Any])
        legacy.removeValue(forKey: "fankuangOverride")
        let old = try JSONDecoder().decode(ListingDraft.self, from: JSONSerialization.data(withJSONObject: legacy))
        XCTAssertNil(old.fankuangOverride)
        XCTAssertTrue(old.inFankuang)
    }

    func testRequestFreezesOverrideAndEditSupportsAutomaticNull() throws {
        var draft = ListingDraft()
        draft.price = "9.9"
        draft.fankuangOverride = false
        try draft.prepareSubmission(locationID: "store", userID: "employee")
        let first = try XCTUnwrap(draft.submission)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: first.body) as? [String: Any])
        XCTAssertEqual(body["fankuang_override"] as? Bool, false)
        draft.fankuangOverride = true
        try draft.prepareSubmission(locationID: "store", userID: "employee")
        XCTAssertEqual(draft.submission?.body, first.body)
        let auto = ProductEditInput(name: "杯", price: "49.9", grade: "A", description: "")
        XCTAssertTrue(try auto.fields()["fankuang_override"] is NSNull)
        var manual = auto
        manual.fankuangOverride = false
        XCTAssertEqual(try manual.fields()["fankuang_override"] as? Bool, false)
    }
}
