package com.vintagego.handheld

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

data class UiState(
    val screen: AppScreen = AppScreen.Login,
    val photo: File? = null,
    val photoBatch: List<String> = emptyList(),
    val listingStoragePath: String = "",
    val listingStoragePaths: List<String> = emptyList(),
    val listingImageUrl: String = "",
    val originalPhoto: File? = null,
    val originalPhotoBatch: List<String> = emptyList(),
    val itemNo: String = "",
    val name: String = "",
    val category: String = "",
    val categoryCode: String = "",
    val listingCategoryOptions: List<ProductCategoryOption> = emptyList(),
    val listingFacetOptions: List<ProductFacetOption> = emptyList(),
    val selectedFacetCodes: List<String> = emptyList(),
    val recognitionRequestId: String = "",
    val classificationStatus: String = "",
    val aiSuggestedPriceCny: Double? = null,
    val brand: String = "",
    val ipName: String = "",
    val ipMatchStatus: String = "empty",
    val ipConfirmed: Boolean = true,
    val ipSuggestions: List<RecognitionIpSuggestion> = emptyList(),
    val material: String = "",
    val color: String = "",
    val conditionGrade: String = "",
    val conditionNote: String = "",
    val confidence: Double = 0.0,
    val price: String = "",
    val fankuangOverride: Boolean? = null,
    val status: String = "请先拍照",
    val busy: Boolean = false,
    val items: List<Item> = emptyList(),
    val search: String = "",
    val selectedItem: Item? = null,
    val locations: List<HandheldLocation> = emptyList(),
    val selectedLocation: HandheldLocation? = null,
    val userName: String = "",
    val employeeAvatarUrl: String = "",
    val roles: Set<String> = emptySet(),
    val dashboard: DashboardData = DashboardData(),
    val dashboardLoading: Boolean = false,
    val homeMessagesGeneration: Long = 0,
    val dashboardRequestId: Long = 0,
    val messagesRequestId: Long = 0,
    val messages: List<NotificationRecord> = emptyList(),
    val messagesLoading: Boolean = false,
    val messagesError: String = "",
    val locationSwitching: Boolean = false,
    val secondTab: SecondTabState = SecondTabState(),
    val orderCenter: OrderCenterState = OrderCenterState(),
    val fulfillmentWork: FulfillmentWorkState? = null,
    val productLoading: Boolean = false,
    val productViewScope: ProductViewScope = ProductViewScope.Current,
    val productError: String = "",
    val productDetailId: String = "",
    val productDetailLoading: Boolean = false,
    val productDetailError: String = "",
    val productType: String = "custom",
    val productSort: String = "updated_desc",
    val productCategory: String = "",
    val productHasImage: Boolean? = null,
    val productStatus: String = "selling",
    val productOnlyFankuang: Boolean = false,
    val productCounts: ProductCounts = ProductCounts(),
    val globalStock: GlobalStockData = GlobalStockData(),
    val globalStockLoading: Boolean = false,
    val globalStockView: String = "matrix",
    val globalStockState: String = "all",
    val installId: String = "",
    val loggedIn: Boolean = false,
    val otpCooldownSeconds: Int = 0,
    val printerSnapshot: PrinterSnapshot = PrinterSnapshot.disconnected(),
    val bluetoothPrinterDevices: List<BluetoothPrinterDevice> = emptyList(),
    val bluetoothPrinterScanning: Boolean = false,
    val printHistory: List<String> = emptyList(),
    val labelTemplates: List<LabelTemplate> = emptyList(),
    val labelTemplatesCanManage: Boolean? = null,
    val editingLabelTemplate: LabelTemplate? = null,
    val labelTemplateReturnScreen: AppScreen = AppScreen.PrinterSettings,
    val printOffsetXDots: Int = 0,
    val printOffsetYDots: Int = DEFAULT_PRINT_OFFSET_Y_DOTS,
    val printPreviewItem: Item? = null,
)

val UiState.canShowHQTools: Boolean get() = loggedIn && !locationSwitching &&
    selectedLocation?.kind == "warehouse" && locations.any { it.id == selectedLocation.id } &&
    roles.any { it == "super_admin" || it == "hq_operator" }

fun UiState.productScope(): ProductScope? {
    val location = selectedLocation ?: return null
    if (!loggedIn || locationSwitching) return null
    val scope = ProductScope(homeMessagesGeneration, userName, location.id, location.kind,
        locations.map { it.id }.toSet(), roles, productViewScope)
    return scope.takeIf { runCatching { it.validate() }.isSuccess }
}

fun UiState.productQuery(query: String = search): ProductQuery =
    ProductQuery(query.trim(), productType, productSort, productCategory, productHasImage, productStatus,
        onlyFankuang = productOnlyFankuang)

fun UiState.resetProducts(): UiState = copy(items = emptyList(), productCounts = ProductCounts(),
    selectedItem = null, printPreviewItem = null, busy = false, productLoading = false, productError = "",
    productViewScope = ProductViewScope.Current, productDetailId = "", productDetailLoading = false, productDetailError = "")

fun UiState.acceptsProductDetail(key: ProductCacheKey, id: String, sequence: Int, currentSequence: Int): Boolean =
    screen == AppScreen.ProductDetail && productDetailId == id && key.accepts(productScope(), productQuery(), sequence, currentSequence)

fun UiState.productScopeLabel(): String = if (productViewScope == ProductViewScope.All && canShowHQTools) "所有门店" else
    selectedLocation?.let { productLocationLabel(it.name, it.kind) } ?: "请选择门店"

private data class ProductCacheEntry(
    val items: List<Item>,
    val counts: ProductCounts,
    val status: String,
    val loadedAtMillis: Long,
)

enum class AppScreen {
    Login,
    LocationSelect,
    Dashboard,
    Products,
    Orders,
    ProductDetail,
    GlobalStock,
    Camera,
    Processing,
    Confirm,
    LabelPreview,
    Sync,
    Profile,
    QuickStock,
    Inventory,
    RfidBind,
    Transfer,
    Parcels,
    Notifications,
    StoreSettings,
    DeviceSettings,
    PrinterSettings,
    LabelTemplateEditor,
    Pos,
    Help,
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val api = RecognitionApi(application)
    private val handheld = HandheldApiClient(application)
    private val session = HandheldSessionStore(application)
    private val store = ItemStore(application)
    private val labelTemplateStore = LabelTemplateStore(application)
    private val listingDraftStore = ListingDraftStore(application)
    private val printHistoryStore = PrintHistoryStore(application)
    private val capturePreferences = application.getSharedPreferences("capture_state", Application.MODE_PRIVATE)
    private val printerPreferences = application.getSharedPreferences("printer_settings", Application.MODE_PRIVATE)
    private val printer = ThermalPrinterCoordinator(application).also { it.bind() }
    private val productRequestVersion = AtomicInteger(0)
    private val productDetailRequestVersion = AtomicInteger(0)
    private val productCache = mutableMapOf<ProductCacheKey, ProductCacheEntry>()
    private val fulfillmentWorkCache = ConcurrentHashMap<Pair<OrderScope, String>, FulfillmentWorkState>()
    private var fulfillmentScanTarget: FulfillmentScanTarget? = null
    private val mutableState = MutableStateFlow(
        UiState(
            screen = when {
                !session.hasAuth -> AppScreen.Login
                session.selectedLocation() == null -> AppScreen.LocationSelect
                else -> AppScreen.Dashboard
            },
            items = emptyList(),
            selectedLocation = session.selectedLocation(),
            userName = session.userName,
            employeeAvatarUrl = session.avatarUrl,
            roles = session.roles,
            installId = session.installId,
            loggedIn = session.hasAuth,
            printHistory = printHistoryStore.all(),
            labelTemplates = labelTemplateStore.templates(),
            labelTemplatesCanManage = session.roles.takeIf { it.isNotEmpty() }?.let(::canManageTemplatesByRole),
            printOffsetXDots = printerPreferences.getInt(PRINT_OFFSET_X, 0),
            printOffsetYDots = printerPreferences.getInt(PRINT_OFFSET_Y, DEFAULT_PRINT_OFFSET_Y_DOTS),
            status = if (session.hasAuth) "请选择门店或仓库" else "请使用 ERP 账号登录",
        ),
    )
    val state = mutableState.asStateFlow()

    init {
        printer.onBluetoothChanged = {
            mutableState.value = mutableState.value.copy(
                bluetoothPrinterDevices = printer.bluetoothDevices(),
                bluetoothPrinterScanning = printer.isBluetoothScanning(),
            )
            refreshPrinterStatus()
        }
        if (session.hasAuth) {
            loadLocations()
            loadProductCategories()
            session.selectedLocation()?.let { loadDashboard(it.id) }
            refreshLabelTemplates(silent = true)
        }
        refreshPrinterStatus()
        if (printer.selectedBackend() == PrinterBackendType.BLUETOOTH) {
            viewModelScope.launch(Dispatchers.IO) {
                runCatching { printer.reconnectLastBluetooth() }
                refreshPrinterStatus()
            }
        }
    }

    fun photoFile(): File {
        val directory = File(getApplication<Application>().filesDir, "images").apply { mkdirs() }
        return File(directory, "${System.currentTimeMillis()}.jpg").apply {
            parentFile?.mkdirs()
            if (!exists()) createNewFile()
        }
    }

    fun latestPhotoFile(): File? {
        val directory = File(getApplication<Application>().filesDir, "images")
        return directory.listFiles { file -> file.extension.equals("jpg", ignoreCase = true) && file.length() > 0L }
            ?.maxByOrNull { it.lastModified() }
    }

    fun rememberPendingPhoto(file: File) {
        capturePreferences.edit().putString("pending_photo", file.absolutePath).apply()
    }

    fun resolveCapturedPhoto(fallback: File): File? {
        val pending = capturePreferences.getString("pending_photo", null)
            ?.let(::File)
            ?.takeIf { it.exists() && it.length() > 0L }
        val captured = fallback.takeIf { it.exists() && it.length() > 0L } ?: pending ?: latestPhotoFile()
        if (captured != null) capturePreferences.edit().remove("pending_photo").apply()
        return captured
    }

    fun resumePendingCaptureIfAny() {
        val current = mutableState.value
        if (!session.hasAuth) return
        if (current.busy || current.screen == AppScreen.Processing || current.screen == AppScreen.Confirm) return

        val pending = capturePreferences.getString("pending_photo", null)
            ?.let(::File)
            ?.takeIf { it.exists() && it.length() > 0L }
            ?: return

        capturePreferences.edit().remove("pending_photo").apply()
        onPhotoTaken(pending)
    }

    fun navigate(screen: AppScreen) {
        if (screen == AppScreen.Parcels && !canOpenParcels()) {
            notify("当前账号没有日本小包权限", AppScreen.Dashboard)
            return
        }
        val current = mutableState.value
        if (current.screen == AppScreen.ProductDetail && screen != AppScreen.ProductDetail) {
            productDetailRequestVersion.incrementAndGet()
        }
        val tab = when (screen) {
            AppScreen.Orders -> current.secondTab.select(SecondTabMode.Orders, SystemClock.uptimeMillis())
            AppScreen.Products -> current.secondTab.select(SecondTabMode.Products, SystemClock.uptimeMillis())
            else -> current.secondTab.leave()
        }
        mutableState.value = current.copy(screen = screen, secondTab = tab)
        if (screen == AppScreen.Orders) ensureOrders()
    }

    fun tapSecondTab(allowDoubleTap: Boolean) {
        val tab = mutableState.value.secondTab.tap(SystemClock.uptimeMillis(), allowDoubleTap)
        mutableState.update { it.copy(secondTab = tab, screen = tab.destination) }
        if (tab.mode == SecondTabMode.Orders) ensureOrders()
    }

    fun ensureOrders() {
        val scope = mutableState.value.orderScope()
        if (mutableState.value.orderCenter.scope != scope) {
            mutableState.update { it.copy(orderCenter = OrderCenterState.forScope(scope)) }
        }
        val orders = mutableState.value.orderCenter
        if (scope != null && orders.total == null && !orders.loading && orders.error.isBlank()) loadOrders()
    }

    fun changeOrderQuery(query: OrderQuery) {
        val scope = mutableState.value.orderScope() ?: return
        runCatching { query.path(scope, 1) }.onFailure { return }
        mutableState.update { it.copy(orderCenter = it.orderCenter.changeQuery(query)) }
        loadOrders(debounce = true)
    }

    fun loadOrders(more: Boolean = false, debounce: Boolean = false) {
        val scope = mutableState.value.orderScope() ?: return
        val old = mutableState.value.orderCenter
        if (old.scope != scope || (more && (old.loading || !old.hasMore))) return
        val loading = old.beginLoad(more)
        val request = loading.request()
        mutableState.update { it.copy(orderCenter = loading) }
        viewModelScope.launch {
            if (debounce) delay(250)
            if (mutableState.value.orderScope() != scope || mutableState.value.orderCenter.request() != request) return@launch
            val result = runCatching { withContext(Dispatchers.IO) { handheld.orderCenterPage(scope, request.query, request.page) } }
            mutableState.update {
                if (it.orderScope() == scope) it.copy(orderCenter = it.orderCenter.receive(request, result)) else it
            }
        }
    }

    fun openOrderDetail(id: String) {
        val scope = mutableState.value.orderScope() ?: return
        val old = mutableState.value.orderCenter
        if (!scope.isHq || old.scope != scope || old.orders.none { it.id == id }) return
        val loading = old.beginDetail(id)
        val request = loading.request()
        mutableState.update { it.copy(orderCenter = loading) }
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.orderCenterDetail(scope, id) } }
            mutableState.update {
                if (it.orderScope() == scope) it.copy(orderCenter = it.orderCenter.receiveDetail(request, id, loading.detailSequence, result)) else it
            }
        }
    }

    fun openFulfillmentSnapshot(id: String) {
        val current = mutableState.value
        if (current.orderScope() != current.orderCenter.scope) return
        val row = current.orderCenter.fulfillments.firstOrNull { it.id == id } ?: return
        mutableState.update { it.copy(orderCenter = it.orderCenter.copy(selectedFulfillment = row)) }
        val scope = current.orderScope() ?: return
        val work = fulfillmentWorkCache.getOrPut(scope to id) { FulfillmentWorkState(scope, id) }
        mutableState.update { it.copy(fulfillmentWork = work) }
        if (!work.busy) refreshFulfillmentWork()
    }

    fun closeOrderDetail() {
        val wasFulfillment = mutableState.value.orderCenter.selectedFulfillment != null
        fulfillmentScanTarget = null
        mutableState.update { it.copy(orderCenter = it.orderCenter.closeDetail()) }
        if (wasFulfillment) loadOrders()
    }

    private fun activeFulfillmentWork(): FulfillmentWorkState? {
        val current = mutableState.value
        val scope = current.orderScope() ?: return null
        val id = current.orderCenter.selectedFulfillment?.id ?: return null
        return fulfillmentWorkCache[scope to id]
    }

    private fun updateFulfillmentWork(scope: OrderScope, id: String, transform: (FulfillmentWorkState) -> FulfillmentWorkState) {
        val current = mutableState.value
        if (current.orderScope() != scope) return
        val work = fulfillmentWorkCache[scope to id] ?: return
        val next = transform(work)
        fulfillmentWorkCache[scope to id] = next
        mutableState.update {
            if (it.orderScope() == scope && it.orderCenter.selectedFulfillment?.id == id) it.copy(fulfillmentWork = next) else it
        }
    }

    fun refreshFulfillmentWork() {
        val work = activeFulfillmentWork() ?: return
        if (work.busy) return
        readFulfillmentWork(work.scope, work.id)
    }

    private fun readFulfillmentWork(scope: OrderScope, id: String) {
        val old = fulfillmentWorkCache[scope to id] ?: return
        if (old.sending || mutableState.value.orderScope() != scope) return
        val reading = old.beginRead()
        updateFulfillmentWork(scope, id) { reading }
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.orderFulfillmentDetail(scope, id) } }
            if (rejectFulfillmentAccess(scope, result.exceptionOrNull())) return@launch
            updateFulfillmentWork(scope, id) { it.receiveRead(reading.readVersion, result) }
        }
    }

    fun startFulfillmentScan(lineId: String): Boolean {
        val work = activeFulfillmentWork() ?: return false
        val target = FulfillmentScanTarget(work.scope, work.id, lineId, work.readVersion)
        if (!target.matches(work)) return false
        fulfillmentScanTarget = target
        return true
    }

    fun finishFulfillmentScan(code: String?) {
        val target = fulfillmentScanTarget ?: return
        fulfillmentScanTarget = null
        val work = activeFulfillmentWork() ?: return
        if (!target.matches(work)) return
        if (code == null) {
            updateFulfillmentWork(work.scope, work.id) { it.copy(notice = "已取消扫描，未提交任何操作") }
            return
        }
        submitFulfillmentPick(target.lineId, code)
    }

    fun submitFulfillmentPick(lineId: String, code: String): Boolean = prepareFulfillmentOperation { detail, scope, opId ->
        FulfillmentOperation.pick(detail, scope, lineId, code, opId)
    }

    fun submitFulfillmentShortage(lineId: String, reason: String): Boolean = prepareFulfillmentOperation { detail, scope, opId ->
        FulfillmentOperation.shortage(detail, scope, lineId, reason, opId)
    }

    fun submitFulfillmentComplete(): Boolean = prepareFulfillmentOperation { detail, scope, opId ->
        FulfillmentOperation.complete(detail, scope, opId)
    }

    private fun prepareFulfillmentOperation(create: (FulfillmentWorkDetail, OrderScope, String) -> FulfillmentOperation): Boolean {
        val work = activeFulfillmentWork() ?: return false
        val detail = work.detail ?: return false
        return runCatching {
            if (!work.canStart) throw FulfillmentGuardException("请先刷新或核对未确认操作")
            val operation = create(detail, work.scope, UUID.randomUUID().toString())
            sendFulfillmentOperation(work, operation)
            true
        }.getOrElse { error ->
            updateFulfillmentWork(work.scope, work.id) { it.copy(error = (error as? FulfillmentGuardException)?.message ?: "当前无法提交，请刷新后重试") }
            false
        }
    }

    fun retryFulfillmentOperation() {
        val work = activeFulfillmentWork() ?: return
        if (work.busy) return
        if (!work.fresh || work.needsReconcile || work.confirmed) {
            readFulfillmentWork(work.scope, work.id)
            return
        }
        val operation = work.pending ?: return
        runCatching { sendFulfillmentOperation(work, operation) }.onFailure { error ->
            updateFulfillmentWork(work.scope, work.id) { it.copy(error = (error as? FulfillmentGuardException)?.message ?: "当前状态不可重试，请刷新") }
        }
    }

    private fun sendFulfillmentOperation(work: FulfillmentWorkState, operation: FulfillmentOperation) {
        val sending = work.beginOperation(operation)
        val detail = work.detail ?: return
        updateFulfillmentWork(work.scope, work.id) { sending }
        viewModelScope.launch {
            if (mutableState.value.orderScope() != work.scope) return@launch
            val result = runCatching { withContext(Dispatchers.IO) { handheld.orderFulfillmentMutation(work.scope, detail, operation) } }
            if (rejectFulfillmentAccess(work.scope, result.exceptionOrNull())) return@launch
            updateFulfillmentWork(work.scope, work.id) { it.receiveMutation(operation, result) }
            if (result.getOrNull() == true) readFulfillmentWork(work.scope, work.id)
        }
    }

    private fun rejectFulfillmentAccess(scope: OrderScope, error: Throwable?): Boolean {
        if (error == null || !isOrderAccessFailure(error) || mutableState.value.orderScope() != scope) return false
        fulfillmentWorkCache.clear()
        fulfillmentScanTarget = null
        mutableState.update {
            if (it.orderScope() == scope) it.copy(
                fulfillmentWork = null,
                orderCenter = it.orderCenter.receive(it.orderCenter.request(), Result.failure(error)),
            ) else it
        }
        return true
    }

    private fun invalidateOrderAndProductRequests() {
        productRequestVersion.incrementAndGet()
        productDetailRequestVersion.incrementAndGet()
        productCache.clear()
        fulfillmentWorkCache.clear()
        fulfillmentScanTarget = null
    }

    fun canOpenParcels(): Boolean = "super_admin" in mutableState.value.roles

    fun parcelCounts(): ParcelCounts = handheld.parcelCounts()

    fun parcels(
        bucket: ParcelBucket,
        mode: ParcelListMode,
        query: String,
        limit: Int,
        offset: Int,
    ): ParcelListResult = handheld.parcels(bucket, mode, query, limit, offset)

    fun parcelDetail(id: String): ParcelDetail = handheld.parcelDetail(id)

    fun estimateParcelPackPieces(itemId: String, source: String): PackPiecesEstimate =
        handheld.estimateParcelPackPieces(itemId, source)

    fun saveParcelPackPieces(itemId: String, pieces: Int?, source: String?, unit: String?): PackPiecesResult =
        handheld.saveParcelPackPieces(itemId, pieces, source, unit)

    private fun saveListingDraftFromState() {
        val current = mutableState.value
        if (
            current.screen == AppScreen.Camera ||
            current.screen == AppScreen.Processing ||
            current.screen == AppScreen.Confirm ||
            current.screen == AppScreen.LabelPreview
        ) {
            listingDraftStore.save(current)
        }
    }

    private fun UiState.withListingDraft(draft: ListingDraft): UiState =
        copy(
            screen = AppScreen.Confirm,
            photo = draft.photoPath.takeIf { it.isNotBlank() }?.let(::File),
            photoBatch = draft.photoPaths.ifEmpty { listOfNotNull(draft.photoPath.takeIf { it.isNotBlank() }) },
            listingStoragePath = draft.listingStoragePath,
            listingStoragePaths = draft.listingStoragePaths.ifEmpty { listOfNotNull(draft.listingStoragePath.takeIf { it.isNotBlank() }) },
            listingImageUrl = draft.listingImageUrl,
            originalPhoto = draft.originalPhotoPath.takeIf { it.isNotBlank() }?.let(::File),
            originalPhotoBatch = draft.originalPhotoPaths.ifEmpty { listOfNotNull(draft.originalPhotoPath.takeIf { it.isNotBlank() }) },
            itemNo = draft.itemNo,
            name = draft.name,
            category = draft.category,
            categoryCode = draft.categoryCode,
            selectedFacetCodes = draft.facetCodes,
            recognitionRequestId = draft.recognitionRequestId,
            classificationStatus = draft.classificationStatus,
            aiSuggestedPriceCny = draft.aiSuggestedPriceCny,
            brand = draft.brand,
            ipName = draft.ipName,
            ipMatchStatus = draft.ipMatchStatus,
            ipConfirmed = draft.ipConfirmed,
            ipSuggestions = draft.ipSuggestions,
            material = draft.material,
            color = draft.color,
            conditionGrade = draft.conditionGrade,
            conditionNote = draft.conditionNote,
            confidence = draft.confidence,
            price = draft.price,
            fankuangOverride = draft.fankuangOverride,
            busy = false,
            printPreviewItem = null,
            status = "已恢复上架草稿，请继续编辑或重新拍照",
        )

    fun sendOtp(phone: String) {
        val normalized = phone.trim()
        if (!normalized.matches(Regex("^1\\d{10}$"))) {
            notify("请输入 11 位手机号", AppScreen.Login)
            return
        }
        mutableState.value = mutableState.value.copy(busy = true, status = "正在发送验证码…")
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { handheld.sendOtp(normalized) }
                .onSuccess {
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        status = "验证码已发送，请查看短信",
                        otpCooldownSeconds = 60,
                    )
                    startOtpCountdown()
                }
                .onFailure {
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        status = "验证码发送失败：${it.message ?: "请稍后重试"}",
                    )
                }
        }
    }

    private fun startOtpCountdown() {
        viewModelScope.launch {
            while (mutableState.value.otpCooldownSeconds > 0) {
                delay(1000)
                mutableState.value = mutableState.value.copy(
                    otpCooldownSeconds = (mutableState.value.otpCooldownSeconds - 1).coerceAtLeast(0),
                )
            }
        }
    }

    fun verifyOtp(phone: String, code: String) {
        val normalizedPhone = phone.trim()
        val normalizedCode = code.trim()
        if (!normalizedPhone.matches(Regex("^1\\d{10}$"))) {
            notify("请输入 11 位手机号", AppScreen.Login)
            return
        }
        if (!normalizedCode.matches(Regex("^\\d{6}$"))) {
            notify("请输入 6 位短信验证码", AppScreen.Login)
            return
        }
        mutableState.update { it.resetHomeMessages().copy(busy = true, loggedIn = false, status = "正在验证并激活设备…") }
        val generation = mutableState.value.homeMessagesGeneration
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.verifyOtp(normalizedPhone, normalizedCode) } }
            if (mutableState.value.homeMessagesGeneration != generation) return@launch
            result
                .onSuccess(::handleLoginSuccess)
                .onFailure {
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        loggedIn = false,
                        screen = AppScreen.Login,
                        status = "验证码登录失败：${it.message ?: "请检查验证码"}",
                    )
                }
        }
    }

    fun login(identity: String, password: String) {
        if (identity.isBlank() || password.isBlank()) {
            notify("请输入手机号和密码", AppScreen.Login)
            return
        }
        mutableState.update { it.resetHomeMessages().copy(busy = true, loggedIn = false, status = "正在登录 ERP…") }
        val generation = mutableState.value.homeMessagesGeneration
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.bootstrap(identity, password) } }
            if (mutableState.value.homeMessagesGeneration != generation) return@launch
            result
                .onSuccess(::handleLoginSuccess)
                .onFailure {
                    val rawMessage = it.message ?: "请检查账号密码"
                    val message = when {
                        rawMessage.contains("Phone logins are disabled", ignoreCase = true) ->
                            "当前 ERP 后台未开启手机号登录，请改用 ERP 邮箱登录，或让 Lovable 开启 phone login"

                        else -> rawMessage
                    }
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        loggedIn = false,
                        screen = AppScreen.Login,
                        status = "ERP 登录失败：$message",
                    )
                }
        }
    }

    private fun handleLoginSuccess(result: BootstrapResult) {
        invalidateOrderAndProductRequests()
        val hasSelectedLocation = result.selectedLocation != null
        val hasNoAuthorizedLocation = result.locations.isEmpty() && !hasSelectedLocation
        mutableState.value = mutableState.value.resetHomeMessages().resetOrderCenter().resetProducts().copy(
            busy = false,
            loggedIn = true,
            locationSwitching = false,
            userName = result.userName,
            roles = result.roles,
            locations = result.locations,
            selectedLocation = result.selectedLocation,
            screen = if (hasSelectedLocation) AppScreen.Dashboard else AppScreen.LocationSelect,
            status = when {
                hasSelectedLocation -> "已登录：${result.selectedLocation.name}"
                hasNoAuthorizedLocation -> "当前账号未授权任何库位，请联系管理员"
                else -> "登录成功，请选择当前操作门店/仓库"
            },
            otpCooldownSeconds = 0,
        )
        result.selectedLocation?.let {
            loadDashboard(it.id)
            loadProductsFromErp()
        }
        loadProductCategories()
        refreshLabelTemplates(silent = true)
    }

    fun loadProductCategories() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { handheld.productTaxonomy() }
                .onSuccess { taxonomy ->
                    val current = mutableState.value
                    val allowedCodes = ProductCategoryContract.facetsForCategory(
                        current.categoryCode,
                        taxonomy.categories,
                        taxonomy.facets,
                    ).mapTo(mutableSetOf()) { it.code }
                    mutableState.value = current.copy(
                        listingCategoryOptions = taxonomy.categories,
                        listingFacetOptions = taxonomy.facets,
                        selectedFacetCodes = current.selectedFacetCodes.filter(allowedCodes::contains),
                    )
                }
        }
    }

    fun loadLocations() {
        val generation = mutableState.value.homeMessagesGeneration
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.locations() } }
            if (mutableState.value.homeMessagesGeneration != generation) return@launch
            result
                .onSuccess { locations ->
                    val selected = session.selectedLocation()
                    val current = mutableState.value
                    val scopeChanged = current.selectedLocation != selected || current.locations != locations ||
                        current.roles != session.roles || current.userName != session.userName
                    if (scopeChanged) invalidateOrderAndProductRequests()
                    mutableState.value = (if (scopeChanged) current.resetHomeMessages().resetOrderCenter().resetProducts() else current).copy(
                        locations = locations,
                        selectedLocation = selected,
                        roles = session.roles,
                        userName = session.userName,
                    )
                    if (scopeChanged) loadProductsFromErp()
                }
                .onFailure {
                    if (!session.hasAuth || it.message?.contains("session token", ignoreCase = true) == true) {
                        handleAuthLost("登录已过期，请重新获取验证码登录")
                        return@onFailure
                    }
                    val keepExisting = mutableState.value.locations.isNotEmpty()
                    mutableState.value = mutableState.value.copy(
                        status = if (keepExisting) {
                            "库位刷新失败，继续使用登录返回的库位"
                        } else {
                            "门店/仓库列表获取失败：${it.message ?: "请检查网络"}"
                        },
                    )
                }
        }
    }

    fun refreshEmployeeProfile() {
        if (!session.hasAuth) return
        val generation = mutableState.value.homeMessagesGeneration
        viewModelScope.launch {
            val profile = runCatching { withContext(Dispatchers.IO) { handheld.currentEmployeeProfile() } }.getOrNull() ?: return@launch
            if (!session.hasAuth || mutableState.value.homeMessagesGeneration != generation) return@launch
            session.saveUser(profile.name, profile.roles, profile.avatarUrl)
            val current = mutableState.value
            val changed = current.userName != profile.name || current.roles != profile.roles
            if (changed) invalidateOrderAndProductRequests()
            mutableState.value = (if (changed) current.resetHomeMessages().resetOrderCenter().resetProducts() else current).copy(
                userName = profile.name, roles = profile.roles, employeeAvatarUrl = profile.avatarUrl)
        }
    }

    fun switchLocation(location: HandheldLocation) {
        if (mutableState.value.locationSwitching) return
        invalidateOrderAndProductRequests()
        mutableState.update { it.resetHomeMessages().resetOrderCenter().resetProducts().copy(busy = true, locationSwitching = true, status = "正在切换到 ${location.name}…") }
        val generation = mutableState.value.homeMessagesGeneration
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.switchLocation(location) } }
            if (mutableState.value.homeMessagesGeneration != generation) return@launch
            result
                .onSuccess { switched ->
                    session.saveSelectedLocation(switched)
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        locationSwitching = false,
                        selectedLocation = switched,
                        screen = AppScreen.Dashboard,
                        status = "当前操作位置：${switched.name}",
                    )
                    loadDashboard(switched.id)
                    loadProductsFromErp()
                }
                .onFailure {
                    if (!session.hasAuth || it.message?.contains("session token", ignoreCase = true) == true) {
                        handleAuthLost("登录已过期，请重新获取验证码登录")
                        return@onFailure
                    }
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        locationSwitching = false,
                        status = "切换门店/仓库失败：${it.message ?: "请重试"}",
                    )
                }
        }
    }

    fun loadDashboard(locationId: String? = mutableState.value.selectedLocation?.id) {
        val current = mutableState.value
        if (!current.loggedIn || current.locationSwitching || locationId.isNullOrBlank() || locationId != current.selectedLocation?.id) return
        val request = current.homeMessagesRequest(current.dashboardRequestId + 1)
        mutableState.update { it.copy(dashboardLoading = true, dashboardRequestId = request.sequence) }
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.dashboard(locationId) } }
            mutableState.update { it.withDashboardResult(request, result) }
        }
    }

    fun loadMessages() {
        val current = mutableState.value
        val locationId = current.selectedLocation?.id
        if (!current.loggedIn || current.locationSwitching || locationId.isNullOrBlank()) return
        val request = current.homeMessagesRequest(current.messagesRequestId + 1)
        mutableState.update { it.copy(messagesLoading = true, messagesError = "", messagesRequestId = request.sequence) }
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.notifications(locationId) } }
            mutableState.update { it.withMessagesResult(request, result) }
        }
    }

    fun loadProductsFromErp(query: String = mutableState.value.search) {
        val requestVersion = productRequestVersion.incrementAndGet()
        val loadingState = mutableState.value
        if (loadingState.loggedIn && !session.hasAuth) {
            handleAuthLost("登录已过期，请重新获取验证码登录")
            return
        }
        val scope = loadingState.productScope()
        if (scope == null || !productSessionMatches(scope)) {
            productCache.clear()
            mutableState.value = loadingState.resetProducts()
            return
        }
        val productQuery = loadingState.productQuery(query)
        val cacheKey = ProductCacheKey(scope, productQuery)
        val cached = productCache[cacheKey]
        val scopeLabel = loadingState.productScopeLabel()
        mutableState.value = loadingState.copy(
            search = productQuery.q,
            items = cached?.items ?: emptyList(),
            productCounts = cached?.counts ?: ProductCounts(),
            selectedItem = null,
            productError = "",
            productLoading = true,
            status = cached?.let {
                val secondsAgo = ((System.currentTimeMillis() - it.loadedAtMillis) / 1000).coerceAtLeast(0)
                "已显示缓存商品，后台刷新中（${secondsAgo}秒前）"
            } ?: "正在同步 $scopeLabel 商品…",
        )
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.products(scope, productQuery) } }
            val current = mutableState.value
            if (!cacheKey.accepts(current.productScope(), current.productQuery(), requestVersion, productRequestVersion.get())) return@launch
            if (!session.hasAuth) {
                handleAuthLost("登录已过期，请重新获取验证码登录")
                return@launch
            }
            if (!productSessionMatches(scope)) {
                productCache.clear()
                mutableState.value = current.resetProducts()
                return@launch
            }
            result.onSuccess { page ->
                val erpItems = page.items.map { it.toItem() }
                val missingImageCount = erpItems.count { it.imagePath.isBlank() }
                val statusText = if (erpItems.isEmpty()) {
                    "$scopeLabel 当前没有匹配商品"
                } else if (missingImageCount > 0) {
                    "已同步 $scopeLabel 商品 ${erpItems.size} 件；其中 $missingImageCount 件 ERP 未返回图片"
                } else {
                    "已同步 $scopeLabel 商品 ${erpItems.size} 件"
                }
                productCache[cacheKey] = ProductCacheEntry(
                    items = erpItems,
                    counts = page.counts,
                    status = statusText,
                    loadedAtMillis = System.currentTimeMillis(),
                )
                mutableState.value = mutableState.value.copy(
                    items = erpItems,
                    productCounts = page.counts,
                    productLoading = false,
                    status = statusText,
                )
            }.onFailure {
                if (!session.hasAuth || (it as? HandheldApiException)?.httpCode == 401) {
                    handleAuthLost("登录已过期，请重新获取验证码登录")
                    return@onFailure
                }
                val failClosed = it is ProductScopeException || (it as? HandheldApiException)?.httpCode == 403
                if (failClosed) productCache.clear()
                val fallback = cached.takeUnless { failClosed }
                val error = "商品列表读取失败：${it.message ?: "请检查 ERP 商品接口"}"
                mutableState.value = mutableState.value.copy(
                    items = fallback?.items ?: emptyList(),
                    productCounts = fallback?.counts ?: ProductCounts(),
                    selectedItem = null,
                    productLoading = false,
                    productError = error,
                    status = fallback?.let { entry ->
                        "商品刷新失败，继续显示缓存：${entry.status}"
                    } ?: error,
                )
            }
        }
    }

    private fun productSessionMatches(scope: ProductScope): Boolean = session.hasAuth &&
        session.userName == scope.userName && session.roles == scope.roles &&
        session.selectedLocation()?.id == scope.locationId && session.selectedLocation()?.kind == scope.locationKind

    fun selectProductScope(view: ProductViewScope) {
        val current = mutableState.value
        if (view == current.productViewScope || (view == ProductViewScope.All && !current.canShowHQTools)) return
        productRequestVersion.incrementAndGet()
        productCache.clear()
        mutableState.value = current.resetProducts().copy(productViewScope = view)
        loadProductsFromErp()
    }

    fun selectProductType(type: String) {
        val nextHasImage = if (type == "custom") mutableState.value.productHasImage else null
        mutableState.value = mutableState.value.copy(productType = type, productHasImage = nextHasImage)
        loadProductsFromErp()
    }

    fun selectProductSort(sort: String) {
        mutableState.value = mutableState.value.copy(productSort = sort)
        loadProductsFromErp()
    }

    fun selectProductCategory(category: String) {
        mutableState.value = mutableState.value.copy(productCategory = category)
        loadProductsFromErp()
    }

    fun toggleProductHasImage(hasImage: Boolean?) {
        mutableState.value = mutableState.value.copy(productHasImage = hasImage)
        loadProductsFromErp()
    }

    fun selectProductStatus(status: String) {
        mutableState.value = mutableState.value.copy(productStatus = status)
        loadProductsFromErp()
    }

    fun toggleProductFankuang() {
        mutableState.value = mutableState.value.copy(productOnlyFankuang = !mutableState.value.productOnlyFankuang)
        loadProductsFromErp()
    }

    fun openGlobalStock() {
        mutableState.value = mutableState.value.copy(screen = AppScreen.GlobalStock)
        loadGlobalStock()
    }

    fun setGlobalStockView(view: String) {
        mutableState.value = mutableState.value.copy(globalStockView = view)
    }

    fun setGlobalStockState(stockState: String) {
        mutableState.value = mutableState.value.copy(globalStockState = stockState)
        loadGlobalStock()
    }

    fun loadGlobalStock() {
        val current = mutableState.value
        if (!session.hasAuth) return
        mutableState.value = current.copy(globalStockLoading = true)
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                handheld.globalStock(
                    type = current.productType.takeIf { it in setOf("custom", "bundle", "standard") } ?: "custom",
                    query = current.search.trim(),
                    category = current.productCategory,
                    stockState = current.globalStockState,
                    status = current.productStatus,
                )
            }.onSuccess { data ->
                mutableState.value = mutableState.value.copy(
                    globalStock = data,
                    globalStockLoading = false,
                    status = "已读取全局库存 ${data.items.size} 个 SKU",
                )
            }.onFailure {
                mutableState.value = mutableState.value.copy(
                    globalStockLoading = false,
                    status = "全局库存读取失败：${it.message ?: "请确认 ERP 已发布 global-stock 接口"}",
                )
            }
        }
    }

    fun logout() {
        invalidateOrderAndProductRequests()
        val cleared = mutableState.value.resetHomeMessages().resetOrderCenter().resetProducts()
        session.clearAuth()
        mutableState.value = UiState(
            homeMessagesGeneration = cleared.homeMessagesGeneration,
            screen = AppScreen.Login,
            items = emptyList(),
            installId = session.installId,
            printOffsetXDots = printerPreferences.getInt(PRINT_OFFSET_X, 0),
            printOffsetYDots = printerPreferences.getInt(PRINT_OFFSET_Y, DEFAULT_PRINT_OFFSET_Y_DOTS),
            status = "已退出，请重新登录 ERP",
        )
    }

    private fun handleAuthLost(message: String) {
        invalidateOrderAndProductRequests()
        val cleared = mutableState.value.resetHomeMessages().resetOrderCenter().resetProducts()
        session.clearAuth()
        mutableState.value = UiState(
            homeMessagesGeneration = cleared.homeMessagesGeneration,
            screen = AppScreen.Login,
            items = emptyList(),
            installId = session.installId,
            loggedIn = false,
            printHistory = printHistoryStore.all(),
            labelTemplates = labelTemplateStore.templates(),
            labelTemplatesCanManage = false,
            printOffsetXDots = printerPreferences.getInt(PRINT_OFFSET_X, 0),
            printOffsetYDots = printerPreferences.getInt(PRINT_OFFSET_Y, DEFAULT_PRINT_OFFSET_Y_DOTS),
            status = message,
        )
    }

    fun notify(message: String, screen: AppScreen? = null) {
        val current = mutableState.value
        mutableState.value = current.copy(
            status = message,
            screen = screen ?: current.screen,
        )
    }

    fun onPhotoTaken(file: File) {
        addPhotoToBatch(file)
        mutableState.value = mutableState.value.copy(
            screen = AppScreen.Camera,
            busy = false,
            status = "已加入 ${mutableState.value.photoBatch.size} 张照片，可继续拍摄其他角度",
        )
    }

    fun addPhotoToBatch(file: File) {
        if (!file.exists() || file.length() <= 0L) {
            notify("照片保存失败，请重拍或从相册选择")
            return
        }
        val path = file.absolutePath
        val current = mutableState.value
        val next = (current.photoBatch + path).distinct().take(6)
        mutableState.value = current.copy(
            photo = path.let(::File),
            photoBatch = next,
            originalPhoto = path.let(::File),
            originalPhotoBatch = next,
            status = "已加入 ${next.size} 张照片，拍完后再一起识别",
        )
        saveListingDraftFromState()
    }

    fun removePhotoFromBatch(path: String) {
        val current = mutableState.value
        val next = current.photoBatch.filterNot { it == path }
        val main = next.firstOrNull()?.let(::File)
        mutableState.value = current.copy(
            photo = main,
            photoBatch = next,
            originalPhoto = main,
            originalPhotoBatch = next,
            status = if (next.isEmpty()) "请先拍摄商品照片" else "已保留 ${next.size} 张照片",
        )
        saveListingDraftFromState()
    }

    fun startBatchRecognition() {
        val paths = mutableState.value.photoBatch
            .map(::File)
            .filter { it.exists() && it.length() > 0L }
            .take(6)
        if (paths.isEmpty()) {
            notify("请先拍摄至少 1 张照片")
            return
        }
        val main = paths.first()
        mutableState.value = mutableState.value.copy(
            screen = AppScreen.Confirm,
            photo = main,
            photoBatch = paths.map { it.absolutePath },
            originalPhoto = main,
            originalPhotoBatch = paths.map { it.absolutePath },
            busy = true,
            status = "正在上传原图，可先填写价格",
        )
        saveListingDraftFromState()
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val uploaded = mutableListOf<PreparedListingImage>()
                for (batch in planListingImageBatches(paths, maxParallel = 2)) {
                    val results = coroutineScope {
                        batch.map { plan ->
                            async { api.uploadRawImage(plan.source) }
                        }.awaitAll()
                    }
                    uploaded += results
                }
                val storagePaths = uploaded.map { it.storagePath }.filter { it.isNotBlank() }.distinct()
                mutableState.value = mutableState.value.copy(
                    listingStoragePath = storagePaths.firstOrNull().orEmpty(),
                    listingStoragePaths = storagePaths,
                    status = "原图已保存，AI 正在识别商品",
                )
                saveListingDraftFromState()
                api.recognizeUploadedImages(uploaded, bucket = "sku-raw") to uploaded
            }.onSuccess { (recognized, uploaded) ->
                val storagePaths = uploaded.map { it.storagePath }.filter { it.isNotBlank() }.distinct()
                val recognitionNote = recognized.warning.ifBlank {
                    if (recognized.alternatives.isNotEmpty()) {
                        "AI 给出 ${recognized.alternatives.size} 个备选，请人工确认名称和分类"
                    } else {
                        ""
                    }
                }
                val recognizedCategory = mutableState.value.listingCategoryOptions
                    .firstOrNull { option -> option.code == recognized.categoryCode }
                    ?.displayName
                    ?: recognized.category
                mutableState.value = mutableState.value.copy(
                    itemNo = ItemNumber.createForDevice(getApplication()),
                    name = recognized.name,
                    category = recognizedCategory,
                    categoryCode = recognized.categoryCode,
                    status = "已生成标题与分类，正在补充 IP 和标签",
                )
                delay(80)
                mutableState.value = mutableState.value.copy(
                    selectedFacetCodes = recognized.facetCodes,
                    recognitionRequestId = recognized.requestId,
                    classificationStatus = recognized.classificationStatus,
                    aiSuggestedPriceCny = recognized.suggestedPriceCny,
                    brand = recognized.brand,
                    ipName = recognized.ipName,
                    ipMatchStatus = recognized.ipMatchStatus,
                    ipConfirmed = recognized.ipMatchStatus != "review_required" || recognized.ipSuggestions.isEmpty(),
                    ipSuggestions = recognized.ipSuggestions,
                    status = "已识别 IP 和标签，正在补充成色与介绍",
                )
                delay(80)
                val currentPrice = mutableState.value.price
                mutableState.value = mutableState.value.copy(
                    material = recognized.material,
                    color = recognized.color,
                    conditionGrade = recognized.conditionGrade,
                    conditionNote = recognized.conditionNote,
                    confidence = recognized.confidence,
                    price = currentPrice.ifBlank {
                        recognized.suggestedPriceCny?.takeIf { price -> price > 0.0 }?.let { price ->
                            if (price % 1.0 == 0.0) price.toInt().toString() else "%.2f".format(price)
                        }.orEmpty()
                    },
                    photo = main,
                    photoBatch = paths.map { it.absolutePath },
                    originalPhoto = main,
                    originalPhotoBatch = paths.map { it.absolutePath },
                    listingStoragePath = storagePaths.firstOrNull().orEmpty(),
                    listingStoragePaths = storagePaths,
                    listingImageUrl = "",
                    busy = false,
                    screen = AppScreen.Confirm,
                    status = listOf(
                        "AI 识别完成，请确认必要字段和售价",
                        recognitionNote,
                        "请确认名称、分类和价格",
                    ).filter { it.isNotBlank() }.joinToString("；"),
                )
                saveListingDraftFromState()
            }.onFailure {
                mutableState.value = mutableState.value.copy(
                    itemNo = ItemNumber.createForDevice(getApplication()),
                    name = "",
                    category = "",
                    categoryCode = "",
                    selectedFacetCodes = emptyList(),
                    recognitionRequestId = "",
                    classificationStatus = "",
                    aiSuggestedPriceCny = null,
                    brand = "",
                    ipName = "",
                    ipMatchStatus = "empty",
                    ipConfirmed = true,
                    ipSuggestions = emptyList(),
                    material = "",
                    color = "",
                    conditionGrade = "",
                    conditionNote = "",
                    busy = false,
                    screen = AppScreen.Confirm,
                    status = "AI/ERP 未完成识别：${it.message ?: "请检查设备 token、登录和网络"}",
                )
                saveListingDraftFromState()
            }
        }
    }

    fun clearPhoto() {
        mutableState.value = mutableState.value.copy(
            photo = null,
            photoBatch = emptyList(),
            originalPhoto = null,
            originalPhotoBatch = emptyList(),
            listingStoragePath = "",
            listingStoragePaths = emptyList(),
            listingImageUrl = "",
            status = "已移除照片，请重新拍摄或选择图片",
        )
        saveListingDraftFromState()
    }

    fun updateName(value: String) {
        mutableState.value = mutableState.value.copy(name = value)
        saveListingDraftFromState()
    }

    fun updatePrice(value: String) {
        if (value.count { it == '.' } <= 1 && value.all { it.isDigit() || it == '.' }) {
            mutableState.value = mutableState.value.copy(price = value)
            saveListingDraftFromState()
        }
    }

    fun updateFankuangEnrollment(enabled: Boolean) {
        mutableState.value = mutableState.value.copy(fankuangOverride = enabled)
        saveListingDraftFromState()
    }

    fun updateCategory(value: String) {
        mutableState.value = mutableState.value.copy(category = value, categoryCode = "")
        saveListingDraftFromState()
    }

    fun selectListingCategory(code: String) {
        val current = mutableState.value
        val option = current.listingCategoryOptions.firstOrNull { it.code == code } ?: return
        val allowedCodes = ProductCategoryContract.facetsForCategory(
            code,
            current.listingCategoryOptions,
            current.listingFacetOptions,
        ).mapTo(mutableSetOf()) { it.code }
        mutableState.value = current.copy(
            category = option.displayName,
            categoryCode = option.code,
            selectedFacetCodes = current.selectedFacetCodes.filter(allowedCodes::contains),
        )
        saveListingDraftFromState()
    }

    fun listingFacetsForCurrentCategory(): List<ProductFacetOption> {
        val current = mutableState.value
        return ProductCategoryContract.facetsForCategory(
            current.categoryCode,
            current.listingCategoryOptions,
            current.listingFacetOptions,
        )
    }

    fun toggleListingFacet(code: String) {
        val current = mutableState.value
        if (listingFacetsForCurrentCategory().none { it.code == code }) return
        val next = if (code in current.selectedFacetCodes) {
            current.selectedFacetCodes - code
        } else {
            (current.selectedFacetCodes + code).distinct().take(20)
        }
        mutableState.value = current.copy(selectedFacetCodes = next)
        saveListingDraftFromState()
    }

    fun updateConditionGrade(value: String) {
        mutableState.value = mutableState.value.copy(conditionGrade = value)
        saveListingDraftFromState()
    }

    fun updateIpName(value: String) {
        mutableState.value = mutableState.value.copy(
            ipName = value,
            ipMatchStatus = if (value.isBlank()) "empty" else "review_required",
            ipConfirmed = value.isBlank(),
        )
        saveListingDraftFromState()
    }

    fun confirmIpName() {
        mutableState.value = mutableState.value.copy(ipConfirmed = true)
        saveListingDraftFromState()
    }

    fun updateConditionNote(value: String) {
        mutableState.value = mutableState.value.copy(conditionNote = value)
        saveListingDraftFromState()
    }

    fun updateSearch(value: String) {
        mutableState.value = mutableState.value.copy(search = value)
        if (mutableState.value.screen == AppScreen.Products) loadProductsFromErp(value)
    }

    fun selectItem(item: Item) {
        val current = mutableState.value
        val scopedDetail = current.screen == AppScreen.Products && current.loggedIn && item.sourceLabel == "ERP"
        if (scopedDetail && (current.productScope() == null || item.erpId.isBlank() || current.items.none { it.erpId == item.erpId })) return
        productDetailRequestVersion.incrementAndGet()
        mutableState.value = current.copy(selectedItem = if (scopedDetail) null else item,
            printPreviewItem = null, screen = AppScreen.ProductDetail,
            productDetailId = if (scopedDetail) item.erpId else "", productDetailError = "", productDetailLoading = false)
        if (scopedDetail) loadProductDetail()
    }

    fun loadProductDetail() {
        val current = mutableState.value
        val scope = current.productScope() ?: return
        val id = current.productDetailId
        if (current.screen != AppScreen.ProductDetail || id.isBlank() || !productSessionMatches(scope)) return
        val key = ProductCacheKey(scope, current.productQuery())
        val sequence = productDetailRequestVersion.incrementAndGet()
        mutableState.value = current.copy(selectedItem = null, productDetailLoading = true, productDetailError = "")
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.itemDetail(scope, id).toItem() } }
            val latest = mutableState.value
            if (!latest.acceptsProductDetail(key, id, sequence, productDetailRequestVersion.get())) return@launch
            if (!session.hasAuth) { handleAuthLost("登录已过期，请重新登录"); return@launch }
            if (!productSessionMatches(scope)) { productCache.clear(); mutableState.value = latest.resetProducts(); return@launch }
            result.onSuccess { item ->
                mutableState.value = latest.copy(selectedItem = item, productDetailLoading = false)
            }.onFailure { error ->
                if ((error as? HandheldApiException)?.httpCode == 401) { handleAuthLost("登录已过期，请重新登录"); return@onFailure }
                val failClosed = error is ProductScopeException || (error as? HandheldApiException)?.httpCode in listOf(403, 404)
                if (failClosed) productCache.clear()
                mutableState.value = latest.copy(selectedItem = null, productDetailLoading = false,
                    items = if (failClosed) emptyList() else latest.items,
                    productCounts = if (failClosed) ProductCounts() else latest.productCounts,
                    productDetailError = "商品详情读取失败：${error.message ?: "请重试"}")
            }
        }
    }

    fun openLabelPreviewForItem(item: Item) {
        mutableState.value = mutableState.value.copy(
            selectedItem = item,
            printPreviewItem = item,
            status = "请选择模板后打印：${item.itemNo}",
            screen = AppScreen.LabelPreview,
        )
    }

    fun setSelectedItemFankuang(enabled: Boolean) {
        val current = mutableState.value
        val item = current.selectedItem ?: return
        val scope = current.productScope() ?: return
        val cacheKey = ProductCacheKey(scope, current.productQuery())
        val requestVersion = productRequestVersion.get()
        if (current.busy || current.productDetailLoading || item.canEdit != true ||
            item.updatedAt.isBlank() || item.productType != "custom" || !productSessionMatches(scope)) return
        mutableState.update { it.copy(busy = true, status = "正在保存翻筐乐设置…") }
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) {
                handheld.setItemFankuang(scope, item, enabled)
                handheld.itemDetail(scope, item.erpId).toItem()
            } }
            val latest = mutableState.value
            if (!cacheKey.accepts(latest.productScope(), latest.productQuery(), requestVersion, productRequestVersion.get())) return@launch
            if (!session.hasAuth) { handleAuthLost("登录已过期，请重新登录"); return@launch }
            if (!productSessionMatches(scope)) { mutableState.value = latest.resetProducts(); return@launch }
            result.onSuccess { updated ->
                refreshProductsAfterMutation()
                mutableState.update { it.copy(selectedItem = updated, busy = false, status = "翻筐乐设置已保存") }
            }.onFailure { error ->
                mutableState.update { it.copy(busy = false, status = "设置未确认：${error.message ?: "请重试"}") }
                reloadSelectedProductDetail()
            }
        }
    }

    fun setSelectedItemDisplay(isDisplay: Boolean) {
        val current = mutableState.value
        val item = current.selectedItem ?: return
        val scope = current.productScope() ?: return
        val cacheKey = ProductCacheKey(scope, current.productQuery())
        val requestVersion = productRequestVersion.get()
        if (current.busy || !productSessionMatches(scope)) return
        mutableState.value = mutableState.value.copy(busy = true, status = if (isDisplay) "正在恢复上架…" else "正在下架商品…")
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.setItemDisplay(item.itemNo, isDisplay).toItem() } }
            val latest = mutableState.value
            if (!cacheKey.accepts(latest.productScope(), latest.productQuery(), requestVersion, productRequestVersion.get())) return@launch
            if (!session.hasAuth) { handleAuthLost("登录已过期，请重新登录"); return@launch }
            if (!productSessionMatches(scope)) { mutableState.value = latest.resetProducts(); return@launch }
            result
                .onSuccess { updated ->
                    refreshProductsAfterMutation()
                    mutableState.value = mutableState.value.copy(
                        selectedItem = updated,
                        busy = false,
                        status = "${updated.name} ${updated.statusLabel}",
                    )
                    reloadSelectedProductDetail()
                }
                .onFailure {
                    if (!session.hasAuth || it.message?.contains("session token", ignoreCase = true) == true) {
                        handleAuthLost("登录已过期，请重新获取验证码登录")
                        return@onFailure
                    }
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        status = "状态更新失败：${it.message ?: "请检查 ERP 接口"}",
                    )
                }
        }
    }

    fun restockSelectedItem(delta: Int = 1, printLabels: Boolean = true) {
        val current = mutableState.value
        val item = current.selectedItem ?: return
        val scope = current.productScope() ?: return
        val cacheKey = ProductCacheKey(scope, current.productQuery())
        val requestVersion = productRequestVersion.get()
        if (current.busy || !productSessionMatches(scope)) return
        val templateId = labelTemplate().id
        mutableState.value = mutableState.value.copy(busy = true, status = "正在补货入库…")
        viewModelScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { handheld.restockItem(item.itemNo, scope.locationId, delta, printLabels, templateId).toItem() } }
            val latest = mutableState.value
            if (!cacheKey.accepts(latest.productScope(), latest.productQuery(), requestVersion, productRequestVersion.get())) return@launch
            if (!session.hasAuth) { handleAuthLost("登录已过期，请重新登录"); return@launch }
            if (!productSessionMatches(scope)) { mutableState.value = latest.resetProducts(); return@launch }
            result
                .onSuccess { updated ->
                    refreshProductsAfterMutation()
                    mutableState.value = mutableState.value.copy(
                        selectedItem = updated,
                        printPreviewItem = if (printLabels) updated else mutableState.value.printPreviewItem,
                        busy = false,
                        status = if (printLabels) "补货成功，已生成 $delta 张标签，请进入打印预览确认" else "补货成功",
                        screen = if (printLabels) AppScreen.LabelPreview else mutableState.value.screen,
                    )
                    reloadSelectedProductDetail()
                }
                .onFailure {
                    if (!session.hasAuth || it.message?.contains("session token", ignoreCase = true) == true) {
                        handleAuthLost("登录已过期，请重新获取验证码登录")
                        return@onFailure
                    }
                    mutableState.value = mutableState.value.copy(
                        busy = false,
                        status = "补货失败：${it.message ?: "请检查 ERP restock 接口"}",
                    )
                }
        }
    }

    fun newListing() {
        val current = mutableState.value
        val draft = listingDraftStore.load()
        if (draft != null) {
            mutableState.value = current.withListingDraft(draft).copy(secondTab = current.secondTab.leave())
            return
        }
        mutableState.value = UiState(
            screen = AppScreen.Camera,
            secondTab = current.secondTab.leave(),
            orderCenter = current.orderCenter,
            fulfillmentWork = current.fulfillmentWork,
            items = current.items,
            productViewScope = current.productViewScope,
            productCounts = current.productCounts,
            locations = current.locations,
            selectedLocation = current.selectedLocation,
            userName = current.userName,
            roles = current.roles,
            dashboard = current.dashboard,
            dashboardLoading = current.dashboardLoading,
            homeMessagesGeneration = current.homeMessagesGeneration,
            dashboardRequestId = current.dashboardRequestId,
            messagesRequestId = current.messagesRequestId,
            messages = current.messages,
            messagesLoading = current.messagesLoading,
            messagesError = current.messagesError,
            locationSwitching = current.locationSwitching,
            installId = session.installId,
            loggedIn = session.hasAuth,
            printHistory = current.printHistory,
            labelTemplates = current.labelTemplates,
            labelTemplatesCanManage = current.labelTemplatesCanManage,
            printOffsetXDots = current.printOffsetXDots,
            printOffsetYDots = current.printOffsetYDots,
            status = "请拍摄商品照片",
        )
    }

    fun saveOnly() {
        val item = saveCurrent() ?: return
        listingDraftStore.clear()
        mutableState.value = mutableState.value.copy(
            items = emptyList(),
            productCounts = ProductCounts(),
            status = "已保存：${item.itemNo}",
            screen = AppScreen.Products,
            secondTab = mutableState.value.secondTab.select(SecondTabMode.Products, SystemClock.uptimeMillis()),
        )
    }

    fun labelTemplate(type: PrintTemplateType = PrintTemplateType.LABEL): LabelTemplate =
        labelTemplateStore.load(type)

    fun labelTemplates(type: PrintTemplateType? = null): List<LabelTemplate> =
        labelTemplateStore.templates(type)

    fun refreshLabelTemplates(silent: Boolean = false) {
        if (!session.hasAuth) {
            mutableState.value = mutableState.value.copy(
                labelTemplates = labelTemplateStore.templates(),
                labelTemplatesCanManage = false,
            )
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { handheld.labelTemplates() }
                .onSuccess { cloud ->
                    if (cloud.items.isNotEmpty()) {
                        labelTemplateStore.replaceAll(cloud.defaultTemplateIds, cloud.items)
                    }
                    mutableState.value = mutableState.value.copy(
                        labelTemplates = labelTemplateStore.templates(),
                        labelTemplatesCanManage = cloud.canManage,
                        status = if (silent) mutableState.value.status else "已同步总部标签模板",
                    )
                }
                .onFailure {
                    mutableState.value = mutableState.value.copy(
                        labelTemplates = labelTemplateStore.templates(),
                        labelTemplatesCanManage = mutableState.value.labelTemplatesCanManage ?: canManageTemplatesByRole(mutableState.value.roles),
                        status = if (silent) mutableState.value.status else "总部模板同步失败，已使用本机缓存：${it.message ?: "网络异常"}",
                    )
                }
        }
    }

    fun saveLabelTemplate(template: LabelTemplate) {
        labelTemplateStore.save(template)
        mutableState.value = mutableState.value.copy(
            labelTemplates = labelTemplateStore.templates(),
            editingLabelTemplate = template,
            status = "标签模板已保存为默认样式",
        )
        syncSaveLabelTemplate(template, makeDefault = true)
    }

    fun setDefaultLabelTemplate(template: LabelTemplate) {
        labelTemplateStore.setDefault(template)
        mutableState.value = mutableState.value.copy(
            labelTemplates = labelTemplateStore.templates(),
            status = "已设为默认模板：${template.templateName}",
        )
        syncSetDefaultLabelTemplate(template)
    }

    fun editLabelTemplate(template: LabelTemplate, returnTo: AppScreen = AppScreen.PrinterSettings) {
        mutableState.value = mutableState.value.copy(
            editingLabelTemplate = template,
            labelTemplateReturnScreen = returnTo,
            screen = AppScreen.LabelTemplateEditor,
        )
    }

    fun createLabelTemplate(type: PrintTemplateType = PrintTemplateType.LABEL) {
        val template = labelTemplateStore.createTemplate(type)
        mutableState.value = mutableState.value.copy(
            editingLabelTemplate = template,
            screen = AppScreen.LabelTemplateEditor,
            status = "正在新建模板，保存后才会加入模板库",
        )
    }

    fun deleteLabelTemplate(template: LabelTemplate) {
        labelTemplateStore.deleteTemplate(template.id)
        mutableState.value = mutableState.value.copy(
            labelTemplates = labelTemplateStore.templates(),
            editingLabelTemplate = null,
            status = "已删除模板：${template.templateName}",
        )
        if (canManageCloudTemplates()) {
            viewModelScope.launch(Dispatchers.IO) {
                runCatching { handheld.deleteLabelTemplate(template.id) }
                    .onSuccess { refreshLabelTemplates(silent = true) }
                    .onFailure {
                        mutableState.value = mutableState.value.copy(status = "本机已删除，云端删除失败：${it.message ?: "请重试"}")
                    }
            }
        }
    }

    fun updateEditingLabelTemplate(template: LabelTemplate) {
        mutableState.value = mutableState.value.copy(editingLabelTemplate = template)
    }

    fun saveEditingLabelTemplate(template: LabelTemplate) {
        labelTemplateStore.saveTemplate(template)
        mutableState.value = mutableState.value.copy(
            labelTemplates = labelTemplateStore.templates(),
            editingLabelTemplate = template,
            status = "模板已保存：${template.templateName}",
        )
        syncSaveLabelTemplate(template)
    }

    private fun syncSaveLabelTemplate(template: LabelTemplate, makeDefault: Boolean = false) {
        if (!canManageCloudTemplates()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                if (template.id.startsWith("tpl_") || template.id == "default") {
                    handheld.createLabelTemplate(template, isDefault = makeDefault)
                } else {
                    val updated = handheld.updateLabelTemplate(template)
                    if (makeDefault) handheld.setDefaultLabelTemplate(updated.id)
                    updated
                }
            }.onSuccess { saved ->
                val currentDefaultIds = PrintTemplateType.entries.associateWith { type ->
                    labelTemplateStore.load(type).id
                }
                val currentDefaultId = currentDefaultIds[template.printType].orEmpty()
                val nextDefaultId = if (currentDefaultId == template.id) saved.id else currentDefaultId
                val nextTemplates = (labelTemplateStore.templates().filterNot { it.id == template.id || it.id == saved.id } + saved)
                labelTemplateStore.replaceAll(
                    currentDefaultIds + (template.printType to nextDefaultId),
                    nextTemplates,
                )
                mutableState.value = mutableState.value.copy(
                    labelTemplates = labelTemplateStore.templates(),
                    editingLabelTemplate = saved,
                    status = "总部模板已同步：${saved.templateName}",
                )
                refreshLabelTemplates(silent = true)
            }.onFailure {
                mutableState.value = mutableState.value.copy(status = "模板已本机保存，云端同步失败：${it.message ?: "请检查权限"}")
            }
        }
    }

    private fun syncSetDefaultLabelTemplate(template: LabelTemplate) {
        if (!canManageCloudTemplates()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { handheld.setDefaultLabelTemplate(template.id) }
                .onSuccess { refreshLabelTemplates(silent = true) }
                .onFailure {
                    mutableState.value = mutableState.value.copy(status = "本机默认已更新，云端默认设置失败：${it.message ?: "请检查权限"}")
                }
        }
    }

    private fun canManageCloudTemplates(): Boolean =
        mutableState.value.labelTemplatesCanManage ?: canManageTemplatesByRole(mutableState.value.roles)

    fun refreshPrinterStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val snapshot = printer.snapshot()
            mutableState.value = mutableState.value.copy(
                printerSnapshot = snapshot,
                bluetoothPrinterDevices = printer.bluetoothDevices(),
                bluetoothPrinterScanning = printer.isBluetoothScanning(),
                status = if (snapshot.connected) "打印机状态：${snapshot.stateText} · ${snapshot.modeText}" else snapshot.stateText,
            )
        }
    }

    fun useBuiltInPrinter() {
        val message = runCatching {
            printer.selectSunmi()
            "已切换到商米内置打印机"
        }.getOrElse { "切换失败：${it.message}" }
        mutableState.value = mutableState.value.copy(status = message)
        refreshPrinterStatus()
    }

    fun hasBuiltInPrinter(): Boolean = printer.hasSunmiPrinter()

    fun scanBluetoothPrinters() {
        mutableState.value = mutableState.value.copy(
            status = "正在搜索附近的便携式打印机…",
            bluetoothPrinterScanning = true,
        )
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                printer.scanBluetooth()
                "正在搜索附近的便携式打印机"
            }.getOrElse { "搜索失败：${it.message}" }
            mutableState.value = mutableState.value.copy(
                status = message,
                bluetoothPrinterDevices = printer.bluetoothDevices(),
                bluetoothPrinterScanning = printer.isBluetoothScanning(),
            )
            refreshPrinterStatus()
        }
    }

    fun connectBluetoothPrinter(device: BluetoothPrinterDevice) {
        mutableState.value = mutableState.value.copy(status = "正在连接 ${device.name}…", busy = true)
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                val connected = printer.connectBluetooth(device.address)
                "已连接蓝牙打印机：${connected.name}"
            }.getOrElse { "蓝牙连接失败：${it.message}" }
            mutableState.value = mutableState.value.copy(status = message, busy = false)
            refreshPrinterStatus()
        }
    }

    fun disconnectBluetoothPrinter() {
        printer.disconnectBluetooth()
        mutableState.value = mutableState.value.copy(status = "已断开蓝牙打印机")
        refreshPrinterStatus()
    }

    fun setBluetoothPrinterPaperWidth(widthMm: Int) {
        printer.setBluetoothPaperWidth(widthMm)
        mutableState.value = mutableState.value.copy(status = "外接打印机纸宽已设为 ${printer.bluetoothPaperWidth()}mm")
        refreshPrinterStatus()
    }

    fun setBluetoothPrinterMode(labelMode: Boolean) {
        printer.setBluetoothLabelMode(labelMode)
        if (!labelMode) {
            printer.setBluetoothPaperWidth(58)
        }
        mutableState.value = mutableState.value.copy(status = if (labelMode) "外接打印机已切换为标签模式" else "外接打印机已切换为小票模式")
        refreshPrinterStatus()
    }

    fun updatePrintOffset(deltaX: Int = 0, deltaY: Int = 0) {
        val current = mutableState.value
        val nextX = (current.printOffsetXDots + deltaX).coerceIn(-96, 96)
        val nextY = (current.printOffsetYDots + deltaY).coerceIn(-120, 80)
        printerPreferences.edit()
            .putInt(PRINT_OFFSET_X, nextX)
            .putInt(PRINT_OFFSET_Y, nextY)
            .apply()
        mutableState.value = current.copy(
            printOffsetXDots = nextX,
            printOffsetYDots = nextY,
            status = "标签内微调已更新：X $nextX dots / Y $nextY dots",
        )
    }

    fun resetPrintOffset() {
        printerPreferences.edit()
            .putInt(PRINT_OFFSET_X, 0)
            .putInt(PRINT_OFFSET_Y, DEFAULT_PRINT_OFFSET_Y_DOTS)
            .apply()
        mutableState.value = mutableState.value.copy(
            printOffsetXDots = 0,
            printOffsetYDots = DEFAULT_PRINT_OFFSET_Y_DOTS,
            status = "已恢复默认微调：X 0 / Y ${DEFAULT_PRINT_OFFSET_Y_DOTS} dots",
        )
    }

    fun initializePrinter() {
        mutableState.value = mutableState.value.copy(status = "正在初始化打印机…", busy = true)
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                printer.initialize()
                printer.snapshot()
            }.fold(
                onSuccess = { snapshot ->
                    mutableState.value = mutableState.value.copy(printerSnapshot = snapshot)
                    "打印机已初始化：${snapshot.stateText}"
                },
                onFailure = { "初始化失败：${it.message}" },
            )
            recordPrint(message)
            mutableState.value = mutableState.value.copy(status = message, busy = false)
        }
    }

    fun runPrinterSelfCheck() {
        mutableState.value = mutableState.value.copy(status = "正在执行打印机自检…", busy = true)
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                printer.selfCheck()
                "已发送自检指令"
            }.getOrElse { "自检失败：${it.message}" }
            recordPrint(message)
            mutableState.value = mutableState.value.copy(status = message, busy = false)
            refreshPrinterStatus()
        }
    }

    fun outputLabelToTearLine() {
        mutableState.value = mutableState.value.copy(status = "正在出纸到撕纸位…", busy = true)
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                printer.outputLabel()
                "已走到下一张标签间隙"
            }.getOrElse { "走纸失败：${it.message}" }
            recordPrint(message)
            mutableState.value = mutableState.value.copy(status = message, busy = false)
            refreshPrinterStatus()
        }
    }

    fun printTestLabel(template: LabelTemplate = labelTemplate()) {
        val current = mutableState.value
        mutableState.value = mutableState.value.copy(status = "正在打印定位样张…", busy = true)
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                "定位样张：${printer.printTestLabel(template, current.printOffsetXDots, current.printOffsetYDots)}"
            }.getOrElse { "定位样张失败：${it.message}" }
            recordPrint(message)
            mutableState.value = mutableState.value.copy(status = message, busy = false)
            refreshPrinterStatus()
        }
    }

    fun printReceiptTestLabel(
        template: LabelTemplate = labelTemplate(PrintTemplateType.RECEIPT),
    ) {
        val current = mutableState.value
        mutableState.value = mutableState.value.copy(status = "正在打印测试小票…", busy = true)
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                "测试小票：${printer.printReceiptTest(template, current.printOffsetXDots, current.printOffsetYDots)}"
            }.getOrElse { "测试小票失败：${it.message}" }
            recordPrint(message)
            mutableState.value = mutableState.value.copy(status = message, busy = false)
            refreshPrinterStatus()
        }
    }

    fun saveAndPrint(copies: Int = 1, template: LabelTemplate = labelTemplate()) {
        val item = saveCurrent() ?: return
        listingDraftStore.clear()
        val current = mutableState.value
        mutableState.value = mutableState.value.copy(
            items = emptyList(),
            productCounts = ProductCounts(),
            status = "正在打印标签…",
            busy = true,
        )
        viewModelScope.launch(Dispatchers.IO) {
            val printMessage = runCatching {
                val results = mutableListOf<String>()
                repeat(copies.coerceIn(1, 10)) {
                    results.add(printer.printLabel(item, template, current.printOffsetXDots, current.printOffsetYDots))
                }
                results.distinct().joinToString(" / ")
            }
                .fold(
                    onSuccess = { "已发送打印：$it" },
                    onFailure = { "打印失败：${it.message}" },
                )
            recordPrint("${item.itemNo} $printMessage")
            mutableState.value = mutableState.value.copy(status = "$printMessage；正在同步 ERP…")
            val syncMessage = runCatching {
                val result = handheld.smartCreate(item, autoPushYouzan = true)
                val imageCount = runCatching { handheld.itemImageCount(result.skuId) }.getOrDefault(0)
                "ERP已建档：${result.skuCode}；图片${imageCount}张"
            }.getOrElse {
                "ERP建档失败：${it.message ?: "请检查账号/token配置"}"
            }
            mutableState.value = mutableState.value.copy(
                items = emptyList(),
                productCounts = ProductCounts(),
                status = "$printMessage；$syncMessage",
                busy = false,
                screen = AppScreen.Products,
                secondTab = mutableState.value.secondTab.select(SecondTabMode.Products, SystemClock.uptimeMillis()),
            )
        }
    }

    fun printItem(item: Item, copies: Int = 1, template: LabelTemplate = labelTemplate()) {
        val current = mutableState.value
        mutableState.value = mutableState.value.copy(status = "正在发送打印：${item.itemNo}", busy = true)
        viewModelScope.launch(Dispatchers.IO) {
            val message = runCatching {
                val results = mutableListOf<String>()
                repeat(copies.coerceIn(1, 10)) {
                    results.add(printer.printLabel(item, template, current.printOffsetXDots, current.printOffsetYDots))
                }
                results.distinct().joinToString(" / ")
            }
                .fold(
                    onSuccess = { "已发送打印：${item.itemNo}（$it）" },
                    onFailure = { "打印失败：${it.message}" },
                )
            recordPrint(message)
            mutableState.value = mutableState.value.copy(
                status = message,
                busy = false,
            )
        }
    }

    private fun recordPrint(message: String) {
        printHistoryStore.add(message)
        mutableState.value = mutableState.value.copy(printHistory = printHistoryStore.all())
    }

    override fun onCleared() {
        printer.close()
        super.onCleared()
    }

    private fun saveCurrent(): Item? {
        val current = mutableState.value
        val name = current.name.trim()
        val price = current.price.trim()
        val category = current.category.trim()
        if (name.isBlank()) {
            mutableState.value = current.copy(status = "请填写商品名称")
            return null
        }
        if ((price.toDoubleOrNull() ?: 0.0) <= 0.0) {
            mutableState.value = current.copy(status = "请填写有效售价")
            return null
        }
        if (category.isBlank() || current.categoryCode.isBlank()) {
            mutableState.value = current.copy(status = "请选择 ERP 商品分类")
            return null
        }
        if (current.listingCategoryOptions.isNotEmpty() &&
            current.listingCategoryOptions.none { it.code == current.categoryCode }
        ) {
            mutableState.value = current.copy(status = "该商品分类已停用，请重新选择 ERP 商品分类")
            return null
        }
        if (current.ipName.isNotBlank() && !current.ipConfirmed) {
            mutableState.value = current.copy(status = "请确认识别到的 IP，或修改后确认新建")
            return null
        }
        val item = Item(
            itemNo = current.itemNo.ifBlank { ItemNumber.createForDevice(getApplication()) },
            name = name,
            priceCents = ((price.toDoubleOrNull() ?: 0.0) * 100).toInt(),
            category = category.ifBlank { "未分类" },
            categoryCode = current.categoryCode,
            facetCodes = current.selectedFacetCodes,
            tags = current.listingFacetOptions
                .filter { it.code in current.selectedFacetCodes }
                .map { it.name },
            recognitionRequestId = current.recognitionRequestId,
            categoryConfidence = current.confidence.takeIf { current.recognitionRequestId.isNotBlank() },
            classificationStatus = current.classificationStatus,
            aiSuggestedPriceCny = current.aiSuggestedPriceCny,
            imagePath = current.photo?.absolutePath.orEmpty(),
            listingStoragePath = current.listingStoragePath,
            listingStoragePaths = current.listingStoragePaths,
            listingImageUrl = current.listingImageUrl,
            originalImagePath = current.originalPhoto?.absolutePath.orEmpty(),
            originalImagePaths = current.originalPhotoBatch,
            brand = current.brand,
            ipName = current.ipName,
            ipConfirmed = current.ipConfirmed,
            material = current.material,
            color = current.color,
            conditionGrade = current.conditionGrade.ifBlank { "A" },
            conditionNote = current.conditionNote,
            productType = "custom",
            fankuangOverride = current.fankuangOverride,
            stockQty = 1,
            sourceLabel = "本机",
        )
        store.save(item)
        return item
    }

    private fun ErpSkuItem.toItem(): Item =
        Item(
            itemNo = skuCode.ifBlank { id },
            name = name,
            priceCents = priceCents,
            category = category.ifBlank { "未分类" },
            imagePath = imageUrl,
            listingImageUrl = imageUrl,
            brand = brand,
            era = era,
            ipName = ipName,
            material = material,
            color = "",
            conditionGrade = conditionGrade.ifBlank { "A" },
            conditionNote = notes,
            createdAt = System.currentTimeMillis(),
            productType = productType,
            stockQty = stockQty,
            isDisplay = isDisplay,
            listingStatus = listingStatus,
            statusLabel = statusLabel,
            canRestock = canRestock,
            sourceLabel = "ERP",
            editable = editable,
            isUnlimitedStock = isUnlimitedStock,
            imageProcessingStatus = imageProcessingStatus,
            productStocks = productStocks,
            erpId = id,
            fankuangOverride = fankuangOverride,
            fankuangMembership = fankuangMembership,
            canEdit = canEdit,
            updatedAt = updatedAt,
        )

    private fun refreshProductsAfterMutation() {
        productCache.clear()
        loadProductsFromErp()
    }

    private fun reloadSelectedProductDetail() {
        val current = mutableState.value
        if (current.screen == AppScreen.ProductDetail && current.productDetailId.isNotBlank()) loadProductDetail()
    }

    companion object {
        private const val PRINT_OFFSET_X = "print_offset_x_v2"
        private const val PRINT_OFFSET_Y = "print_offset_y_v2"
    }
}

private fun canManageTemplatesByRole(roles: Set<String>): Boolean =
    roles.any { it == "super_admin" || it == "hq_operator" }
