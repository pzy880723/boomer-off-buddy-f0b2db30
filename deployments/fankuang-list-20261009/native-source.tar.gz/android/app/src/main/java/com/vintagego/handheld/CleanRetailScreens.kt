package com.vintagego.handheld

import android.Manifest
import android.animation.ValueAnimator
import android.os.SystemClock
import android.view.accessibility.AccessibilityManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val BoRed = Color(0xFFEE1B2A)
private val BoRedSoft = Color(0xFFFFF1F2)
private val BoNavy = Color(0xFF062F5F)
private val BoNavySoft = Color(0xFFEAF3FF)
private val BoInk = Color(0xFF111827)
private val BoSub = Color(0xFF6B7280)
private val BoMuted = Color(0xFF9CA3AF)
private val BoBg = Color.White
private val BoCard = Color.White
private val BoSoft = Color(0xFFF5F7FA)
private val BoLine = Color(0xFFE7E9EE)
private val BoOrange = Color(0xFFD97706)
private val BoYellow = Color(0xFFFFC83D)
private val BoBlue = Color(0xFF0A3D78)
private val BoGreen = Color(0xFF16A34A)
private val BoPage = Color(0xFFF5F7FA)
private val BoAmberSoft = Color(0xFFFFF7E8)
private val BoGreenSoft = Color(0xFFEAF8F1)
private val BoPanelShadow = Color(0x14111827)
private val BoFont = FontFamily.SansSerif

@Composable
private fun BoLogo(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.boomer_off_vintage_logo_red),
        contentDescription = "BOOMER-OFF Vintage",
        modifier = modifier.width(154.dp).height(52.dp),
        contentScale = ContentScale.Fit,
    )
}

@Composable
private fun BoTopBar(
    onBack: (() -> Unit)? = null,
    rightText: String? = null,
    rightIcon: ImageVector? = null,
    onRight: () -> Unit = {},
) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 6.dp, start = 4.dp, end = 4.dp, bottom = 2.dp)
            .height(48.dp),
    ) {
        if (onBack != null) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(40.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .border(1.dp, BoLine.copy(.72f), RoundedCornerShape(14.dp)),
            ) {
                Icon(Icons.Default.ArrowBack, null, tint = BoInk, modifier = Modifier.size(20.dp))
            }
        }
        when {
            rightText != null -> Text(
                rightText,
                color = BoNavy,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = BoFont,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color.White)
                    .border(1.dp, BoLine.copy(.72f), RoundedCornerShape(999.dp))
                    .clickable(onClick = onRight)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )

            rightIcon != null -> IconButton(
                onClick = onRight,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(40.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .border(1.dp, BoLine.copy(.72f), RoundedCornerShape(14.dp)),
            ) {
                Icon(rightIcon, null, tint = BoInk, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
fun CleanLoginScreen(vm: MainViewModel, state: UiState) {
    var phone by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var loginTab by remember { mutableIntStateOf(0) }

    Scaffold(containerColor = BoBg) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color.White),
        ) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 28.dp, end = 18.dp)
                    .size(86.dp)
                    .clip(CircleShape)
                    .background(BoRed.copy(.06f)),
            )
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
            ) {
                Spacer(Modifier.height(32.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(BoRed),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("BO", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("BOOMER-OFF", color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Text("Vintage handheld", color = BoSub, fontSize = 11.sp)
                    }
                }

                Spacer(Modifier.height(34.dp))
                Text("登录门店终端", color = BoInk, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(8.dp))
                Text(
                    "用手机号验证码进入当前设备。登录后选择门店或仓库，后续拍照上架、RFID 入库都会按该位置记录。",
                    color = BoSub,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                )

                Spacer(Modifier.height(22.dp))
                BoRaisedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(BoGreen))
                            Spacer(Modifier.width(8.dp))
                            Text("ERP 登录", color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            LoginTab("验证码登录", loginTab == 0, Modifier.weight(1f)) { loginTab = 0 }
                            LoginTab("密码登录", loginTab == 1, Modifier.weight(1f)) { loginTab = 1 }
                        }
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it.filter(Char::isDigit).take(11) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("手机号") },
                            placeholder = { Text("请输入 11 位手机号") },
                        )
                        if (loginTab == 0) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = code,
                                    onValueChange = { code = it.filter(Char::isDigit).take(6) },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    label = { Text("6 位验证码") },
                                )
                                Button(
                                    onClick = { vm.sendOtp(phone) },
                                    enabled = !state.busy && state.otpCooldownSeconds == 0,
                                    modifier = Modifier.width(120.dp).height(56.dp),
                                    shape = RoundedCornerShape(15.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = BoRed),
                                    border = BorderStroke(1.dp, BoRed.copy(.35f)),
                                ) {
                                    Text(
                                        if (state.otpCooldownSeconds > 0) "${state.otpCooldownSeconds}s" else "获取验证码",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("密码") },
                                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { showPassword = !showPassword }) {
                                        Icon(
                                            if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = if (showPassword) "隐藏密码" else "显示密码",
                                            tint = BoSub,
                                        )
                                    }
                                },
                            )
                        }
                        Button(
                            onClick = { if (loginTab == 0) vm.verifyOtp(phone, code) else vm.login(phone, password) },
                            enabled = !state.busy,
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BoRed, contentColor = Color.White),
                        ) {
                            Text(
                                when {
                                    state.busy -> "正在连接 ERP…"
                                    loginTab == 0 -> "验证并激活设备"
                                    else -> "密码登录并激活"
                                },
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Text(
                            if (loginTab == 0) "验证码 5 分钟内有效。频繁发送会触发限流。" else "密码登录仅作兜底；日常建议使用短信验证码。",
                            color = BoMuted,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                        )
                        if (state.status.isNotBlank()) {
                            LoginStatusBanner(state.status)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                BoRaisedCard {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("设备安装码", color = BoSub, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(state.installId, color = BoInk, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }

                Spacer(Modifier.height(18.dp))
                Text(
                    "没有单独 APP 账号。手机号必须先在 PC 端 ERP 建好员工账号。",
                    color = BoMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun LoginStatusBanner(text: String) {
    val isError = text.contains("失败") ||
        text.contains("请输入") ||
        text.contains("未命中") ||
        text.contains("过期") ||
        text.contains("不正确") ||
        text.contains("频繁")
    val bg = if (isError) BoRedSoft else Color(0xFFEAF8F1)
    val fg = if (isError) BoRed else BoGreen
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(bg)
            .padding(horizontal = 11.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Default.CheckCircle, null, tint = fg, modifier = Modifier.size(17.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 17.sp)
    }
}

@Composable
private fun LoginTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) BoInk else Color(0xFFF5F5F5))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (selected) Color.White else BoSub, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LocationSelectScreen(vm: MainViewModel, state: UiState) {
    Scaffold(containerColor = BoBg) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Spacer(Modifier.height(18.dp))
            Text("选择当前门店/仓库", color = BoInk, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text("后续拍照上架、RFID 入库、调拨和盘点都按这个位置执行。", color = BoSub, fontSize = 13.sp, lineHeight = 19.sp)
            Spacer(Modifier.height(14.dp))
            if (state.status.isNotBlank()) StatusBanner(state.status)
            Spacer(Modifier.height(12.dp))
            if (state.locations.isEmpty()) {
                BoRaisedCard {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (state.busy) "正在加载门店/仓库…" else "当前账号未授权任何库位，请联系管理员",
                            color = BoInk,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp,
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = vm::loadLocations,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BoRed, contentColor = Color.White),
                        ) { Text("重新获取") }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    state.locations.forEach { location ->
                        BoRaisedCard(Modifier.clickable(enabled = !state.busy) { vm.switchLocation(location) }) {
                            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(BoRedSoft), contentAlignment = Alignment.Center) {
                                    Icon(if (location.kind == "warehouse") Icons.Default.Inventory2 else Icons.Default.Storefront, null, tint = BoRed)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(location.name, color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text(if (location.kind == "warehouse") "仓库" else "门店", color = BoSub, fontSize = 12.sp)
                                }
                                Icon(Icons.Default.ChevronRight, null, tint = BoMuted)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = vm::logout,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = BoRed),
                border = BorderStroke(1.dp, BoLine),
            ) { Text("退出登录", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun CleanDashboard(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    LaunchedEffect(state.homeMessagesGeneration, state.selectedLocation?.id, state.locationSwitching) {
        state.selectedLocation?.id?.let(vm::loadDashboard)
    }
    val location = state.selectedLocation
    val canSwitchLocation = state.locations.size > 1
    val tasks = state.dashboard.tasks
    val recentItems = state.dashboard.recentItems
    val activeRoles = effectiveRoles(state.roles, state.locations, state.selectedLocation)
    val canViewGlobalStock = activeRoles.any { it == "super_admin" || it == "hq_operator" }
    val tools = dashboardToolsForRoles(activeRoles)
    Scaffold(containerColor = BoBg, bottomBar = { CleanBottomNav(vm, AppScreen.Dashboard) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 28.dp),
        ) {
            DesignDashboardHeader(
                locationName = location?.name ?: "未选择库位",
                role = roleLabel(activeRoles),
                canSwitchLocation = canSwitchLocation,
                unread = state.dashboard.unreadNotifications,
                onSwitch = { vm.navigate(AppScreen.LocationSelect) },
                onNotifications = { vm.navigate(AppScreen.Notifications) },
            )
            DesignDashboardHero(
                canSwitchLocation = canSwitchLocation,
                role = roleLabel(activeRoles),
                stockCount = state.dashboard.stats.stockCount.toString(),
                accuracy = state.dashboard.stats.inventoryAccuracy?.let { "%.1f".format(it) } ?: "--",
                transitCount = state.dashboard.stats.inTransitCount.toString(),
            )

            if (canViewGlobalStock) {
                DesignSectionHeader("总部工具", "仅总部账号显示")
                DesignGlobalStockEntry { vm.openGlobalStock() }
                if ("super_admin" in activeRoles) {
                    BoRaisedCard(Modifier.padding(bottom = 12.dp).clickable { vm.navigate(AppScreen.Parcels) }) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Inventory2, null, tint = BoRed)
                            Text("日本小包", modifier = Modifier.weight(1f).padding(start = 12.dp), color = BoInk, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ChevronRight, null, tint = BoMuted)
                        }
                    }
                }
            }

            DesignSectionHeader("今日待办", "查看全部") { vm.loadDashboard() }
            when {
                state.dashboardLoading -> DesignEmptyPanel("正在加载工作台", "正在从 ERP 获取真实待办和库存数据")
                tasks.isEmpty() -> DesignEmptyPanel("暂无待办", "当前库位没有需要处理的任务")
                else -> tasks.take(3).forEach { task ->
                    DesignTaskRow(task) {
                        when (task.action) {
                            "transfer_detail" -> vm.navigate(AppScreen.Transfer)
                            "stocktake_detail" -> vm.navigate(AppScreen.Inventory)
                            else -> vm.navigate(AppScreen.Notifications)
                        }
                    }
                }
            }

            DesignSectionHeader("常用操作", "")
            if (tools.isEmpty()) {
                DesignEmptyPanel("暂无可用功能", "当前账号没有手持端功能权限，请联系管理员")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    tools.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEach { tool ->
                                DesignQuickAction(tool.icon, tool.label, tool.subtitle, Modifier.weight(1f)) {
                                    if (tool.screen == AppScreen.Camera) vm.newListing() else vm.navigate(tool.screen)
                                }
                            }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            if (recentItems.isNotEmpty()) {
                DesignSectionHeader("最近上架", "全部") { vm.navigate(AppScreen.Products) }
                val recent = recentItems.first()
                DesignRecentItem(
                    imagePath = recent.imageUrl,
                    name = recent.name,
                    code = recent.skuCode.ifBlank { recent.barcode },
                    price = "¥%.0f".format(recent.price),
                    grade = recent.conditionGrade.ifBlank { "-" },
                ) { vm.navigate(AppScreen.Products) }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

internal data class DashboardTool(
    val icon: ImageVector,
    val label: String,
    val screen: AppScreen,
    val subtitle: String = "",
)

private fun effectiveRoles(
    roles: Set<String>,
    locations: List<HandheldLocation>,
    selectedLocation: HandheldLocation?,
): Set<String> = when {
    roles.isNotEmpty() -> roles
    locations.size > 1 -> setOf("super_admin")
    selectedLocation?.kind == "warehouse" -> setOf("warehouse_staff")
    selectedLocation != null -> setOf("store_staff")
    else -> emptySet()
}

internal fun dashboardToolsForRoles(roles: Set<String>): List<DashboardTool> {
    val elevated = roles.any { it == "super_admin" || it == "hq_operator" }
    val manager = "store_manager" in roles
    val staff = "store_staff" in roles
    val warehouse = "warehouse_staff" in roles
    return buildList {
        if (elevated || manager || staff) add(DashboardTool(Icons.Default.PointOfSale, "门店收银", AppScreen.Pos, "扫码选品、会员优惠与收款"))
        if (elevated || manager || staff) add(DashboardTool(Icons.Default.AutoAwesome, "拍照上架", AppScreen.Camera))
        if (elevated || manager || staff || warehouse) add(DashboardTool(Icons.Default.ReceiptLong, "订单", AppScreen.Orders))
        if (elevated || manager || staff || warehouse) add(DashboardTool(Icons.Default.Storefront, "快速入库", AppScreen.QuickStock))
        if (elevated || manager || staff || warehouse) add(DashboardTool(Icons.Default.Search, "商品中心", AppScreen.Products))
        if (elevated || manager || warehouse) add(DashboardTool(Icons.Default.Sync, "调拨管理", AppScreen.Transfer))
        if (elevated || manager) add(DashboardTool(Icons.Default.Assignment, "库存盘点", AppScreen.Inventory))
        if (elevated || manager || staff || warehouse) add(DashboardTool(Icons.Default.QrCodeScanner, "RFID关联", AppScreen.RfidBind))
        if (elevated || manager || staff) add(DashboardTool(Icons.Default.Print, "打印中心", AppScreen.PrinterSettings))
        if (elevated || manager) add(DashboardTool(Icons.Default.Bolt, "同步中心", AppScreen.Sync))
        if (elevated || manager || staff || warehouse) add(DashboardTool(Icons.Default.Notifications, "消息中心", AppScreen.Notifications))
    }
}

private fun canManageLabelTemplates(roles: Set<String>): Boolean =
    roles.any { it == "super_admin" || it == "hq_operator" }

private fun roleLabel(roles: Set<String>): String = when {
    "super_admin" in roles -> "超级管理员"
    "hq_operator" in roles -> "总部运营"
    "store_manager" in roles -> "店长"
    "store_staff" in roles -> "店员"
    "warehouse_staff" in roles -> "仓库员工"
    else -> "员工"
}

@Composable
private fun DesignTopTitle(
    title: String,
    back: (() -> Unit)? = null,
    action: String? = null,
    onAction: () -> Unit = {},
) {
    Box(Modifier.fillMaxWidth().height(74.dp)) {
        if (back != null) {
            Box(
                Modifier
                    .align(Alignment.CenterStart)
                    .size(38.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(1.dp, BoLine, RoundedCornerShape(16.dp))
                    .clickable(onClick = back),
                contentAlignment = Alignment.Center,
            ) {
                Text("‹", color = BoInk, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            }
        }
        Text(
            title,
            color = BoInk,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = BoFont,
            modifier = Modifier.align(if (back == null) Alignment.CenterStart else Alignment.Center),
        )
        if (action != null) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(1.dp, BoLine, RoundedCornerShape(16.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(action, color = BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
            }
        }
    }
}

@Composable
private fun DesignDashboardHeader(
    locationName: String,
    role: String,
    canSwitchLocation: Boolean,
    unread: Int,
    onSwitch: () -> Unit,
    onNotifications: () -> Unit,
) {
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Row(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .clickable(enabled = canSwitchLocation, onClick = onSwitch)
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(locationName, color = BoInk, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
            if (canSwitchLocation) {
                Spacer(Modifier.width(4.dp))
                Text("›", color = BoInk, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
        }
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .border(1.dp, BoLine, RoundedCornerShape(16.dp))
                .clickable(onClick = onNotifications),
            contentAlignment = Alignment.Center,
        ) {
            Text("铃", color = BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
            if (unread > 0) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 4.dp, y = (-5).dp)
                        .size(17.dp)
                        .clip(CircleShape)
                        .background(BoRed),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(unread.coerceAtMost(9).toString(), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
    Text(role, color = BoSub, fontSize = 12.sp)
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun DesignDashboardHero(
    canSwitchLocation: Boolean,
    role: String,
    stockCount: String,
    accuracy: String,
    transitCount: String,
) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .shadow(8.dp, RoundedCornerShape(22.dp), ambientColor = BoNavy.copy(.08f), spotColor = BoNavy.copy(.10f))
            .clip(RoundedCornerShape(22.dp))
            .background(BoNavy),
    ) {
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset(x = 24.dp, y = (-28).dp)
                .size(118.dp)
                .clip(CircleShape)
                .background(Color.White.copy(.10f)),
        )
        Column(Modifier.fillMaxSize().padding(24.dp, 20.dp, 18.dp, 16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(if (canSwitchLocation) "总部视角" else "库位视角", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
                    Spacer(Modifier.height(7.dp))
                    Text(
                        if (canSwitchLocation) "可查看全部门店与仓库库存" else "当前库位实时库存与任务",
                        color = Color.White.copy(.78f),
                        fontSize = 12.sp,
                    )
                }
                Box(
                    Modifier
                        .clip(CircleShape)
                        .border(1.dp, Color.White.copy(.28f), CircleShape)
                        .padding(horizontal = 11.dp, vertical = 7.dp),
                ) {
                    Text(role, color = Color.White.copy(.9f), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DesignHeroStat(stockCount, "在库商品", Modifier.weight(1f))
                DesignHeroStat(accuracy, "库存准确率", Modifier.weight(1f))
                DesignHeroStat(transitCount, "在途库存", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun DesignHeroStat(value: String, label: String, modifier: Modifier) {
    Column(
        modifier
            .height(60.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(.12f))
            .padding(start = 8.dp, top = 8.dp),
    ) {
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont, maxLines = 1)
        Text(label, color = Color.White.copy(.72f), fontSize = 10.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun DesignSectionHeader(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont, modifier = Modifier.weight(1f))
        if (action != null) {
            Row(
                Modifier.clickable(enabled = onAction != null) { onAction?.invoke() },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(action, color = BoSub, fontSize = 12.sp)
                Text(" ›", color = BoSub, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun DesignGlobalStockEntry(onClick: () -> Unit) {
    DesignCard(Modifier.height(78.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(BoNavySoft), contentAlignment = Alignment.Center) {
                Text("▦", color = BoNavy, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("全局库存", color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(4.dp))
                Text("按 SKU 查看总部、门店、仓库的库存分布", color = BoSub, fontSize = 12.sp, lineHeight = 16.sp)
            }
            Text("›", color = BoRed, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun DesignTaskRow(task: DashboardTaskItem, onClick: () -> Unit) {
    val color = taskColor(task)
    val iconText = if (task.type == "stocktake") "盘" else "↔"
    DesignCard(Modifier.height(62.dp).padding(bottom = 0.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(42.dp).clip(RoundedCornerShape(4.dp)).background(color))
            Spacer(Modifier.width(14.dp))
            Box(Modifier.size(36.dp).clip(CircleShape).background(color.copy(.11f)), contentAlignment = Alignment.Center) {
                Text(iconText, color = color, fontSize = 14.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(task.title, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text(task.description, color = BoSub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("›", color = BoRed, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun DesignQuickAction(icon: ImageVector, label: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(72.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp, pressedElevation = 1.dp),
    ) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, tint = BoRed, modifier = Modifier.size(18.dp))
            Spacer(Modifier.height(2.dp))
            Text(label, color = BoInk, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont, maxLines = 1)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = BoSub, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun DesignRecentItem(imagePath: String, name: String, code: String, price: String, grade: String, onClick: () -> Unit) {
    DesignCard(Modifier.height(82.dp).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxSize().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            DesignProductThumb(imagePath, 60)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1)
                Text("SKU: $code", color = BoSub, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.height(5.dp))
                MiniBadge("成色 $grade", BoSub)
            }
            Text(price, color = BoRed, fontSize = 20.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun DesignSearchBox(value: String, placeholder: String, onValueChange: (String) -> Unit) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = androidx.compose.ui.text.TextStyle(color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Medium),
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(BoSoft)
            .border(1.dp, BoLine.copy(.55f), RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp),
        decorationBox = { inner ->
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Text("⌕", color = BoMuted, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (value.isBlank()) Text(placeholder, color = BoMuted, fontSize = 13.sp)
                    inner()
                }
            }
        },
    )
}

@Composable
private fun DesignProductTypeTab(label: String, count: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(60.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color.White else BoSoft)
            .border(1.dp, if (selected) BoRed.copy(.38f) else Color.Transparent, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
    ) {
        Text(
            label,
            color = BoInk,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = BoFont,
            maxLines = 1,
            modifier = Modifier.align(Alignment.TopStart).padding(top = 12.dp),
        )
        Text(
            "$count 件",
            color = if (selected) BoRed else BoSub,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            lineHeight = 12.sp,
            maxLines = 1,
            modifier = Modifier.align(Alignment.BottomStart).padding(bottom = 10.dp),
        )
    }
}

@Composable
private fun CompactProductTypeTab(label: String, count: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(34.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(if (selected) BoNavy else BoSoft)
            .border(1.dp, if (selected) BoNavy else BoLine, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "$label $count",
            color = if (selected) Color.White else BoInk,
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
        )
    }
}

@Composable
private fun ProductStatusTabs(selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(BoSoft)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        productStatusOptions.forEach { (status, label) ->
            val active = selected == status
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(13.dp))
                    .background(if (active) Color.White else Color.Transparent)
                    .border(1.dp, if (active) BoLine else Color.Transparent, RoundedCornerShape(13.dp))
                    .clickable { onSelect(status) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (active) listingStatusColor(status) else BoSub,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun DesignFilterPill(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .height(34.dp)
            .clip(CircleShape)
            .background(Color.White)
            .border(1.dp, BoLine, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun DesignOptionDialog(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        ) {
            Column(Modifier.padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = BoInk, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont, modifier = Modifier.weight(1f))
                    Text("关闭", color = BoSub, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onDismiss).padding(8.dp))
                }
                Spacer(Modifier.height(10.dp))
                options.forEach { (value, label) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (value == selected) BoRedSoft else Color.Transparent)
                            .clickable { onSelect(value) }
                            .padding(horizontal = 14.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(label, color = if (value == selected) BoRed else BoInk, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (value == selected) Text("✓", color = BoRed, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun DesignMultiOptionDialog(
    title: String,
    options: List<ProductFacetOption>,
    selected: Set<String>,
    onDismiss: () -> Unit,
    onToggle: (String) -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        ) {
            Column(Modifier.padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title, color = BoInk, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
                        Text("已选择 ${selected.size} 个", color = BoSub, fontSize = 11.sp)
                    }
                    Text("完成", color = BoRed, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onDismiss).padding(8.dp))
                }
                Spacer(Modifier.height(10.dp))
                if (options.isEmpty()) {
                    Text("当前分类暂无可选标签", color = BoSub, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), textAlign = TextAlign.Center)
                } else {
                    LazyColumn(Modifier.heightIn(max = 460.dp)) {
                        items(options, key = { it.code }) { option ->
                            val active = option.code in selected
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (active) BoRedSoft else Color.Transparent)
                                    .clickable { onToggle(option.code) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(option.name, color = if (active) BoRed else BoInk, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text(facetDimensionLabel(option.dimension), color = BoSub, fontSize = 10.sp)
                                }
                                if (active) Text("✓", color = BoRed, fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun facetDimensionLabel(dimension: String): String = when (dimension) {
    "object_type" -> "物件类型"
    "function" -> "用途"
    "origin" -> "产地"
    "material" -> "材质"
    "era" -> "年代"
    "craft" -> "工艺"
    "style" -> "风格"
    "ip" -> "IP"
    "character" -> "角色"
    "series" -> "系列"
    "release_method" -> "发行方式"
    else -> "商品标签"
}

@Composable
private fun DesignProductRow(item: Item, locationBadges: List<String> = emptyList(), stockLabel: String = "总库存", onClick: () -> Unit) {
    DesignCard((if (locationBadges.isEmpty()) Modifier.height(92.dp) else Modifier.heightIn(min = 92.dp)).clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            DesignProductThumb(item.imagePath, 72)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(3.dp))
                Text(item.itemNo.ifBlank { "未生成编码" }, color = BoSub, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.height(2.dp))
                Text(item.itemNo.takeIf { it.isNotBlank() } ?: "条码待生成", color = BoSub, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    MiniBadge(productTypeLabel(item.productType).replace("商品", ""), BoRed)
                    MiniBadge(item.statusLabel.ifBlank { productStatusLabel(item.listingStatus) }, listingStatusColor(item.listingStatus))
                    if (listingImageProcessingLabel(item.imageProcessingStatus) != null) MiniBadge("主图修图中", BoNavy)
                    if (item.conditionGrade.isNotBlank()) MiniBadge("成色 ${item.conditionGrade}", BoSub)
                    if (item.isUnlimitedStock) MiniBadge("库存不限", BoNavy)
                    else if (item.stockQty > 0 || locationBadges.isNotEmpty()) MiniBadge("$stockLabel ${item.stockQty}", BoNavy)
                }
                if (locationBadges.isNotEmpty()) {
                    Spacer(Modifier.height(5.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        locationBadges.forEach { MiniBadge(it, BoNavy) }
                    }
                }
                if (item.inFankuang) {
                    Spacer(Modifier.height(4.dp))
                    MiniBadge("翻筐乐", BoRed)
                }
            }
            Text("¥%.0f".format(item.priceCents / 100.0), color = BoRed, fontSize = 20.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun DesignGlobalStockSummary(
    search: String,
    onSearch: (String) -> Unit,
    summary: GlobalStockSummary,
    matrix: Boolean,
    onMatrix: () -> Unit,
    onDetail: () -> Unit,
) {
    DesignCard(Modifier.height(232.dp)) {
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Text("全部库位库存分布", color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(14.dp))
            DesignSearchBox(search, "搜索 SKU / 商品 / 条码", onSearch)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DesignSummaryMetric("SKU 数", summary.skuCount.toString(), Modifier.weight(1f))
                DesignSummaryMetric("总库存", summary.totalQty.toString(), Modifier.weight(1f))
                DesignSummaryMetric("低库存", summary.lowStock.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(16.dp)).background(BoSoft).padding(3.dp)) {
                DesignSegmentButton("矩阵视图", matrix, Modifier.weight(1f), onMatrix)
                DesignSegmentButton("明细视图", !matrix, Modifier.weight(1f), onDetail)
            }
        }
    }
}

@Composable
private fun DesignSummaryMetric(label: String, value: String, modifier: Modifier) {
    Column(
        modifier
            .height(58.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(BoSoft)
            .padding(start = 10.dp, top = 8.dp),
    ) {
        Text(value, color = BoInk, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(label, color = BoSub, fontSize = 10.sp)
    }
}

@Composable
private fun DesignSegmentButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(13.dp))
            .background(if (selected) Color.White else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (selected) BoNavy else BoSub, fontSize = 12.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun DesignGlobalStockMatrix(data: GlobalStockData) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        data.items.forEach { item ->
            DesignCard(Modifier.height(132.dp)) {
                Column(Modifier.fillMaxSize().padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(item.name, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${item.skuCode.ifBlank { item.barcode }} · ¥%.0f · ${productTypeLabel(item.productType)}".format(item.priceCents / 100.0),
                                color = BoSub,
                                fontSize = 11.sp,
                                maxLines = 1,
                            )
                        }
                        Box(Modifier.clip(CircleShape).background(BoNavySoft).padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text(if (item.isUnlimitedStock) "库存不限" else "合计 ${item.totalQty}", color = BoNavy, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        data.locations.forEach { location ->
                            val qty = item.stocks[location.id] ?: 0
                            DesignLocationStockCell(qty, location.name, Modifier.width(102.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun DesignLocationStockCell(qty: Int, name: String, modifier: Modifier) {
    val color = stockQtyColor(qty)
    Column(
        modifier
            .height(52.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(.08f))
            .border(1.dp, color.copy(.16f), RoundedCornerShape(12.dp))
            .padding(start = 10.dp, top = 7.dp, end = 8.dp),
    ) {
        Text(qty.toString(), color = BoInk, fontSize = 17.sp, fontWeight = FontWeight.Bold, lineHeight = 18.sp)
        Spacer(Modifier.height(3.dp))
        Text(name, color = BoSub, fontSize = 9.sp, lineHeight = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DesignProductThumb(path: String, size: Int) {
    if (path.isBlank()) {
        Box(
            Modifier
                .size(size.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFFB89974)),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .width((size * .48f).dp)
                    .height((size * .30f).dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(BoInk),
            )
            Box(
                Modifier
                    .width((size * .38f).dp)
                    .height((size * .20f).dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White),
            )
        }
    } else {
        ProductImage(path, Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(BoSoft), ContentScale.Crop)
    }
}

@Composable
private fun DesignCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0x0A111827)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp, pressedElevation = 1.dp),
    ) {
        content()
    }
}

@Composable
private fun DesignEmptyPanel(title: String, desc: String) {
    DesignCard(Modifier.height(92.dp)) {
        Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(title, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Spacer(Modifier.height(5.dp))
            Text(desc, color = BoSub, fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 15.sp)
        }
    }
}

private fun taskIcon(task: DashboardTaskItem): ImageVector = when (task.type) {
    "transfer_in" -> Icons.Default.Inventory2
    "stocktake" -> Icons.Default.Assignment
    else -> Icons.Default.Notifications
}

private fun taskColor(task: DashboardTaskItem): Color = if (task.urgency == "urgent") BoRed else BoBlue

private fun taskActionLabel(task: DashboardTaskItem): String = when (task.action) {
    "transfer_detail" -> "处理调拨"
    "stocktake_detail" -> "开始盘点"
    else -> "查看"
}

@Composable
private fun DashboardHeroCard(
    locationName: String,
    role: String,
    userName: String,
    today: String,
    canSwitchLocation: Boolean,
    unread: Int,
    stockCount: String,
    accuracy: String,
    accuracyUnit: String,
    transitCount: String,
    onSwitch: () -> Unit,
    onNotifications: () -> Unit,
) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(enabled = canSwitchLocation, onClick = onSwitch)
                    .padding(vertical = 4.dp),
            ) {
                Text(locationName, color = BoInk, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.6).sp)
                if (canSwitchLocation) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.ChevronRight, null, tint = BoInk, modifier = Modifier.size(22.dp))
                }
            }
            Box(
                Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(Color.White)
                    .border(1.dp, BoLine, RoundedCornerShape(15.dp))
                    .clickable(onClick = onNotifications),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Default.Notifications, null, tint = BoInk, modifier = Modifier.size(23.dp))
                if (unread > 0) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 2.dp, y = (-2).dp)
                            .size(17.dp)
                            .clip(CircleShape)
                            .background(BoRed),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(unread.toString(), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(BoNavy),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        ) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(if (canSwitchLocation) "总部视角" else "库位视角", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(4.dp))
                        Text("$role · $userName", color = Color.White.copy(.72f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(today, color = Color.White.copy(.52f), fontSize = 11.sp)
                    }
                    Box(
                        Modifier
                            .clip(CircleShape)
                            .border(1.dp, Color.White.copy(.28f), CircleShape)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                    ) {
                        Text(role, color = Color.White.copy(.88f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(.12f))
                        .padding(horizontal = 6.dp, vertical = 13.dp),
                ) {
                    StoreStat("在库商品", stockCount, "件", Modifier.weight(1f), dark = true)
                    DividerLine(dark = true)
                    StoreStat("库存准确率", accuracy, accuracyUnit, Modifier.weight(1f), dark = true)
                    DividerLine(dark = true)
                    StoreStat("在途待收", transitCount, "单", Modifier.weight(1f), dark = true)
                }
            }
        }
    }
}

@Composable
private fun StoreStat(label: String, value: String, unit: String, modifier: Modifier, dark: Boolean = false) {
    val labelColor = if (dark) Color.White.copy(.70f) else BoSub
    val valueColor = if (dark) Color.White else BoInk
    val hintColor = if (dark) Color.White.copy(.55f) else BoMuted
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = labelColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = valueColor, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text(unit.lines().first(), color = valueColor, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp, start = 2.dp))
        }
        unit.lines().drop(1).firstOrNull()?.let { Text(it, color = hintColor, fontSize = 10.sp) }
    }
}

@Composable
private fun DividerLine(dark: Boolean = false) {
    Box(
        Modifier
            .height(46.dp)
            .width(1.dp)
            .background(if (dark) Color.White.copy(.18f) else BoLine),
    )
}

@Composable
private fun SectionTitle(title: String, badge: String?, action: String?, onAction: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 18.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
            if (badge != null) {
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(19.dp).clip(CircleShape).background(BoRedSoft), contentAlignment = Alignment.Center) {
                    Text(badge, color = BoRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (action != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = if (onAction != null) Modifier.clickable(onClick = onAction) else Modifier,
            ) {
                Text(action, color = BoSub, fontSize = 12.sp)
                Icon(Icons.Default.ChevronRight, null, tint = BoSub, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun TaskCard(icon: ImageVector, color: Color, title: String, desc: String, time: String, action: String, onClick: () -> Unit) {
    BoRaisedCard(Modifier.padding(bottom = 7.dp).clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(48.dp).clip(RoundedCornerShape(4.dp)).background(color))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(color.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(desc, color = BoSub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(time, color = BoMuted, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(action, color = BoRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ChevronRight, null, tint = BoRed, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun QuickTile(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(72.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(BoCard),
        elevation = CardDefaults.cardElevation(2.dp),
    ) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(BoRedSoft), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = BoRed, modifier = Modifier.size(19.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(label, color = BoInk, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun RecentListing(imagePath: String, name: String, code: String, price: String, grade: String, onClick: () -> Unit) {
    BoRaisedCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            ProductThumb(imagePath, 72)
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("SKU: $code", color = BoSub, fontSize = 11.sp, maxLines = 1)
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GradeChip("$grade · 09:25", selected = false)
                    Spacer(Modifier.width(7.dp))
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFFE8F8EF)).padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Text("已上架", color = BoGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(price, color = BoRed, fontSize = 20.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun CleanCameraScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var pendingFile by remember { mutableStateOf<File?>(null) }
    var relaunchCamera by remember { mutableStateOf(false) }
    fun launchCamera(camera: androidx.activity.result.ActivityResultLauncher<android.net.Uri>) {
        val nextFile = vm.photoFile()
        pendingFile = nextFile
        vm.rememberPendingPhoto(nextFile)
        val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.files", nextFile)
        camera.launch(uri)
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) {
            val captured = pendingFile?.let(vm::resolveCapturedPhoto)
            if (captured != null) {
                vm.addPhotoToBatch(captured)
                relaunchCamera = true
            } else {
                vm.notify("相机没有返回照片，请重拍或从相册选择")
            }
        }
    }
    LaunchedEffect(relaunchCamera) {
        if (relaunchCamera) {
            relaunchCamera = false
            launchCamera(camera)
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCamera(camera)
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { picked ->
        picked.take(6).forEach { uri ->
            val target = vm.photoFile()
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            vm.addPhotoToBatch(target)
        }
    }
    Scaffold(containerColor = Color(0xFF07172B)) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 24.dp)) {
            BoTopBar(onBack = { vm.navigate(AppScreen.Dashboard) })
            Text("拍照上架", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text("连拍多个角度，拍够后按返回，再一起识别和上传", color = Color.White.copy(.68f), fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            var previewPath by remember { mutableStateOf<String?>(null) }
            CameraFrame(state.photo?.absolutePath) {
                if (!state.photo?.absolutePath.isNullOrBlank()) previewPath = state.photo!!.absolutePath
            }
            Spacer(Modifier.height(12.dp))
            if (state.photoBatch.isNotEmpty()) {
                ThumbnailStrip(
                    imagePaths = state.photoBatch,
                    onAdd = {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        if (granted) launchCamera(camera) else permission.launch(Manifest.permission.CAMERA)
                    },
                    onClear = vm::removePhotoFromBatch,
                    onPreview = { previewPath = it },
                )
            }
            previewPath?.let { ImagePreviewDialog(it) { previewPath = null } }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                CircleTool(Icons.Default.PhotoLibrary, "相册") { gallery.launch("image/*") }
                Box(
                    Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(4.dp, BoRed.copy(.25f), CircleShape)
                        .background(BoRed)
                        .clickable {
                            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            if (granted) launchCamera(camera) else permission.launch(Manifest.permission.CAMERA)
                        },
                )
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { vm.navigate(AppScreen.Dashboard) },
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color.White.copy(.16f)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(.08f), contentColor = Color.White),
                ) { Text("取消", fontWeight = FontWeight.Bold) }
                Button(
                    onClick = {
                        if (state.photoBatch.isNotEmpty()) {
                            vm.startBatchRecognition()
                        } else {
                            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            if (granted) launchCamera(camera) else permission.launch(Manifest.permission.CAMERA)
                        }
                    },
                    modifier = Modifier.weight(1.75f).height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BoRed, contentColor = Color.White),
                ) { Text(if (state.photoBatch.isNotEmpty()) "开始识别 ${state.photoBatch.size} 张" else "拍第一张", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun CameraFrame(imagePath: String?, onPreview: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1.02f)
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xFFB99472)),
        contentAlignment = Alignment.Center,
    ) {
        if (!imagePath.isNullOrBlank()) {
            ProductImage(imagePath, Modifier.fillMaxSize().clickable(onClick = onPreview), ContentScale.Crop)
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CameraAlt, null, tint = BoSub, modifier = Modifier.size(58.dp))
                Spacer(Modifier.height(12.dp))
                Text("将商品置于取景框内", color = Color.White, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(Color.Black.copy(.35f)).padding(horizontal = 18.dp, vertical = 9.dp))
            }
        }
        CornerMark(Modifier.align(Alignment.TopStart).padding(28.dp), top = true, start = true)
        CornerMark(Modifier.align(Alignment.TopEnd).padding(28.dp), top = true, start = false)
        CornerMark(Modifier.align(Alignment.BottomStart).padding(28.dp), top = false, start = true)
        CornerMark(Modifier.align(Alignment.BottomEnd).padding(28.dp), top = false, start = false)
    }
}

@Composable
private fun CornerMark(modifier: Modifier, top: Boolean, start: Boolean) {
    Box(modifier.size(34.dp)) {
        Box(
            Modifier
                .align(if (top) Alignment.TopCenter else Alignment.BottomCenter)
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(BoRed),
        )
        Box(
            Modifier
                .align(if (start) Alignment.CenterStart else Alignment.CenterEnd)
                .width(4.dp)
                .fillMaxSize()
                .clip(RoundedCornerShape(4.dp))
                .background(BoRed),
        )
    }
}

@Composable
private fun ThumbnailStrip(imagePaths: List<String>, onAdd: () -> Unit, onClear: (String) -> Unit, onPreview: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        imagePaths.forEachIndexed { index, imagePath ->
            Box(Modifier.size(70.dp).clip(RoundedCornerShape(13.dp)).background(Color.White).border(1.dp, if (index == 0) BoRed else BoLine, RoundedCornerShape(13.dp)).clickable { onPreview(imagePath) }) {
                ProductImage(imagePath, Modifier.fillMaxSize(), ContentScale.Crop)
                Box(Modifier.align(Alignment.TopEnd).padding(4.dp).size(18.dp).clip(CircleShape).background(Color.White.copy(.85f)).clickable { onClear(imagePath) }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Close, null, tint = BoSub, modifier = Modifier.size(12.dp))
                }
                Box(Modifier.align(Alignment.BottomEnd).padding(4.dp).size(18.dp).clip(CircleShape).background(Color.White.copy(.9f)), contentAlignment = Alignment.Center) {
                    Text("${index + 1}", color = BoInk, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Box(Modifier.size(70.dp).clip(RoundedCornerShape(13.dp)).border(1.dp, BoLine, RoundedCornerShape(13.dp)).background(Color.White).clickable(onClick = onAdd), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Add, null, tint = BoSub, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun CircleTool(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(8.dp)) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(.10f)).border(1.dp, Color.White.copy(.10f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White.copy(.88f), fontSize = 11.sp)
    }
}

@Composable
fun CleanProcessingScreen(state: UiState) {
    Scaffold(containerColor = BoBg) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(Modifier.size(90.dp).clip(CircleShape).background(BoRedSoft), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, null, tint = BoRed, modifier = Modifier.size(42.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text("AI 正在识别商品", color = BoInk, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(
                state.status.ifBlank { "生成名称、成色、描述和适合上架的图片" },
                color = BoSub,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun CleanConfirmScreen(vm: MainViewModel, state: UiState) {
    var previewPath by remember { mutableStateOf<String?>(null) }
    var showCategoryOptions by remember { mutableStateOf(false) }
    var showFacetOptions by remember { mutableStateOf(false) }
    Scaffold(
        containerColor = BoBg,
        bottomBar = {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .border(1.dp, Color(0x0A111827))
                    .padding(horizontal = 24.dp, vertical = 12.dp)
                    .navigationBarsPadding(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Button(
                    onClick = { vm.saveOnly() },
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(15.dp),
                    border = BorderStroke(1.dp, BoLine),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = BoInk),
                ) { Text("保存草稿", fontWeight = FontWeight.Bold, fontFamily = BoFont) }
                Button(
                    onClick = { vm.navigate(AppScreen.LabelPreview) },
                    enabled = !state.busy && state.name.isNotBlank() && state.categoryCode.isNotBlank(),
                    modifier = Modifier.weight(1.6f).height(56.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BoRed, contentColor = Color.White),
                ) { Text("打印并上架", fontWeight = FontWeight.Bold, fontFamily = BoFont) }
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
            BoTopBar(onBack = { vm.navigate(AppScreen.Camera) }, rightText = "重新识别") { vm.navigate(AppScreen.Camera) }
            if (state.status.isNotBlank() && state.status != "请先拍照") {
                BoRaisedCard {
                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        if (state.busy) {
                            androidx.compose.material3.CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = BoRed,
                            )
                        } else {
                            Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF16A34A), modifier = Modifier.size(18.dp))
                        }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(state.status, color = BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("原图保存后即可继续操作；上架图会在 ERP 后台静默修整", color = BoSub, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            val chips = listOf(state.brand, state.material, state.category).filter { it.isNotBlank() }
            BoRaisedCard {
                Box(Modifier.fillMaxWidth().height(210.dp).padding(10.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFF6F6F6))) {
                    if (!state.photo?.absolutePath.isNullOrBlank()) {
                        ProductImage(state.photo!!.absolutePath, Modifier.fillMaxSize().clickable { previewPath = state.photo!!.absolutePath }, ContentScale.Crop)
                    } else {
                        Text("暂无商品图", color = BoMuted, modifier = Modifier.align(Alignment.Center))
                    }
                    Text(if (state.busy) "AI识别中" else "AI识别", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(RoundedCornerShape(bottomEnd = 8.dp)).background(BoRed).padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }
            if (state.photoBatch.size > 1) {
                Spacer(Modifier.height(10.dp))
                ThumbnailStrip(
                    imagePaths = state.photoBatch,
                    onAdd = { vm.navigate(AppScreen.Camera) },
                    onClear = vm::removePhotoFromBatch,
                    onPreview = { previewPath = it },
                )
            }
            if (chips.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    chips.forEach { SmallChip(it) }
                }
            }
            Spacer(Modifier.height(10.dp))
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    FieldLabel("商品名称 *")
                    OutlinedTextField(
                        value = state.name,
                        onValueChange = vm::updateName,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("AI 识别后自动填写；也可手动输入") },
                        trailingIcon = { Text("${state.name.length}/28", color = BoSub, fontSize = 10.sp) },
                    )
                    FieldLabel("商品分类 *")
                    OutlinedButton(
                        onClick = {
                            if (state.listingCategoryOptions.isEmpty()) vm.loadProductCategories()
                            showCategoryOptions = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BoLine),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                    ) {
                        Text(
                            state.category.ifBlank { "请选择 ERP 商品分类" },
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Start,
                            color = if (state.category.isBlank()) BoMuted else BoInk,
                        )
                        Icon(Icons.Default.KeyboardArrowDown, null, tint = BoSub)
                    }
                    FieldLabel("IP / 角色 / 系列")
                    OutlinedTextField(
                        value = state.ipName,
                        onValueChange = vm::updateIpName,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("例如：Hello Kitty、宝可梦") },
                    )
                    when {
                        state.ipMatchStatus == "matched" -> Text(
                            "已匹配 ERP IP 库",
                            color = Color(0xFF16A34A),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                        state.ipName.isNotBlank() -> Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("未找到完全匹配，请确认名称", color = Color(0xFFD97706), fontSize = 11.sp)
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = vm::confirmIpName) {
                                Text(if (state.ipConfirmed) "已确认" else "确认新建")
                            }
                        }
                    }
                    FieldLabel("商品标签")
                    val availableFacets = vm.listingFacetsForCurrentCategory()
                    val selectedFacetNames = availableFacets
                        .filter { it.code in state.selectedFacetCodes }
                        .map { it.name }
                    OutlinedButton(
                        onClick = { showFacetOptions = true },
                        enabled = state.categoryCode.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BoLine),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
                    ) {
                        Text(
                            when {
                                state.categoryCode.isBlank() -> "请先选择商品分类"
                                selectedFacetNames.isEmpty() -> "选择 ERP 商品标签（可多选）"
                                else -> selectedFacetNames.joinToString("、")
                            },
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Start,
                            color = if (selectedFacetNames.isEmpty()) BoMuted else BoInk,
                            maxLines = 2,
                        )
                        Icon(Icons.Default.KeyboardArrowDown, null, tint = BoSub)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            BoRaisedCard {
                Column(Modifier.padding(14.dp)) {
                    FieldLabel("商品成色 *")
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf("N", "S", "A", "B", "C", "J").forEach { grade ->
                            GradeChip(
                                text = when (grade) {
                                    "N" -> "N 全新"
                                    "S" -> "S 近新"
                                    "A" -> "A 很好"
                                    "B" -> "B 良好"
                                    "C" -> "C 一般"
                                    else -> "J 垃圾"
                                },
                                selected = state.conditionGrade == grade,
                                modifier = Modifier.weight(1f),
                            ) { vm.updateConditionGrade(grade) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(state.conditionNote.ifBlank { "AI 识别后会给出成色说明；请人工最终确认" }, color = BoSub, fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            FieldLabel("售价 *")
                            OutlinedTextField(value = state.price, onValueChange = vm::updatePrice, singleLine = true, prefix = { Text("¥ ") }, placeholder = { Text("手动填写") }, modifier = Modifier.fillMaxWidth())
                        }
                        Column(Modifier.weight(1f)) {
                            FieldLabel("库存 *")
                            OutlinedTextField(value = "1", onValueChange = {}, singleLine = true, suffix = { Text("件") }, modifier = Modifier.fillMaxWidth())
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("加入翻筐乐", color = BoInk, modifier = Modifier.weight(1f))
                        Switch(
                            checked = fankuangEnrollment(state.price, state.fankuangOverride),
                            onCheckedChange = vm::updateFankuangEnrollment,
                            enabled = !state.busy,
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    FieldLabel("商品编码（自动生成）")
                    Text(
                        state.itemNo.ifBlank { "保存/上架时自动生成" },
                        color = BoInk,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Start,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(BoSoft).padding(13.dp),
                    )
                    FieldLabel("商品详情（AI 生成，可编辑）")
                    OutlinedTextField(
                        value = state.conditionNote,
                        onValueChange = vm::updateConditionNote,
                        placeholder = { Text("AI 识别后自动生成商品描述") },
                        modifier = Modifier.fillMaxWidth().height(110.dp),
                    )
                }
            }
            previewPath?.let { ImagePreviewDialog(it) { previewPath = null } }
            Spacer(Modifier.height(18.dp))
        }
    }
    if (showCategoryOptions) {
        val options = buildList {
            if (state.categoryCode.isNotBlank() && state.listingCategoryOptions.none { it.code == state.categoryCode }) {
                add(state.categoryCode to state.category)
            }
            addAll(state.listingCategoryOptions.map { it.code to it.displayName })
        }
        DesignOptionDialog(
            title = if (options.isEmpty()) "正在读取 ERP 分类" else "选择 ERP 商品分类",
            options = options,
            selected = state.categoryCode,
            onDismiss = { showCategoryOptions = false },
            onSelect = {
                vm.selectListingCategory(it)
                showCategoryOptions = false
            },
        )
    }
    if (showFacetOptions) {
        DesignMultiOptionDialog(
            title = "选择商品标签",
            options = vm.listingFacetsForCurrentCategory(),
            selected = state.selectedFacetCodes.toSet(),
            onDismiss = { showFacetOptions = false },
            onToggle = vm::toggleListingFacet,
        )
    }
}

@Composable
fun CleanLabelPreview(vm: MainViewModel, state: UiState) {
    val context = LocalContext.current
    val liveState by vm.state.collectAsState()
    var printCopies by remember { mutableIntStateOf(1) }
    var template by remember { mutableStateOf(vm.labelTemplate()) }
    val templates = liveState.labelTemplates.ifEmpty { vm.labelTemplates() }
    val canManageTemplates = liveState.labelTemplatesCanManage
        ?: canManageLabelTemplates(effectiveRoles(liveState.roles, liveState.locations, liveState.selectedLocation))
    LaunchedEffect(templates) {
        if (templates.none { it.id == template.id }) {
            template = vm.labelTemplate()
        }
    }
    val previewItem = remember(state.printPreviewItem, state.name, state.price, state.itemNo, state.category, state.conditionGrade, state.conditionNote, state.photo) {
        state.printPreviewItem ?: Item(
            itemNo = state.itemNo.ifBlank { "未生成" },
            name = state.name.ifBlank { "未填写商品名" },
            priceCents = ((state.price.toDoubleOrNull() ?: 0.0) * 100).toInt(),
            category = state.category.ifBlank { "未分类" },
            imagePath = state.photo?.absolutePath.orEmpty(),
            conditionGrade = state.conditionGrade.ifBlank { "-" },
            conditionNote = state.conditionNote,
        )
    }
    val labelBitmap = remember(previewItem, template, context, liveState.printOffsetXDots, liveState.printOffsetYDots) {
        LabelRenderer.renderPhysicalPreview(
            previewItem,
            template,
            context = context,
            offsetXDots = liveState.printOffsetXDots,
            offsetYDots = liveState.printOffsetYDots,
        )
    }
    Scaffold(
        containerColor = BoBg,
        bottomBar = {
            Button(
                onClick = {
                    state.printPreviewItem?.let { vm.printItem(it, printCopies, template) } ?: vm.saveAndPrint(printCopies, template)
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp).navigationBarsPadding().height(56.dp).shadow(3.dp, RoundedCornerShape(16.dp), ambientColor = BoRed.copy(.08f), spotColor = BoRed.copy(.12f)),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BoRed, contentColor = Color.White),
            ) {
                Icon(Icons.Default.Print, null)
                Spacer(Modifier.width(8.dp))
                Text(if (state.printPreviewItem == null) "打印标签" else "打印当前商品", fontWeight = FontWeight.Bold, fontFamily = BoFont)
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
            BoTopBar(onBack = { vm.navigate(if (state.printPreviewItem == null) AppScreen.Confirm else AppScreen.ProductDetail) })
            if (liveState.status.isNotBlank() && liveState.status != "请先拍照") {
                StatusBanner(liveState.status)
                Spacer(Modifier.height(12.dp))
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Surface(
                    modifier = Modifier.width(285.dp).shadow(4.dp, RoundedCornerShape(8.dp), ambientColor = Color.Black.copy(.08f), spotColor = Color.Black.copy(.08f)),
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White,
                ) {
                    Image(labelBitmap.asImageBitmap(), null, modifier = Modifier.fillMaxWidth().aspectRatio(424f / 280f).padding(10.dp), contentScale = ContentScale.Fit)
                }
            }
            Spacer(Modifier.height(14.dp))
            BoRaisedCard {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(BoRedSoft), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Print, null, tint = BoRed, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("固定标签规格", color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Text("53 × 35mm 纸张 · 预览含物理左右边距 · 可打印区 384×280 dots", color = BoSub, fontSize = 12.sp)
                    }
                    StatusPill(template.templateName, BoRed)
                }
            }
            SectionTitle("选择打印模板", null, if (canManageTemplates) "新建" else null) {
                if (canManageTemplates) vm.createLabelTemplate()
            }
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (!canManageTemplates) {
                        Text("模板由总部统一维护，当前账号只能选择模板并打印。", color = BoSub, fontSize = 12.sp)
                    }
                    templates.forEach { candidate ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (candidate.id == template.id) BoRedSoft else Color.White)
                                .border(1.dp, if (candidate.id == template.id) BoRed else BoLine, RoundedCornerShape(14.dp))
                                .clickable { template = candidate }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(candidate.templateName, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                Text("${candidate.widthMm}×${candidate.heightMm}mm · ${candidate.elements.count { it.enabled }} 个变量元素", color = BoSub, fontSize = 11.sp)
                            }
                            if (candidate.id == template.id) StatusPill("当前", BoRed)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        if (canManageTemplates) {
                            OutlineButton("编辑模板", Modifier.weight(1f), Icons.Default.Edit) {
                                vm.editLabelTemplate(
                                    template,
                                    returnTo = if (state.printPreviewItem == null) AppScreen.Confirm else AppScreen.ProductDetail,
                                )
                            }
                        }
                        OutlineButton("打印机设置", Modifier.weight(1f), Icons.Default.Settings) {
                            runCatching {
                                context.startActivity(Intent("com.sunmi.printer.settings").addCategory(Intent.CATEGORY_DEFAULT))
                            }.onFailure {
                                vm.notify("无法打开商米打印设置：${it.message}")
                            }
                        }
                    }
                }
            }
            SectionTitle("打印设置", null, null)
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    StepperRow("打印份数", printCopies, onMinus = { printCopies = (printCopies - 1).coerceAtLeast(1) }, onPlus = { printCopies = (printCopies + 1).coerceAtMost(10) })
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("打印并上架", color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("先发送打印，再提交 ERP 建档", color = BoSub, fontSize = 11.sp)
                        }
                        StatusPill("自动", BoGreen)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
fun LabelTemplateEditorScreen(vm: MainViewModel, state: UiState) {
    val context = LocalContext.current
    var template by remember(state.editingLabelTemplate?.id) {
        mutableStateOf(state.editingLabelTemplate ?: vm.labelTemplate())
    }
    var selectedId by remember(template.id) { mutableStateOf(template.elements.firstOrNull()?.id.orEmpty()) }
    var snapGuides by remember(template.id) { mutableStateOf(emptyList<SnapGuide>()) }
    var resizingId by remember(template.id) { mutableStateOf<String?>(null) }
    val sampleItem = remember {
        Item(
            itemNo = "VG202506290001",
            name = "示例中古商品",
            priceCents = 69900,
            category = "相机 / 胶片相机",
            imagePath = "",
            conditionGrade = "A",
            conditionNote = "轻微使用痕迹，功能正常",
        )
    }
    val selected = template.elements.firstOrNull { it.id == selectedId }
    Scaffold(
        containerColor = BoBg,
        bottomBar = {
            Button(
                onClick = {
                    vm.saveEditingLabelTemplate(template)
                    vm.navigate(state.labelTemplateReturnScreen)
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp).navigationBarsPadding().height(56.dp).shadow(3.dp, RoundedCornerShape(16.dp), ambientColor = BoRed.copy(.08f), spotColor = BoRed.copy(.12f)),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BoRed, contentColor = Color.White),
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(8.dp))
                Text("保存模板", fontWeight = FontWeight.Bold, fontFamily = BoFont)
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
            BoTopBar(onBack = { vm.navigate(state.labelTemplateReturnScreen) }, rightText = "设为默认") {
                vm.saveLabelTemplate(template)
            }
            Text(
                if (template.printType == PrintTemplateType.RECEIPT) "小票模板编辑器" else "标签模板编辑器",
                color = BoInk,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = BoFont,
            )
            Text(
                if (template.printType == PrintTemplateType.RECEIPT) {
                    "拖动小票标题、内容和二维码调整位置。小票固定使用 58mm 纸张。"
                } else {
                    "拖动标签里的文字或条码即可调整位置。打印时会自动替换成真实商品内容。"
                },
                color = BoSub,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = template.templateName,
                onValueChange = { template = template.copy(templateName = it.take(18)) },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                singleLine = true,
                label = { Text("模板名称") },
            )
            Spacer(Modifier.height(8.dp))
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val canvasWidth = maxWidth * 0.92f
                val canvasHeight = canvasWidth * template.heightMm / template.widthMm
                val scale = canvasWidth.value / LabelRenderer.PHYSICAL_WIDTH_DOTS
                val scalePx = with(density) { canvasWidth.toPx() } / LabelRenderer.PHYSICAL_WIDTH_DOTS
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (template.printType == PrintTemplateType.RECEIPT) {
                            "小票纸宽 58mm"
                        } else {
                            "标签实际尺寸 ${template.widthMm}×${template.heightMm}mm"
                        },
                        color = BoSub,
                        fontSize = 11.sp,
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier
                            .width(canvasWidth)
                            .height(canvasHeight)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White)
                            .border(1.dp, BoInk.copy(.16f), RoundedCornerShape(14.dp)),
                    ) {
                        val previewBitmap = remember(sampleItem, template, context) {
                            LabelRenderer.renderPhysicalPreview(sampleItem, template, context = context)
                        }
                        Image(
                            previewBitmap.asImageBitmap(),
                            null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.FillBounds,
                        )
                        Canvas(Modifier.fillMaxSize()) {
                            val inset = 6.dp.toPx()
                            val guideDash = PathEffect.dashPathEffect(floatArrayOf(9f, 7f), 0f)
                            drawRoundRect(
                                color = BoRed.copy(alpha = 0.55f),
                                topLeft = androidx.compose.ui.geometry.Offset(inset, inset),
                                size = androidx.compose.ui.geometry.Size(size.width - inset * 2, size.height - inset * 2),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx(), 10.dp.toPx()),
                                style = Stroke(width = 1.4.dp.toPx(), pathEffect = guideDash),
                            )
                            val printableLeft = LabelRenderer.PREVIEW_LEFT_MARGIN_DOTS.toFloat() / LabelRenderer.PHYSICAL_WIDTH_DOTS * size.width
                            val printableWidth = LabelRenderer.WIDTH_DOTS.toFloat() / LabelRenderer.PHYSICAL_WIDTH_DOTS * size.width
                            drawRoundRect(
                                color = BoInk.copy(alpha = 0.28f),
                                topLeft = androidx.compose.ui.geometry.Offset(printableLeft, inset),
                                size = androidx.compose.ui.geometry.Size(printableWidth, size.height - inset * 2),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx(), 8.dp.toPx()),
                                style = Stroke(width = 1.dp.toPx(), pathEffect = guideDash),
                            )
                            snapGuides.forEach { guide ->
                                when (guide.orientation) {
                                    GuideOrientation.Vertical -> {
                                        val x = (LabelRenderer.PREVIEW_LEFT_MARGIN_DOTS + guide.position) / LabelRenderer.PHYSICAL_WIDTH_DOTS * size.width
                                        drawLine(
                                            color = BoRed.copy(alpha = 0.9f),
                                            start = androidx.compose.ui.geometry.Offset(x, 0f),
                                            end = androidx.compose.ui.geometry.Offset(x, size.height),
                                            strokeWidth = 1.5.dp.toPx(),
                                            pathEffect = guideDash,
                                        )
                                    }
                                    GuideOrientation.Horizontal -> {
                                        val y = guide.position / LabelRenderer.HEIGHT_DOTS * size.height
                                        drawLine(
                                            color = BoRed.copy(alpha = 0.9f),
                                            start = androidx.compose.ui.geometry.Offset(0f, y),
                                            end = androidx.compose.ui.geometry.Offset(size.width, y),
                                            strokeWidth = 1.5.dp.toPx(),
                                            pathEffect = guideDash,
                                        )
                                    }
                                }
                            }
                            listOfNotNull(selectedId.ifBlank { null }, resizingId).distinct().forEach { activeId ->
                                template.elements.firstOrNull { it.id == activeId && it.enabled }?.let { element ->
                                    val left = (LabelRenderer.PREVIEW_LEFT_MARGIN_DOTS + element.x) / LabelRenderer.PHYSICAL_WIDTH_DOTS * size.width
                                    val top = element.y / LabelRenderer.HEIGHT_DOTS * size.height
                                    val width = element.width / LabelRenderer.PHYSICAL_WIDTH_DOTS * size.width
                                    val height = element.height / LabelRenderer.HEIGHT_DOTS * size.height
                                    drawRoundRect(
                                        color = BoRed.copy(alpha = 0.85f),
                                        topLeft = androidx.compose.ui.geometry.Offset(left, top),
                                        size = androidx.compose.ui.geometry.Size(width, height),
                                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx(), 5.dp.toPx()),
                                        style = Stroke(width = 1.4.dp.toPx(), pathEffect = guideDash),
                                    )
                                }
                            }
                        }
                        template.elements.filter { it.enabled }.forEach { element ->
                            val active = element.id == selectedId
                            Box(
                                Modifier
                                    .offset(x = ((LabelRenderer.PREVIEW_LEFT_MARGIN_DOTS + element.x) * scale).dp, y = (element.y * scale).dp)
                                    .width((element.width * scale).dp)
                                    .height((element.height * scale).dp)
                                    .clickable { selectedId = element.id }
                                    .pointerInput(element.id, scalePx) {
                                        detectDragGestures(
                                            onDragEnd = { snapGuides = emptyList() },
                                            onDragCancel = { snapGuides = emptyList() },
                                        ) { change, dragAmount ->
                                            change.consume()
                                            selectedId = element.id
                                            template = template.updateElement(element.id) {
                                                val rawX = (it.x + dragAmount.x / scalePx).coerceIn(0f, LabelRenderer.WIDTH_DOTS - it.width)
                                                val rawY = (it.y + dragAmount.y / scalePx).coerceIn(0f, LabelRenderer.HEIGHT_DOTS - it.height)
                                                val snapped = snapElement(rawX, rawY, it, template.elements)
                                                snapGuides = snapped.guides
                                                it.copy(x = snapped.x, y = snapped.y)
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (active) {
                                    Box(
                                        Modifier
                                            .align(Alignment.BottomEnd)
                                            .offset(x = 8.dp, y = 8.dp)
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(BoRed)
                                            .border(2.dp, Color.White, CircleShape)
                                            .clickable {
                                                selectedId = element.id
                                                template = template.updateElement(element.id) {
                                                    scaleElementContent(it, 10f, 8f)
                                                }
                                            }
                                            .pointerInput(element.id, scalePx) {
                                                detectDragGestures(
                                                    onDragStart = {
                                                        snapGuides = emptyList()
                                                        resizingId = element.id
                                                    },
                                                    onDragEnd = {
                                                        snapGuides = emptyList()
                                                        resizingId = null
                                                    },
                                                    onDragCancel = {
                                                        snapGuides = emptyList()
                                                        resizingId = null
                                                    },
                                                ) { change, dragAmount ->
                                                    change.consume()
                                                    selectedId = element.id
                                                    template = template.updateElement(element.id) {
                                                        scaleElementContent(it, dragAmount.x / scalePx, dragAmount.y / scalePx)
                                                    }
                                                }
                                            },
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("红色虚线为纸张边界，灰色虚线为 V3 可打印区", color = BoSub, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    ElementNudgePad(
                        enabled = selected != null,
                        onMove = { dx, dy ->
                            selected?.let { active ->
                                template = template.updateElement(active.id) { moveElement(it, dx, dy) }
                            }
                        },
                    )
                    Spacer(Modifier.height(8.dp))
                    SelectedElementQuickAdjust(
                        selected = selected,
                        onUpdate = { transform ->
                            selected?.let { active ->
                                template = template.updateElement(active.id, transform)
                            }
                        },
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            SectionTitle("添加变量", null, null)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    LabelElementType.LOGO,
                    LabelElementType.ITEM_NAME,
                    LabelElementType.PRICE,
                    LabelElementType.CATEGORY,
                    LabelElementType.DESCRIPTION,
                    LabelElementType.CONDITION,
                    LabelElementType.ITEM_CODE,
                    LabelElementType.BARCODE,
                    LabelElementType.QR_CODE,
                    LabelElementType.CUSTOM_TEXT,
                    LabelElementType.IMAGE,
                ).forEach { type ->
                    ChoiceChip(type.title, false) {
                        val newElement = newTemplateElement(type)
                        template = template.copy(elements = template.elements + newElement)
                        selectedId = newElement.id
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            SectionTitle("元素属性", null, null)
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (selected == null) {
                        Text("请先选择一个元素", color = BoSub, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    } else {
                        val supportsTextAlign = selected.type !in setOf(LabelElementType.LOGO, LabelElementType.IMAGE, LabelElementType.BARCODE, LabelElementType.QR_CODE)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(selected.type.title, color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                            Text("删除", color = BoRed, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable {
                                template = template.copy(elements = template.elements.filterNot { it.id == selected.id })
                                selectedId = template.elements.firstOrNull()?.id.orEmpty()
                            })
                        }
                        if (selected.type == LabelElementType.LOGO) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ChoiceChip("横版 Logo", selected.customText != LOGO_STACKED) {
                                    template = template.updateElement(selected.id) { it.copy(customText = LOGO_HORIZONTAL, enabled = true) }
                                }
                                ChoiceChip("叠版 Logo", selected.customText == LOGO_STACKED) {
                                    template = template.updateElement(selected.id) { it.copy(customText = LOGO_STACKED, enabled = true) }
                                }
                            }
                        }
                        if (selected.type == LabelElementType.CUSTOM_TEXT) {
                            OutlinedTextField(
                                value = selected.customText,
                                onValueChange = { value ->
                                    template = template.updateElement(selected.id) { it.copy(customText = value.take(30)) }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("文字内容") },
                            )
                        }
                        if (selected.type == LabelElementType.IMAGE) {
                            Text(
                                "图片元素固定为商品图片变量，不支持上传固定图片，避免换设备后丢失。",
                                color = BoSub,
                                fontSize = 11.sp,
                            )
                        }
                        if (supportsTextAlign) {
                            Text("排版", color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ChoiceChip("居左", selected.align == TEXT_ALIGN_LEFT) {
                                    template = template.updateElement(selected.id) { it.copy(align = TEXT_ALIGN_LEFT) }
                                }
                                ChoiceChip("居中", selected.align == TEXT_ALIGN_CENTER) {
                                    template = template.updateElement(selected.id) { it.copy(align = TEXT_ALIGN_CENTER) }
                                }
                                ChoiceChip("居右", selected.align == TEXT_ALIGN_RIGHT) {
                                    template = template.updateElement(selected.id) { it.copy(align = TEXT_ALIGN_RIGHT) }
                                }
                            }
                            Text("字体", color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ChoiceChip("黑体", selected.fontFamily == FONT_SANS) {
                                    template = template.updateElement(selected.id) { it.copy(fontFamily = FONT_SANS) }
                                }
                                ChoiceChip("宋体", selected.fontFamily == FONT_SERIF) {
                                    template = template.updateElement(selected.id) { it.copy(fontFamily = FONT_SERIF) }
                                }
                                ChoiceChip("等宽", selected.fontFamily == FONT_MONO) {
                                    template = template.updateElement(selected.id) { it.copy(fontFamily = FONT_MONO) }
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlineButton(if (selected.bold) "取消加粗" else "加粗", Modifier.weight(1f), null) {
                                    template = template.updateElement(selected.id) { it.copy(bold = !it.bold) }
                                }
                                OutlineButton(if (selected.italic) "取消倾斜" else "倾斜", Modifier.weight(1f), null) {
                                    template = template.updateElement(selected.id) { it.copy(italic = !it.italic) }
                                }
                                OutlineButton(if (selected.underline) "取消下划线" else "下划线", Modifier.weight(1f), null) {
                                    template = template.updateElement(selected.id) { it.copy(underline = !it.underline) }
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlineButton(if (selected.boxed) "取消线框" else "线框", Modifier.weight(1f), null) {
                                    template = template.updateElement(selected.id) { it.copy(boxed = !it.boxed) }
                                }
                                Text(
                                    "适合成色等级，如 A级 外面加一圈方框",
                                    color = BoSub,
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(2f).align(Alignment.CenterVertically),
                                )
                            }
                        }
                        StepperRow("宽度", selected.width.roundToInt(), onMinus = {
                            template = template.updateElement(selected.id) {
                                val minWidth = if (it.type == LabelElementType.BARCODE) 120f else 24f
                                it.copy(width = (it.width - 8f).coerceAtLeast(minWidth))
                            }
                        }, onPlus = {
                            template = template.updateElement(selected.id) { it.copy(width = (it.width + 8f).coerceAtMost(LabelRenderer.WIDTH_DOTS - it.x)) }
                        })
                        StepperRow("高度", selected.height.roundToInt(), onMinus = {
                            template = template.updateElement(selected.id) { it.copy(height = (it.height - 6f).coerceAtLeast(16f)) }
                        }, onPlus = {
                            template = template.updateElement(selected.id) { it.copy(height = (it.height + 6f).coerceAtMost(LabelRenderer.HEIGHT_DOTS - it.y)) }
                        })
                        StepperRow("字号", selected.textSize.roundToInt(), onMinus = {
                            template = template.updateElement(selected.id) { it.copy(textSize = (it.textSize - 1f).coerceAtLeast(8f)) }
                        }, onPlus = {
                            template = template.updateElement(selected.id) { it.copy(textSize = (it.textSize + 1f).coerceAtMost(48f)) }
                        })
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlineButton("隐藏", Modifier.fillMaxWidth(), Icons.Default.VisibilityOff) {
                                template = template.updateElement(selected.id) { it.copy(enabled = false) }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun CleanProductsScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    var showSortOptions by remember { mutableStateOf(false) }
    var showCategoryOptions by remember { mutableStateOf(false) }
    val items = state.items
    LaunchedEffect(state.loggedIn, state.homeMessagesGeneration, state.locationSwitching) {
        if (state.loggedIn) vm.loadProductsFromErp()
    }
    Scaffold(containerColor = BoBg, bottomBar = { CleanBottomNav(vm, AppScreen.Products) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 28.dp)) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("商品", color = BoInk, fontSize = 24.sp, fontWeight = FontWeight.Black, fontFamily = BoFont)
                Spacer(Modifier.width(4.dp))
                ProductOrderTitleSwitch("订单") { vm.navigate(AppScreen.Orders) }
                Spacer(Modifier.width(8.dp))
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End)) {
                    CompactProductTypeTab("自定义", state.productCounts.custom, state.productType == "custom") { vm.selectProductType("custom") }
                    CompactProductTypeTab("组包", state.productCounts.bundle, state.productType == "bundle") { vm.selectProductType("bundle") }
                    CompactProductTypeTab("标准", state.productCounts.standard, state.productType == "standard") { vm.selectProductType("standard") }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (state.canShowHQTools) {
                Row(Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(16.dp)).background(BoSoft).padding(3.dp)) {
                    val currentLabel = state.selectedLocation?.let { productLocationLabel(it.name, it.kind) }.orEmpty()
                    DesignSegmentButton("当前$currentLabel", state.productViewScope == ProductViewScope.Current, Modifier.weight(1f)) {
                        vm.selectProductScope(ProductViewScope.Current)
                    }
                    DesignSegmentButton("所有门店", state.productViewScope == ProductViewScope.All, Modifier.weight(1f)) {
                        vm.selectProductScope(ProductViewScope.All)
                    }
                }
            } else {
                Text("当前门店：${state.productScopeLabel()}", color = BoSub, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            DesignSearchBox(
                value = state.search,
                placeholder = "搜索商品名称 / 条码 / SKU",
                onValueChange = vm::updateSearch,
            )
            Spacer(Modifier.height(10.dp))
            ProductStatusTabs(state.productStatus) { vm.selectProductStatus(it) }
            Spacer(Modifier.height(8.dp))
            Text(
                "当前范围：${state.productScopeLabel()} · ${productStatusLabel(state.productStatus)}",
                color = BoSub,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DesignFilterPill("排序：${sortLabel(state.productSort)}") { showSortOptions = true }
                DesignFilterPill("分类：${if (state.productCategory.isBlank()) "全部" else categoryLabel(state.productCategory)}") {
                    showCategoryOptions = true
                }
                DesignFilterPill(if (state.productOnlyFankuang) "✓ 仅翻筐乐" else "仅翻筐乐") { vm.toggleProductFankuang() }
                if (state.productType == "custom") {
                    DesignFilterPill(
                        when (state.productHasImage) {
                            true -> "只看有图"
                            false -> "只看缺图"
                            else -> "只看缺图"
                        },
                    ) {
                        vm.toggleProductHasImage(
                            when (state.productHasImage) {
                                null -> false
                                false -> true
                                true -> null
                            },
                        )
                    }
                }
            }
            if (showSortOptions) {
                DesignOptionDialog(
                    title = "选择排序方式",
                    options = productSortOptions,
                    selected = state.productSort,
                    onDismiss = { showSortOptions = false },
                    onSelect = {
                        showSortOptions = false
                        vm.selectProductSort(it)
                    },
                )
            }
            if (showCategoryOptions) {
                DesignOptionDialog(
                    title = "选择商品分类",
                    options = productCategoryOptions,
                    selected = state.productCategory,
                    onDismiss = { showCategoryOptions = false },
                    onSelect = {
                        showCategoryOptions = false
                        vm.selectProductCategory(it)
                    },
                )
            }
            Spacer(Modifier.height(12.dp))
            if (state.productLoading) {
                Text("同步中…", color = BoRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
            }
            if (state.productError.isNotBlank()) {
                Text(state.productError, color = BoRed, fontSize = 12.sp)
                TextButton(onClick = { vm.loadProductsFromErp() }) { Text("重新加载", color = BoRed) }
            }
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (state.productLoading && items.isEmpty()) {
                    DesignEmptyPanel(
                        "正在同步商品",
                        "正在读取 ${state.productScopeLabel()} 商品",
                    )
                } else if (state.productError.isNotBlank() && items.isEmpty()) {
                    DesignEmptyPanel("商品读取失败", "${state.productScopeLabel()} 范围未能确认，请重新加载")
                } else if (items.isEmpty()) {
                    DesignEmptyPanel("没有匹配商品", "${state.productScopeLabel()} 当前筛选条件下暂无商品")
                } else {
                    items.forEach { item ->
                        DesignProductRow(item, productLocationBadges(item.productStocks),
                            if (state.productViewScope == ProductViewScope.All) "总库存" else "当前库存") { vm.selectItem(item) }
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun ProductTypeTab(label: String, type: String, selectedType: String, count: Int, onClick: () -> Unit) {
    val selected = selectedType == type
    Column(
        Modifier
            .width(104.dp)
            .height(66.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color.White else BoSoft)
            .border(1.dp, if (selected) BoRed.copy(.35f) else Color.Transparent, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(label, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Text("$count 件", color = if (selected) BoRed else BoSub, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun ProductFilterChip(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color.White)
            .border(1.dp, if (active) BoRed.copy(.32f) else BoLine, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (active) BoRed else BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProductLedgerRow(item: Item, onClick: () -> Unit) {
    BoRaisedCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            ProductThumb(item.imagePath, 66)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 2)
                Spacer(Modifier.height(4.dp))
                Text(item.itemNo, color = BoSub, fontSize = 11.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    MiniBadge(item.sourceLabel, if (item.sourceLabel == "ERP") BoBlue else BoOrange)
                    MiniBadge(productTypeLabel(item.productType), BoInk)
                    if (item.isUnlimitedStock) MiniBadge("库存不限", BoGreen)
                    else if (item.stockQty > 0) MiniBadge("库存 ${item.stockQty}", BoGreen)
                    if (!item.editable) MiniBadge("只读", BoSub)
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text("¥%.0f".format(item.priceCents / 100.0), color = BoRed, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text(item.conditionGrade.ifBlank { "-" }, color = BoSub, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun MiniBadge(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(999.dp)).background(color.copy(.10f)).padding(horizontal = 7.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

private fun productTypeLabel(type: String): String =
    when (type.lowercase()) {
        "standard", "normal" -> "标准商品"
        "custom", "custom_sku" -> "自定义商品"
        "bundle", "package", "combo" -> "组包商品"
        else -> "商品"
    }

private val productTypeOptions = listOf(
    "custom" to "自定义商品",
    "bundle" to "组包商品",
    "standard" to "标准商品",
)

private val stockStateOptions = listOf(
    "all" to "全部库存",
    "low" to "低库存",
    "out" to "缺货",
)

private val productStatusOptions = listOf(
    "selling" to "销售中",
    "sold_out" to "已售罄",
    "in_warehouse" to "仓库中",
)

private fun productStatusLabel(status: String): String =
    productStatusOptions.firstOrNull { it.first == status }?.second ?: "销售中"

private val productSortOptions = listOf(
    "updated_desc" to "最近更新",
    "created_desc" to "最新创建",
    "created_asc" to "最早创建",
    "price_desc" to "价格高到低",
    "price_asc" to "价格低到高",
    "stock_desc" to "库存最多",
)

private fun sortLabel(sort: String): String =
    productSortOptions.firstOrNull { it.first == sort }?.second ?: "最近更新"

private fun nextProductSort(sort: String): String =
    when (sort) {
        "updated_desc" -> "created_desc"
        "created_desc" -> "price_desc"
        "price_desc" -> "price_asc"
        "price_asc" -> "stock_desc"
        "stock_desc" -> "created_asc"
        else -> "updated_desc"
    }

private val productCategoryOptions = listOf(
    "" to "全部分类",
    "digital" to "相机数码",
    "anime_goods" to "动漫周边",
    "vintage_toy" to "中古玩具",
    "jp_porcelain" to "日本瓷器",
    "fashion" to "服饰箱包",
    "jewelry" to "饰品珠宝",
    "media" to "唱片书影音",
    "daily" to "日用杂货",
)

private fun categoryLabel(category: String): String =
    productCategoryOptions.firstOrNull { it.first == category }?.second ?: category

private fun nextCategory(category: String): String {
    val index = productCategoryOptions.indexOfFirst { it.first == category }.takeIf { it >= 0 } ?: 0
    return productCategoryOptions[(index + 1) % productCategoryOptions.size].first
}

private fun stockQtyColor(qty: Int): Color =
    when {
        qty <= 0 -> BoRed
        qty <= 5 -> BoOrange
        else -> BoGreen
    }

private fun listingStatusColor(status: String): Color =
    when (status) {
        "selling" -> BoGreen
        "sold_out" -> BoOrange
        "in_warehouse" -> BoNavy
        else -> BoSub
    }

@Composable
fun CleanProductDetailScreen(vm: MainViewModel, state: UiState) {
    val item = state.selectedItem
    var previewPath by remember(state.productDetailId, state.productScope()) { mutableStateOf<String?>(null) }
    Scaffold(containerColor = BoBg, bottomBar = { CleanBottomNav(vm, AppScreen.Products) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
            BoTopBar(onBack = { vm.navigate(AppScreen.Products) }, rightText = "重打标签") {
                item?.let { vm.printItem(it) }
            }
            if (state.status.contains("打印") || state.busy) {
                StatusBanner(state.status)
                Spacer(Modifier.height(12.dp))
            }
            if (state.productDetailLoading) {
                DesignEmptyPanel("正在读取商品详情", "当前范围：${state.productScopeLabel()}")
            } else if (state.productDetailError.isNotBlank()) {
                EmptyCard("商品详情读取失败", state.productDetailError) { vm.loadProductDetail() }
            } else if (item == null) {
                EmptyCard("未选择商品", "返回商品列表重新选择") { vm.navigate(AppScreen.Products) }
            } else {
                listingImageProcessingLabel(item.imageProcessingStatus)?.let { label ->
                    StatusBanner(label)
                    Spacer(Modifier.height(12.dp))
                }
                val images = (listOf(item.imagePath, item.originalImagePath) + item.originalImagePaths)
                    .filter { it.isNotBlank() }
                    .distinct()
                if (images.size <= 1) {
                    ProductImage(
                        item.imagePath,
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color.White)
                            .clickable { if (item.imagePath.isNotBlank()) previewPath = item.imagePath },
                        ContentScale.Crop,
                    )
                } else {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        images.forEachIndexed { index, path ->
                            Box(Modifier.width(318.dp).aspectRatio(1f).clip(RoundedCornerShape(24.dp)).background(Color.White).clickable { previewPath = path }) {
                                ProductImage(path, Modifier.fillMaxSize(), ContentScale.Crop)
                                Text(
                                    if (index == 0) "上架图" else "原图",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.align(Alignment.TopStart).padding(10.dp).clip(CircleShape).background(Color.Black.copy(.45f)).padding(horizontal = 10.dp, vertical = 5.dp),
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                BoRaisedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                            Text(item.name, color = BoInk, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont, lineHeight = 25.sp)
                                Text(item.category.ifBlank { "未分类" }, color = BoSub, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                StatusPill(item.statusLabel.ifBlank { productStatusLabel(item.listingStatus) }, listingStatusColor(item.listingStatus))
                                StatusPill("${item.conditionGrade}级", conditionColor(item.conditionGrade))
                            }
                        }
                        Text("¥%.0f".format(item.priceCents / 100.0), color = BoRed, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(10.dp))
                BoRaisedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("商品字段", color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        DetailField("商品编码 / 条码", item.itemNo)
                        DetailField("商品名称", item.name)
                        DetailField("商品分类", item.category.ifBlank { "未分类" })
                        DetailField("品牌", item.brand.ifBlank { "未识别" })
                        DetailField("年代", item.era.ifBlank { "未识别" })
                        DetailField("IP", item.ipName.ifBlank { "未识别" })
                        DetailField("材质", item.material.ifBlank { "未识别" })
                        DetailField("颜色", item.color.ifBlank { "未识别" })
                        DetailField("成色等级", "${item.conditionGrade} 级")
                        DetailField("商品状态", item.statusLabel.ifBlank { productStatusLabel(item.listingStatus) })
                        DetailField(if (state.productViewScope == ProductViewScope.All) "总库存" else "当前库存", if (item.isUnlimitedStock) "不限" else "${item.stockQty} 件")
                        if (item.erpId.isNotBlank()) DetailField("所属库位", productLocationBadges(item.productStocks).joinToString("、"))
                        DetailField("售价", "¥%.0f".format(item.priceCents / 100.0))
                        if (item.productType == "custom") {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("加入翻筐乐", color = BoInk, modifier = Modifier.weight(1f))
                                Switch(
                                    checked = fankuangEnrollment((item.priceCents / 100.0).toString(), item.fankuangOverride),
                                    onCheckedChange = vm::setSelectedItemFankuang,
                                    enabled = item.canEdit == true && item.updatedAt.isNotBlank() && !state.busy && !state.productDetailLoading,
                                )
                            }
                        }
                        DetailField("创建时间", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(Date(item.createdAt)))
                    }
                }
                Spacer(Modifier.height(10.dp))
                BoRaisedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("商品描述 / 成色说明", color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        Text(item.conditionNote.ifBlank { "暂无描述" }, color = BoSub, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                BoRaisedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("操作", color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        if (!item.editable) {
                            Text("标准商品由 ERP 总部维护，手持端仅查看和打印标签。", color = BoSub, fontSize = 12.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlineButton("直接打印", Modifier.weight(1f), Icons.Default.Print) { vm.printItem(item) }
                            if (item.editable) {
                                RedButton("预览打印", Modifier.weight(1f), Icons.Default.Edit) { vm.openLabelPreviewForItem(item) }
                            }
                        }
                        if (item.editable) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                when (item.listingStatus) {
                                    "selling" -> OutlineButton("转入仓库中", Modifier.weight(1f), Icons.Default.VisibilityOff) {
                                        vm.setSelectedItemDisplay(false)
                                    }
                                    else -> RedButton("设为销售中", Modifier.weight(1f), Icons.Default.Visibility) {
                                        vm.setSelectedItemDisplay(true)
                                    }
                                }
                                if (item.listingStatus == "sold_out" || item.canRestock) {
                                    RedButton("补货入库", Modifier.weight(1f), Icons.Default.Add) {
                                        vm.restockSelectedItem(delta = 1, printLabels = true)
                                    }
                                }
                            }
                        }
                        OutlineButton("继续上架", Modifier.fillMaxWidth(), Icons.Default.CameraAlt) { vm.newListing() }
                        Spacer(Modifier.height(8.dp))
                        Text("同步状态：本地已保存；ERP 建档结果请查看同步中心", color = BoMuted, fontSize = 11.sp)
                    }
                }
                previewPath?.let { ImagePreviewDialog(it) { previewPath = null } }
                Spacer(Modifier.height(18.dp))
            }
        }
    }
}

@Composable
fun GlobalStockScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val data = state.globalStock
    var showTypeOptions by remember { mutableStateOf(false) }
    var showStockOptions by remember { mutableStateOf(false) }
    var showCategoryOptions by remember { mutableStateOf(false) }
    var showStatusOptions by remember { mutableStateOf(false) }
    LaunchedEffect(state.productType, state.loggedIn) {
        if (state.loggedIn) vm.loadGlobalStock()
    }
    Scaffold(containerColor = BoBg) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 28.dp)) {
            DesignTopTitle(
                title = "全局库存",
                back = { vm.navigate(AppScreen.Products) },
                action = "导出",
                onAction = { vm.loadGlobalStock() },
            )
            DesignGlobalStockSummary(
                search = state.search,
                onSearch = vm::updateSearch,
                summary = data.summary,
                matrix = state.globalStockView == "matrix",
                onMatrix = { vm.setGlobalStockView("matrix") },
                onDetail = { vm.setGlobalStockView("detail") },
            )
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DesignFilterPill("${productTypeLabel(state.productType)}⌄") {
                    showTypeOptions = true
                }
                DesignFilterPill(
                    "库存状态：${when (state.globalStockState) { "out" -> "缺货"; "low" -> "低库存"; else -> "全部" }}",
                ) {
                    showStockOptions = true
                }
                DesignFilterPill("商品状态：${productStatusLabel(state.productStatus)}") { showStatusOptions = true }
                DesignFilterPill("分类：${if (state.productCategory.isBlank()) "全部" else categoryLabel(state.productCategory)}") { showCategoryOptions = true }
            }
            if (showTypeOptions) {
                DesignOptionDialog(
                    title = "选择商品类型",
                    options = productTypeOptions,
                    selected = state.productType,
                    onDismiss = { showTypeOptions = false },
                    onSelect = {
                        showTypeOptions = false
                        vm.selectProductType(it)
                        vm.loadGlobalStock()
                    },
                )
            }
            if (showStockOptions) {
                DesignOptionDialog(
                    title = "选择库存状态",
                    options = stockStateOptions,
                    selected = state.globalStockState,
                    onDismiss = { showStockOptions = false },
                    onSelect = {
                        showStockOptions = false
                        vm.setGlobalStockState(it)
                    },
                )
            }
            if (showStatusOptions) {
                DesignOptionDialog(
                    title = "选择商品状态",
                    options = productStatusOptions,
                    selected = state.productStatus,
                    onDismiss = { showStatusOptions = false },
                    onSelect = {
                        showStatusOptions = false
                        vm.selectProductStatus(it)
                        vm.loadGlobalStock()
                    },
                )
            }
            if (showCategoryOptions) {
                DesignOptionDialog(
                    title = "选择商品分类",
                    options = productCategoryOptions,
                    selected = state.productCategory,
                    onDismiss = { showCategoryOptions = false },
                    onSelect = {
                        showCategoryOptions = false
                        vm.selectProductCategory(it)
                        vm.loadGlobalStock()
                    },
                )
            }
            Spacer(Modifier.height(12.dp))
            if (state.globalStockLoading) {
                Text("读取中…", color = BoRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
            }
            if (state.status.startsWith("全局库存读取失败")) {
                StatusBanner(state.status)
                Spacer(Modifier.height(12.dp))
            }
            if (data.items.isEmpty()) {
                DesignEmptyPanel(if (state.globalStockLoading) "正在读取全局库存" else "暂无全局库存", "如果接口未发布，会在这里显示错误提示")
            } else if (state.globalStockView == "matrix") {
                DesignGlobalStockMatrix(data)
            } else {
                GlobalStockDetailList(data)
            }
        }
    }
}

@Composable
private fun GlobalStockMatrix(data: GlobalStockData) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        data.items.forEach { item ->
            BoRaisedCard {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(item.name, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(item.skuCode.ifBlank { item.barcode }, color = BoSub, fontSize = 11.sp, maxLines = 1)
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                MiniBadge(item.statusLabel.ifBlank { productStatusLabel(item.listingStatus) }, listingStatusColor(item.listingStatus))
                                Text("¥%.0f · %s".format(item.priceCents / 100.0, productTypeLabel(item.productType)), color = BoSub, fontSize = 11.sp)
                            }
                        }
                        Box(
                            Modifier
                                .clip(CircleShape)
                                .background(BoNavySoft)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                        ) {
                            Text("合计 ${item.totalQty}", color = BoNavy, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    data.locations.chunked(3).forEach { rowLocations ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowLocations.forEach { location ->
                                val qty = item.stocks[location.id] ?: 0
                                LocationStockCell(
                                    name = location.name,
                                    qty = qty,
                                    unlimited = item.isUnlimitedStock,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            repeat(3 - rowLocations.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LocationStockCell(name: String, qty: Int, unlimited: Boolean, modifier: Modifier) {
    val color = stockQtyColor(qty)
    Column(
        modifier
            .height(58.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(color.copy(.08f))
            .border(1.dp, color.copy(.14f), RoundedCornerShape(15.dp))
            .padding(horizontal = 9.dp, vertical = 7.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(if (unlimited) "不限" else qty.toString(), color = color, fontSize = 18.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(name, color = BoSub, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun GlobalStockDetailList(data: GlobalStockData) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        data.items.forEach { item ->
            BoRaisedCard {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ProductThumb(item.imageUrl, 54)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.name, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, maxLines = 2)
                            Text(item.skuCode.ifBlank { item.barcode }, color = BoSub, fontSize = 11.sp)
                            Spacer(Modifier.height(4.dp))
                            MiniBadge(item.statusLabel.ifBlank { productStatusLabel(item.listingStatus) }, listingStatusColor(item.listingStatus))
                        }
                        Text(if (item.isUnlimitedStock) "不限" else item.totalQty.toString(), color = stockQtyColor(item.totalQty), fontSize = 22.sp, fontWeight = FontWeight.Black)
                    }
                    data.locations.forEach { location ->
                        val qty = item.stocks[location.id] ?: 0
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${location.name} · ${if (location.kind == "warehouse") "仓库" else "门店"}", color = BoSub, fontSize = 12.sp)
                            Text(if (item.isUnlimitedStock) "不限" else qty.toString(), color = stockQtyColor(qty), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StockCell(text: String, width: Int, header: Boolean = false, color: Color = BoInk) {
    Box(
        Modifier
            .width(width.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (header) BoInk else Color.White)
            .border(1.dp, if (header) BoInk else BoLine, RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (header) Color.White else color, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2)
    }
}

@Composable
fun CleanSyncScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { HandheldApiClient(context) }
    var records by remember { mutableStateOf<List<SyncRecord>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun reload() {
        scope.launch {
            loading = true
            message = ""
            runCatching { withContext(Dispatchers.IO) { api.syncRecords(limit = 50) } }
                .onSuccess { records = it }
                .onFailure { message = it.message ?: "同步记录读取失败" }
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload() }

    Scaffold(containerColor = BoBg, bottomBar = { CleanBottomNav(vm, AppScreen.Sync) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
            BoTopBar(onBack = { vm.navigate(AppScreen.Dashboard) }, rightIcon = Icons.Default.Sync)
            Text("同步中心", color = BoInk, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
            Spacer(Modifier.height(14.dp))
            if (message.isNotBlank()) Text(message, color = BoRed, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                MiniMetric("待同步", records.count { it.status == "pending" }.toString(), BoOrange, Modifier.weight(1f))
                MiniMetric("失败", records.count { it.status == "failed" }.toString(), BoRed, Modifier.weight(1f))
                MiniMetric("完成", records.count { it.status == "done" }.toString(), BoGreen, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            if (records.isEmpty()) {
                EmptyCard(
                    if (loading) "正在读取同步任务" else "暂无同步任务",
                    "${state.selectedLocation?.name ?: "当前库位"} 当前没有 ERP 同步队列记录。",
                ) { reload() }
            } else {
                records.forEach { record ->
                    BoRaisedCard(Modifier.padding(bottom = 10.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(record.skuId.ifBlank { record.id }, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                                StatusPill(record.status.ifBlank { "unknown" }, when (record.status) {
                                    "done" -> BoGreen
                                    "failed" -> BoRed
                                    else -> BoOrange
                                })
                            }
                            Text("目标库存 ${record.targetStock} · 尝试 ${record.attempts} 次", color = BoSub, fontSize = 12.sp)
                            if (record.reason.isNotBlank()) Text(record.reason, color = BoSub, fontSize = 12.sp)
                            if (record.lastError.isNotBlank()) Text(record.lastError, color = BoRed, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CleanProfileScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit) { vm.refreshEmployeeProfile() }
    val activeRoles = effectiveRoles(state.roles, state.locations, state.selectedLocation)
    val displayName = state.userName.ifBlank { "已登录" }
    val initial = displayName.firstOrNull()?.toString() ?: "BO"
    Scaffold(containerColor = BoBg, bottomBar = { CleanBottomNav(vm, AppScreen.Profile) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 24.dp)) {
            BoTopBar()
            BoRaisedCard {
                Column(
                    Modifier.fillMaxWidth().padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(Modifier.size(70.dp).clip(CircleShape).background(BoRedSoft), contentAlignment = Alignment.Center) {
                        Text(initial, color = BoRed, fontSize = 30.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
                        if (state.employeeAvatarUrl.isNotBlank()) {
                            AsyncImage(model = state.employeeAvatarUrl, contentDescription = "员工头像",
                                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        displayName,
                        color = BoInk,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = BoFont,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "${roleLabel(activeRoles)} · ${state.selectedLocation?.name ?: "未选择库位"}",
                        color = BoSub,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text("姓名和头像由 PC 端 ERP 统一维护", color = BoSub, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            listOf(
                Triple("门店信息", Icons.Default.Storefront, AppScreen.StoreSettings),
                Triple("设备设置", Icons.Default.Settings, AppScreen.DeviceSettings),
                Triple("打印中心", Icons.Default.Print, AppScreen.PrinterSettings),
                Triple("帮助与反馈", Icons.Default.Help, AppScreen.Help),
            ).forEach { item ->
                BoRaisedCard(Modifier.padding(bottom = 8.dp).clickable { vm.navigate(item.third) }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(BoRedSoft), contentAlignment = Alignment.Center) {
                            Icon(item.second, null, tint = BoRed, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(item.first, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = BoSub)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("BOOMER-OFF Vintage · v${BuildConfig.VERSION_NAME} · SUNMI V3", color = BoMuted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun TransferScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val selectedLocation = state.selectedLocation
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { HandheldApiClient(context) }
    var incoming by remember { mutableStateOf<List<TransferSummary>>(emptyList()) }
    var outgoing by remember { mutableStateOf<List<TransferSummary>>(emptyList()) }
    var detail by remember { mutableStateOf<TransferDetail?>(null) }
    var epcInput by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    fun reload() {
        val location = selectedLocation ?: return
        scope.launch {
            loading = true
            message = ""
            runCatching {
                withContext(Dispatchers.IO) {
                    api.transfers(location.id, role = "incoming") to api.transfers(location.id, role = "outgoing")
                }
            }.onSuccess {
                incoming = it.first
                outgoing = it.second
            }.onFailure {
                message = it.message ?: "调拨单读取失败"
            }
            loading = false
        }
    }

    fun openDetail(item: TransferSummary) {
        scope.launch {
            message = ""
            runCatching { withContext(Dispatchers.IO) { api.transferDetail(item.id) } }
                .onSuccess { detail = it }
                .onFailure { message = it.message ?: "调拨详情读取失败" }
        }
    }

    LaunchedEffect(selectedLocation?.id) { reload() }

    OperationScaffold(vm, "调拨管理", AppScreen.Dashboard) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            MiniMetric("待收", incoming.size.toString(), BoRed, Modifier.weight(1f))
            MiniMetric("待发", outgoing.size.toString(), BoBlue, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        if (message.isNotBlank()) Text(message, color = BoRed, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
        if (selectedLocation == null) {
            EmptyCard("未选择库位", "请选择门店或仓库后再处理调拨") { vm.navigate(AppScreen.StoreSettings) }
        } else if (incoming.isEmpty() && outgoing.isEmpty()) {
            EmptyCard(if (loading) "正在读取调拨单" else "暂无调拨任务", "当前库位没有待收/待发调拨单") { reload() }
        } else {
            TransferListSection("待收货", incoming, BoRed, ::openDetail)
            TransferListSection("待发货", outgoing, BoBlue, ::openDetail)
        }

        detail?.let { current ->
            Spacer(Modifier.height(8.dp))
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(current.summary.code.ifBlank { "调拨详情" }, color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                        StatusPill(current.summary.status.ifBlank { "待处理" }, BoOrange)
                    }
                    Text("明细 ${current.lines.size} 行 · EPC ${current.epcs.size} 个", color = BoSub, fontSize = 12.sp)
                    OutlinedTextField(
                        value = epcInput,
                        onValueChange = { epcInput = it.trim() },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("扫描/输入 EPC") },
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlineButton("扫描", Modifier.weight(1f), Icons.Default.QrCodeScanner) {
                            val code = epcInput.trim()
                            if (code.isBlank()) {
                                message = "请先扫描或输入 EPC"
                            } else {
                                scope.launch {
                                    runCatching { withContext(Dispatchers.IO) { api.transferScan(current.summary, selectedLocation?.id.orEmpty(), listOf(code)) } }
                                        .onSuccess {
                                            message = "已记录 ${it.side.ifBlank { "调拨" }} 扫描，未知 ${it.unknownCount} 个"
                                            epcInput = ""
                                            openDetail(current.summary)
                                            reload()
                                        }
                                        .onFailure { message = it.message ?: "调拨扫描失败" }
                                }
                            }
                        }
                        RedButton("确认", Modifier.weight(1f), Icons.Default.CheckCircle) {
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { api.transferConfirm(current.summary, selectedLocation?.id.orEmpty()) } }
                                    .onSuccess {
                                        message = "调拨已确认：${it.stage.ifBlank { "完成" }}"
                                        detail = null
                                        reload()
                                    }
                                    .onFailure { message = it.message ?: "调拨确认失败" }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TransferListSection(
    title: String,
    items: List<TransferSummary>,
    color: Color,
    onOpen: (TransferSummary) -> Unit,
) {
    if (items.isEmpty()) return
    SectionTitle(title, items.size.toString(), null)
    items.forEach { item ->
        BoRaisedCard(Modifier.padding(bottom = 10.dp).clickable { onOpen(item) }) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.code.ifBlank { item.id.take(8) }, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    StatusPill(item.status.ifBlank { "待处理" }, color)
                }
                Text("数量 ${item.qty} 件", color = BoSub, fontSize = 12.sp)
                if (item.notes.isNotBlank()) Text(item.notes, color = BoSub, fontSize = 12.sp)
                Text(item.createdAt.ifBlank { "点击查看并扫码处理" }, color = BoMuted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun NotificationsScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val selectedLocation = state.selectedLocation
    var category by remember(state.homeMessagesGeneration, selectedLocation?.id) { mutableStateOf<MessageCategory?>(null) }
    var unreadOnly by remember(state.homeMessagesGeneration, selectedLocation?.id) { mutableStateOf(false) }
    val hasReadStatus = state.messages.any { it.isRead != null }
    val notifications = state.messages.filter {
        (category == null || it.category == category) && (!unreadOnly || !hasReadStatus || it.isRead == false)
    }

    LaunchedEffect(state.homeMessagesGeneration, selectedLocation?.id, state.locationSwitching) { vm.loadMessages() }

    Scaffold(containerColor = BoBg, bottomBar = { CleanBottomNav(vm, AppScreen.Notifications) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
            DesignTopTitle("消息中心")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(selectedLocation?.name ?: "未选择库位", color = BoSub, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::loadMessages, enabled = state.loggedIn && selectedLocation != null && !state.locationSwitching && !state.messagesLoading) {
                    Text(if (state.messagesLoading) "刷新中" else "刷新")
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceChip("全部", category == null) { category = null }
                MessageCategory.entries.forEach { item -> ChoiceChip(item.label, category == item) { category = item } }
            }
            if (hasReadStatus) {
                TextButton(onClick = { unreadOnly = !unreadOnly }) { Text(if (unreadOnly) "显示全部已读状态" else "只看未读") }
            }
            Spacer(Modifier.height(12.dp))
            Text("查看列表不会更改已读或处理状态。当前展示事件提醒，回复和业务处理请使用 ERP。", color = BoMuted, fontSize = 12.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(12.dp))
            if (state.messagesError.isNotBlank()) {
                Text(state.messagesError, color = BoRed, fontSize = 13.sp)
                if (state.messages.isNotEmpty()) Text("保留本次库位已加载的消息，刷新后更新", color = BoSub, fontSize = 12.sp)
            }
            when {
                !state.loggedIn -> EmptyCard("请先登录", "登录 ERP 后查看授权库位消息") { vm.navigate(AppScreen.Login) }
                state.locationSwitching -> DesignEmptyPanel("正在切换库位", "原库位消息已清空")
                selectedLocation == null -> EmptyCard("未选择库位", "请选择门店或仓库后查看消息") { vm.navigate(AppScreen.LocationSelect) }
                notifications.isEmpty() && state.messagesLoading -> DesignEmptyPanel("正在读取消息", "正在从 ERP 获取当前库位消息")
                notifications.isEmpty() && state.messagesError.isNotBlank() -> EmptyCard("消息暂时无法读取", "请检查网络后点击重试") { vm.loadMessages() }
                notifications.isEmpty() -> DesignEmptyPanel("暂无${category?.label.orEmpty()}消息", "当前筛选下没有消息，可点击顶部刷新")
                else -> notifications.forEach { item ->
                    BoRaisedCard(Modifier.padding(bottom = 10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(item.title, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                StatusPill(item.category.label, BoBlue)
                                if (item.isRead == false) {
                                    Spacer(Modifier.width(6.dp))
                                    StatusPill("未读", BoRed)
                                }
                            }
                            Text(item.payloadText, color = BoSub, fontSize = 13.sp, lineHeight = 19.sp)
                            val timestamp = messageTimestamp(item.ts)
                            if (timestamp.isNotBlank()) Text(timestamp, color = BoMuted, fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun StoreSettingsScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val activeRoles = effectiveRoles(state.roles, state.locations, state.selectedLocation)
    SettingsScreen(
        vm,
        "门店信息",
        listOf(
            "当前库位" to (state.selectedLocation?.name ?: "未选择"),
            "库位类型" to if (state.selectedLocation?.kind == "warehouse") "仓库" else "门店",
            "员工角色" to roleLabel(activeRoles),
            "库存策略" to "ERP 主数据优先",
        ),
    )
}

@Composable
fun DeviceSettingsScreen(vm: MainViewModel) {
    SettingsScreen(vm, "设备设置", listOf("设备型号" to "SUNMI V3", "摄像头" to "已授权", "本地缓存" to "可用", "后端地址" to BuildConfig.BACKEND_BASE_URL))
}

@Composable
fun PrinterSettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    val snapshot = state.printerSnapshot
    val activeRoles = effectiveRoles(state.roles, state.locations, state.selectedLocation)
    val canManageTemplates = state.labelTemplatesCanManage ?: canManageLabelTemplates(activeRoles)
    var printType by remember {
        mutableStateOf(
            if (snapshot.isLabelMode) PrintTemplateType.LABEL else PrintTemplateType.RECEIPT,
        )
    }
    var selectedTemplate by remember(printType) {
        mutableStateOf(vm.labelTemplate(printType))
    }
    var showDevicePicker by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }
    val bluetoothPermissions = remember {
        if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }
    val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        if (bluetoothPermissions.all { result[it] == true || ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }) {
            vm.scanBluetoothPrinters()
        } else {
            vm.notify("需要允许附近设备/蓝牙权限，才能搜索打印机")
        }
    }
    val scanBluetooth = {
        val granted = bluetoothPermissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (granted) vm.scanBluetoothPrinters() else bluetoothPermissionLauncher.launch(bluetoothPermissions)
    }
    LaunchedEffect(Unit) {
        vm.refreshPrinterStatus()
        vm.refreshLabelTemplates(silent = true)
    }
    LaunchedEffect(printType) {
        vm.setBluetoothPrinterMode(printType == PrintTemplateType.LABEL)
        selectedTemplate = vm.labelTemplate(printType)
    }
    LaunchedEffect(state.labelTemplates, printType) {
        val available = state.labelTemplates.filter { it.printType == printType }
        if (available.none { it.id == selectedTemplate.id }) {
            selectedTemplate = available.firstOrNull() ?: vm.labelTemplate(printType)
        }
    }
    OperationScaffold(vm, "打印中心", AppScreen.Profile) {
        SectionTitle("打印机", null, null)
        BoRaisedCard(Modifier.clickable { showDevicePicker = true }) {
            Row(
                Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(BoNavySoft),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (snapshot.backendType == PrinterBackendType.BLUETOOTH) Icons.Default.Bluetooth else Icons.Default.Print,
                        null,
                        tint = BoNavy,
                    )
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(snapshot.displayName, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                    Text(
                        if (snapshot.connected) {
                            "${if (snapshot.backendType == PrinterBackendType.BLUETOOTH) "蓝牙打印机" else "设备内置打印机"} · 点击切换"
                        } else {
                            "点击选择附近的打印机"
                        },
                        color = BoSub,
                        fontSize = 12.sp,
                    )
                }
                Text(
                    if (snapshot.connected) "已连接" else "待连接",
                    color = if (snapshot.connected) BoGreen else BoOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.background(
                        if (snapshot.connected) BoGreenSoft else BoAmberSoft,
                        RoundedCornerShape(20.dp),
                    ).padding(horizontal = 9.dp, vertical = 6.dp),
                )
                Icon(Icons.Default.ChevronRight, null, tint = BoMuted, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        val statusText = state.status
        val isPrinterSnapshotStatus = statusText.startsWith("打印机状态：")
        if (statusText.isNotBlank() && !isPrinterSnapshotStatus) {
            StatusBanner(state.status)
            Spacer(Modifier.height(14.dp))
        }

        SectionTitle("打印类型", null, null)
        Row(
            Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            PrintModeButton(
                label = "标签",
                selected = printType == PrintTemplateType.LABEL,
                modifier = Modifier.weight(1f),
            ) {
                printType = PrintTemplateType.LABEL
            }
            PrintModeButton(
                label = "小票",
                selected = printType == PrintTemplateType.RECEIPT,
                modifier = Modifier.weight(1f),
            ) {
                printType = PrintTemplateType.RECEIPT
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("纸张", null, null)
        if (printType == PrintTemplateType.RECEIPT) {
            BoRaisedCard {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.ReceiptLong, null, tint = BoNavy)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("58mm 小票纸", color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        Text("固定纸宽，无需选择", color = BoSub, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.CheckCircle, null, tint = BoGreen, modifier = Modifier.size(20.dp))
                }
            }
        } else {
            BoRaisedCard {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.Label, null, tint = BoNavy)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("58mm 标签纸", color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        Text("固定纸宽，无需选择", color = BoSub, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.CheckCircle, null, tint = BoGreen, modifier = Modifier.size(20.dp))
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("打印模板", null, if (canManageTemplates) "新建" else null) {
            if (canManageTemplates) vm.createLabelTemplate(printType)
        }
        if (!canManageTemplates) {
            Text("模板由管理员统一维护，当前账号可选择使用。", color = BoSub, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
        }
        val templateList = state.labelTemplates
            .filter { it.printType == printType }
            .ifEmpty { listOf(vm.labelTemplate(printType)) }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            templateList.forEach { candidate ->
                CompactPrintTemplateRow(
                    template = candidate,
                    selected = selectedTemplate.id == candidate.id,
                    canManage = canManageTemplates,
                    onSelect = { selectedTemplate = candidate },
                    onEdit = {
                        if (canManageTemplates) {
                            vm.editLabelTemplate(candidate)
                        } else {
                            vm.notify("模板由总部统一维护，当前账号没有编辑权限")
                        }
                    },
                    onDefault = {
                        if (canManageTemplates) {
                            selectedTemplate = candidate
                            vm.setDefaultLabelTemplate(candidate)
                        } else {
                            vm.notify("模板由总部统一维护，当前账号不能修改默认模板")
                        }
                    },
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        RedButton(
            if (printType == PrintTemplateType.RECEIPT) "打印测试小票" else "打印测试标签",
            Modifier.fillMaxWidth(),
            Icons.Default.Print,
        ) {
            if (printType == PrintTemplateType.RECEIPT) {
                vm.printReceiptTestLabel(selectedTemplate.normalizedForPrint())
            } else {
                vm.printTestLabel(selectedTemplate)
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clickable { showAdvanced = !showAdvanced }.padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("高级设置", color = BoSub, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Icon(
                if (showAdvanced) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                null,
                tint = BoMuted,
            )
        }
        if (showAdvanced) {
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (printType == PrintTemplateType.LABEL) {
                        StepperRow("左右微调", state.printOffsetXDots, onMinus = { vm.updatePrintOffset(deltaX = -8) }, onPlus = { vm.updatePrintOffset(deltaX = 8) })
                        StepperRow("上下微调", state.printOffsetYDots, onMinus = { vm.updatePrintOffset(deltaY = -8) }, onPlus = { vm.updatePrintOffset(deltaY = 8) })
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlineButton("恢复默认", Modifier.weight(1f), Icons.Default.Refresh) { vm.resetPrintOffset() }
                            OutlineButton("走到下一张", Modifier.weight(1f), Icons.Default.Bolt) { vm.outputLabelToTearLine() }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton("初始化", Modifier.weight(1f), Icons.Default.Refresh) { vm.initializePrinter() }
                        OutlineButton("打印机自检", Modifier.weight(1f), Icons.Default.CheckCircle) { vm.runPrinterSelfCheck() }
                    }
                    if (snapshot.supportsSystemSettings) {
                        OutlineButton("打开设备打印设置", Modifier.fillMaxWidth(), Icons.Default.Settings) {
                            runCatching {
                                context.startActivity(Intent("com.sunmi.printer.settings").addCategory(Intent.CATEGORY_DEFAULT))
                            }.onFailure {
                                vm.notify("无法打开商米打印设置：${it.message}")
                            }
                        }
                    }
                }
            }
        }
    }
    if (showDevicePicker) {
        Dialog(onDismissRequest = { showDevicePicker = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 12.dp,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("选择打印设备", color = BoInk, fontSize = 19.sp, fontWeight = FontWeight.Black)
                            Text("已连接过的蓝牙打印机会自动重连", color = BoSub, fontSize = 12.sp)
                        }
                        IconButton(onClick = { showDevicePicker = false }) {
                            Icon(Icons.Default.Close, null, tint = BoSub)
                        }
                    }
                    if (vm.hasBuiltInPrinter()) {
                        PrinterDeviceChoice(
                            icon = Icons.Default.Print,
                            name = "商米 V3 内置打印机",
                            detail = "设备内置 · 支持标签定位",
                            connected = snapshot.backendType == PrinterBackendType.SUNMI && snapshot.connected,
                            onClick = {
                                vm.useBuiltInPrinter()
                                showDevicePicker = false
                            },
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("附近的蓝牙打印机", color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(
                            if (state.bluetoothPrinterScanning) "搜索中…" else "重新搜索",
                            color = BoRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { scanBluetooth() }.padding(8.dp),
                        )
                    }
                    if (state.bluetoothPrinterDevices.isEmpty()) {
                        Column(
                            Modifier.fillMaxWidth().background(BoSoft, RoundedCornerShape(16.dp)).padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(Icons.Default.Bluetooth, null, tint = BoMuted)
                            Text(
                                if (state.bluetoothPrinterScanning) "正在搜索，请打开打印机蓝牙" else "暂无打印机，先搜索或在系统中完成配对",
                                color = BoSub,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                            )
                        }
                    } else {
                        state.bluetoothPrinterDevices.forEach { device ->
                            PrinterDeviceChoice(
                                icon = Icons.Default.Bluetooth,
                                name = device.name,
                                detail = "${if (device.bonded) "已配对" else "未配对"} · ${device.address}",
                                connected = snapshot.backendType == PrinterBackendType.BLUETOOTH &&
                                    snapshot.connected &&
                                    snapshot.serialNo == device.address,
                                onClick = {
                                    vm.connectBluetoothPrinter(device)
                                    showDevicePicker = false
                                },
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlineButton("系统蓝牙设置", Modifier.weight(1f), Icons.Default.PhoneAndroid) {
                            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                        }
                        if (snapshot.backendType == PrinterBackendType.BLUETOOTH && snapshot.connected) {
                            OutlineButton("断开连接", Modifier.weight(1f), Icons.Default.Close) {
                                vm.disconnectBluetoothPrinter()
                                showDevicePicker = false
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PrintModeButton(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Text(
        label,
        color = if (selected) Color.White else BoInk,
        fontSize = 13.sp,
        fontWeight = FontWeight.Black,
        textAlign = TextAlign.Center,
        modifier = modifier
            .clickable(onClick = onClick)
            .background(if (selected) BoNavy else Color.Transparent, RoundedCornerShape(11.dp))
            .padding(vertical = 10.dp),
    )
}

@Composable
private fun CompactPrintTemplateRow(
    template: LabelTemplate,
    selected: Boolean,
    canManage: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onDefault: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .background(Color.White, RoundedCornerShape(14.dp))
            .padding(horizontal = 13.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            Modifier.size(36.dp).background(if (selected) BoNavySoft else BoSoft, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (template.printType == PrintTemplateType.RECEIPT) Icons.Default.ReceiptLong else Icons.Default.Label,
                null,
                tint = if (selected) BoNavy else BoSub,
                modifier = Modifier.size(19.dp),
            )
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(template.templateName, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Black, maxLines = 1)
            Text(
                if (template.printType == PrintTemplateType.RECEIPT) "58mm 小票" else "${template.widthMm}×${template.heightMm}mm 标签",
                color = BoSub,
                fontSize = 10.sp,
            )
        }
        if (selected) {
            Icon(Icons.Default.CheckCircle, null, tint = BoGreen, modifier = Modifier.size(19.dp))
        }
        if (canManage) {
            Text(
                "编辑",
                color = BoNavy,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable(onClick = onEdit).padding(5.dp),
            )
            Text(
                "设默认",
                color = BoRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable(onClick = onDefault).padding(5.dp),
            )
        }
    }
}

@Composable
private fun PrinterDeviceChoice(
    icon: ImageVector,
    name: String,
    detail: String,
    connected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).background(BoSoft, RoundedCornerShape(16.dp)).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(11.dp),
    ) {
        Box(Modifier.size(40.dp).background(Color.White, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = BoNavy, modifier = Modifier.size(21.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(name, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(detail, color = BoSub, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (connected) {
            Icon(Icons.Default.CheckCircle, null, tint = BoGreen, modifier = Modifier.size(20.dp))
        } else {
            Icon(Icons.Default.ChevronRight, null, tint = BoMuted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun PrinterOptionChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) Color.White else BoInk,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .clickable(onClick = onClick)
            .background(if (selected) BoNavy else BoSoft, RoundedCornerShape(10.dp))
            .padding(horizontal = 11.dp, vertical = 9.dp),
    )
}

@Composable
fun HelpScreen(vm: MainViewModel) {
    OperationScaffold(vm, "帮助与反馈", AppScreen.Profile) {
        HelpCard("AI 上架流程", "拍照 → AI识别 → 修改确认 → 打印标签 → 保存商品。")
        HelpCard("普通商品快速入库", "选择 SKU 后连续感应 RFID，重复标签会被跳过。")
        HelpCard("RFID 关联", "方案A下先扫热敏标签二维码，再感应空白 RFID 芯片。")
        HelpCard("当前版本", "已接入 ERP 登录、库位权限、工作台和 AI 上架链路。")
    }
}

@Composable
private fun SettingsScreen(vm: MainViewModel, title: String, rows: List<Pair<String, String>>) {
    OperationScaffold(vm, title, AppScreen.Profile) {
        rows.forEach { (label, value) ->
            BoRaisedCard(Modifier.padding(bottom = 8.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = BoSub, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(value, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        RedButton("保存设置", Modifier.fillMaxWidth(), Icons.Default.Save) {
            vm.notify("$title 已保存", AppScreen.Profile)
        }
    }
}

@Composable
fun QuickStockScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val appState by vm.state.collectAsState()
    val stockStore = remember { RfidStockStore(context) }
    val handheld = remember { HandheldApiClient(context) }
    val session = remember { HandheldSessionStore(context) }
    val scope = rememberCoroutineScope()
    var locations by remember { mutableStateOf(appState.locations) }
    var selectedLocation by remember { mutableStateOf(appState.selectedLocation ?: session.selectedLocation() ?: HandheldLocation("", "未选择库位", "shop")) }
    var erpOnline by remember { mutableStateOf(handheld.authHeadersReady() && selectedLocation.id.isNotBlank()) }
    val records = remember { mutableStateListOf<StockScanLog>() }
    var uniqueCount by remember { mutableIntStateOf(0) }
    var lastScan by remember { mutableStateOf("等待扫描") }
    var lastScanColor by remember { mutableStateOf(BoMuted) }
    var pendingTransfer by remember { mutableStateOf<PendingTransfer?>(null) }
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 80) }
    LaunchedEffect(appState.locations, appState.selectedLocation) {
        locations = appState.locations
        appState.selectedLocation?.let {
            selectedLocation = it
            session.saveSelectedLocation(it)
        }
        erpOnline = handheld.authHeadersReady() && selectedLocation.id.isNotBlank()
    }

    fun handleRfidReadLocal(code: String, source: String = "本地") {
        if (records.any { it.code.equals(code, ignoreCase = true) }) {
            records.add(0, StockScanLog(code, selectedLocation.name, "本次重复，已跳过", BoOrange, ScanAction.None))
            lastScan = "本次已扫过，跳过：$code"
            lastScanColor = BoOrange
            return
        }
        val existing = stockStore.find(code)
        when {
            existing == null -> {
                stockStore.upsert(code, selectedLocation.name)
                uniqueCount += 1
                records.add(0, StockScanLog(code, selectedLocation.name, "$source 新入库", BoGreen, ScanAction.Inserted(previousLocation = null)))
                lastScan = "滴，新标签入库：$code"
                lastScanColor = BoGreen
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            }

            existing.location == selectedLocation.name -> {
                records.add(0, StockScanLog(code, selectedLocation.name, "已在当前库，跳过", BoOrange, ScanAction.None))
                lastScan = "已在 ${selectedLocation.name}，跳过：$code"
                lastScanColor = BoOrange
            }

            else -> {
                pendingTransfer = PendingTransfer(code, existing.location, selectedLocation.name, selectedLocation.id)
                records.add(0, StockScanLog(code, existing.location, "已在${existing.location}，待确认转移", BoRed, ScanAction.None))
                lastScan = "该标签已在${existing.location}，请确认是否转移"
                lastScanColor = BoRed
            }
        }
    }

    fun handleRfidRead(code: String) {
        if (selectedLocation.id.isBlank()) {
            lastScan = "请先选择有权限的门店/仓库"
            lastScanColor = BoRed
            return
        }
        if (records.any { it.code.equals(code, ignoreCase = true) }) {
            records.add(0, StockScanLog(code, selectedLocation.name, "本次重复，已跳过", BoOrange, ScanAction.None))
            lastScan = "本次已扫过，跳过：$code"
            lastScanColor = BoOrange
            return
        }
        if (!erpOnline || !handheld.authHeadersReady()) {
            lastScan = "ERP 未连接，已停止入库。请重新登录或检查网络"
            lastScanColor = BoRed
            return
        }
        lastScan = "正在向 ERP 核验：$code"
        lastScanColor = BoMuted
        scope.launch(Dispatchers.IO) {
            runCatching {
                val lookup = handheld.rfidLookup(code)
                if (lookup.known && lookup.currentLocationId == selectedLocation.id) {
                    "CURRENT" to lookup
                } else if (lookup.known && !lookup.currentLocationId.isNullOrBlank()) {
                    "TRANSFER" to lookup
                } else {
                    handheld.rfidStockIn(code)
                    "INSERTED" to lookup
                }
            }.onSuccess { (kind, lookup) ->
                withContext(Dispatchers.Main) {
                    when (kind) {
                        "CURRENT" -> {
                            stockStore.upsert(code, selectedLocation.name)
                            records.add(0, StockScanLog(code, selectedLocation.name, "ERP已在当前库，跳过", BoOrange, ScanAction.None))
                            lastScan = "ERP确认已在 ${selectedLocation.name}：$code"
                            lastScanColor = BoOrange
                        }
                        "TRANSFER" -> {
                            val from = lookup.currentLocationName ?: lookup.currentLocationId ?: "其他库位"
                            pendingTransfer = PendingTransfer(code, from, selectedLocation.name, selectedLocation.id)
                            records.add(0, StockScanLog(code, from, "ERP已在$from，待确认转移", BoRed, ScanAction.None))
                            lastScan = "ERP发现已在 $from，请确认是否转移"
                            lastScanColor = BoRed
                        }
                        else -> {
                            stockStore.upsert(code, selectedLocation.name)
                            uniqueCount += 1
                            records.add(0, StockScanLog(code, selectedLocation.name, "ERP待认领入库", BoGreen, ScanAction.Inserted(previousLocation = null)))
                            lastScan = "滴，ERP已入待认领队列：$code"
                            lastScanColor = BoGreen
                            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                        }
                    }
                }
            }.onFailure { error ->
                withContext(Dispatchers.Main) {
                    lastScan = "ERP入库失败：${error.message ?: "请检查登录/token"}"
                    lastScanColor = BoRed
                    vm.notify(lastScan)
                }
            }
        }
    }
    fun undoLast() {
        val last = records.firstOrNull() ?: run {
            lastScan = "没有可撤销记录"
            lastScanColor = BoMuted
            return
        }
        when (val action = last.action) {
            is ScanAction.Inserted -> {
                if (action.previousLocation == null) stockStore.remove(last.code) else stockStore.upsert(last.code, action.previousLocation)
                uniqueCount = (uniqueCount - 1).coerceAtLeast(0)
                lastScan = "已撤销：${last.code}"
                lastScanColor = BoMuted
            }
            ScanAction.None -> {
                lastScan = "上一条没有改变库存，无需撤销"
                lastScanColor = BoMuted
            }
        }
        records.removeAt(0)
    }
    OperationScaffold(vm, "快速入库", AppScreen.Dashboard) {
        BoRaisedCard {
            Column(Modifier.padding(14.dp)) {
                Text("选择入库门店 / 仓库", color = BoSub, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    locations.forEach {
                        ChoiceChip(it.name, selectedLocation.id == it.id) {
                            selectedLocation = it
                            session.saveSelectedLocation(it)
                            lastScan = "已选择：${selectedLocation.name}"
                            lastScanColor = BoMuted
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(if (erpOnline) "ERP库位已连接" else "ERP未连接，禁止本地入库", color = if (erpOnline) BoGreen else BoRed, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        BoRaisedCard {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(164.dp).clip(CircleShape).background(BoRedSoft), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$uniqueCount", color = BoRed, fontSize = 58.sp, fontWeight = FontWeight.Black)
                        Text("件已入库", color = BoSub, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("当前入库位置：${selectedLocation.name}", color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                Text("每个 RFID 编码只处理一次；重复扫描会自动跳过", color = BoSub, fontSize = 12.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text(lastScan, color = lastScanColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            }
        }
        if (pendingTransfer != null) {
            val transfer = pendingTransfer!!
            Spacer(Modifier.height(12.dp))
            BoRaisedCard {
                Column(Modifier.padding(14.dp)) {
                    Text("发现已入库标签", color = BoRed, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    Text("${transfer.code} 当前在 ${transfer.from}，是否转移到 ${transfer.to}？", color = BoInk, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton("取消", Modifier.weight(1f), Icons.Default.Close) {
                            pendingTransfer = null
                            lastScan = "已取消转移"
                            lastScanColor = BoMuted
                        }
                        RedButton("确认转移", Modifier.weight(1f), Icons.Default.CheckCircle) {
                            scope.launch(Dispatchers.IO) {
                                val synced = runCatching {
                                    erpOnline && handheld.rfidTransfer(transfer.code, transfer.toLocationId)
                                }.getOrDefault(false)
                                withContext(Dispatchers.Main) {
                                    if (synced) {
                                        stockStore.upsert(transfer.code, transfer.to)
                                        uniqueCount += 1
                                        records.add(0, StockScanLog(transfer.code, transfer.to, "ERP已从${transfer.from}转移", BoBlue, ScanAction.Inserted(previousLocation = transfer.from)))
                                        pendingTransfer = null
                                        lastScan = "滴，已转移到 ${transfer.to}"
                                        lastScanColor = BoBlue
                                        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                                    } else {
                                        lastScan = "ERP转移失败，未修改库存"
                                        lastScanColor = BoRed
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlineButton("等待RFID扫描", Modifier.weight(1f), Icons.Default.QrCodeScanner) {
                vm.notify("请使用 RFID 手持硬件触发真实扫描；APP 不再生成模拟编码")
            }
            OutlineButton("撤销", Modifier.weight(1f), Icons.Default.Refresh) { undoLast() }
        }
        Spacer(Modifier.height(10.dp))
        OutlineButton("清空本次记录", Modifier.fillMaxWidth(), Icons.Default.Delete) {
            records.clear()
            uniqueCount = 0
            pendingTransfer = null
            lastScan = "已清空本次扫描记录，不影响已提交的历史库存"
            lastScanColor = BoMuted
        }
        Spacer(Modifier.height(12.dp))
        BoRaisedCard {
            Column(Modifier.padding(14.dp)) {
                Text("扫描流水", color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(8.dp))
                if (records.isEmpty()) {
                    Text("暂无记录", color = BoMuted, fontSize = 13.sp)
                } else {
                    records.take(10).forEach { ScanLine(it.code, "${it.status} · ${it.location}", it.color) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        RedButton("完成入库 $uniqueCount 件", Modifier.fillMaxWidth(), Icons.Default.Save) {
            vm.notify("${selectedLocation.name} 已处理 $uniqueCount 个唯一 RFID", AppScreen.Dashboard)
        }
    }
}

private data class PendingTransfer(val code: String, val from: String, val to: String, val toLocationId: String)

private data class StockScanLog(
    val code: String,
    val location: String,
    val status: String,
    val color: Color,
    val action: ScanAction,
)

private sealed interface ScanAction {
    data object None : ScanAction
    data class Inserted(val previousLocation: String?) : ScanAction
}

@Composable
fun InventoryScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val selectedLocation = state.selectedLocation
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { HandheldApiClient(context) }
    var stocktakes by remember { mutableStateOf<List<StocktakeSummaryItem>>(emptyList()) }
    var selectedStocktake by remember { mutableStateOf<StocktakeSummaryItem?>(null) }
    var epcInput by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    fun reload() {
        val location = selectedLocation ?: return
        scope.launch {
            loading = true
            message = ""
            runCatching { withContext(Dispatchers.IO) { api.stocktakes(location.id) } }
                .onSuccess { items ->
                    stocktakes = items
                    selectedStocktake = selectedStocktake?.let { current -> items.firstOrNull { it.id == current.id } } ?: items.firstOrNull()
                }
                .onFailure { message = it.message ?: "盘点单读取失败" }
            loading = false
        }
    }

    LaunchedEffect(selectedLocation?.id) { reload() }

    OperationScaffold(vm, "门店盘点", AppScreen.Dashboard) {
        if (message.isNotBlank()) Text(message, color = BoRed, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
        if (selectedLocation == null) {
            EmptyCard("未选择库位", "请选择门店或仓库后再盘点") { vm.navigate(AppScreen.StoreSettings) }
            return@OperationScaffold
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            MiniMetric("盘点单", stocktakes.size.toString(), BoBlue, Modifier.weight(1f))
            MiniMetric("进行中", stocktakes.count { it.status == "open" || it.status == "scanning" }.toString(), BoOrange, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        if (stocktakes.isEmpty()) {
            EmptyCard(if (loading) "正在读取盘点单" else "暂无盘点任务", "${selectedLocation.name} 当前没有盘点单") {
                scope.launch {
                    runCatching { withContext(Dispatchers.IO) { api.stocktakeOpen() } }
                        .onSuccess {
                            selectedStocktake = it
                            reload()
                        }
                        .onFailure { message = it.message ?: "新建盘点单失败" }
                }
            }
        } else {
            stocktakes.forEach { item ->
                BoRaisedCard(Modifier.padding(bottom = 8.dp).clickable { selectedStocktake = item }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.code.ifBlank { item.id.take(8) }, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            Text(item.openedAt.ifBlank { item.notes.ifBlank { "点击选择此盘点单" } }, color = BoSub, fontSize = 12.sp)
                        }
                        StatusPill(item.status.ifBlank { "open" }, if (item.status == "submitted") BoGreen else BoOrange)
                    }
                }
            }
        }
        selectedStocktake?.let { current ->
            Spacer(Modifier.height(8.dp))
            BoRaisedCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("当前盘点：${current.code.ifBlank { current.id.take(8) }}", color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    OutlinedTextField(
                        value = epcInput,
                        onValueChange = { epcInput = it.trim() },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("扫描/输入 EPC") },
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlineButton("记录扫描", Modifier.weight(1f), Icons.Default.QrCodeScanner) {
                            val code = epcInput.trim()
                            if (code.isBlank()) {
                                message = "请先扫描或输入 EPC"
                            } else {
                                scope.launch {
                                    runCatching { withContext(Dispatchers.IO) { api.stocktakeScan(current.id, listOf(code)) } }
                                        .onSuccess {
                                            message = "已记录 $it 个唯一 EPC"
                                            epcInput = ""
                                        }
                                        .onFailure { message = it.message ?: "盘点扫描失败" }
                                }
                            }
                        }
                        RedButton("提交盘点", Modifier.weight(1f), Icons.Default.CheckCircle) {
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { api.stocktakeSubmit(current.id) } }
                                    .onSuccess {
                                        message = "盘点已提交 ERP"
                                        reload()
                                    }
                                    .onFailure { message = it.message ?: "盘点提交失败" }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RfidBindScreen(vm: MainViewModel) {
    val state by vm.state.collectAsState()
    val selectedLocation = state.selectedLocation
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { HandheldApiClient(context) }
    var skuId by remember { mutableStateOf("") }
    var epc by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    OperationScaffold(vm, "RFID 关联", AppScreen.Dashboard) {
        Text("把商品 SKU 与 RFID EPC 绑定到 ${selectedLocation?.name ?: "当前库位"}。后续接入硬件 SDK 后，这两个输入会由扫码/RFID 扳机自动填入。", color = BoSub, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(12.dp))
        BoRaisedCard {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = skuId,
                    onValueChange = { skuId = it.trim() },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("SKU ID") },
                    placeholder = { Text("扫描商品二维码或粘贴 sku_id") },
                )
                OutlinedTextField(
                    value = epc,
                    onValueChange = { epc = it.trim() },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("RFID EPC") },
                    placeholder = { Text("感应 RFID 芯片后填入") },
                )
                if (message.isNotBlank()) Text(message, color = if (message.contains("成功")) BoGreen else BoRed, fontSize = 12.sp)
                RedButton("确认绑定并入库", Modifier.fillMaxWidth(), Icons.Default.Link) {
                    if (skuId.isBlank() || epc.isBlank()) {
                        message = "请先填写 SKU ID 和 EPC"
                    } else {
                        scope.launch {
                            runCatching {
                                withContext(Dispatchers.IO) { api.bindRfid(skuId, epc, selectedLocation?.id) }
                            }.onSuccess {
                                message = "绑定成功：库存 ${it.stockAfter}"
                                skuId = ""
                                epc = ""
                                vm.loadDashboard()
                            }.onFailure {
                                message = it.message ?: "RFID 绑定失败"
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
internal fun CleanBottomNav(vm: MainViewModel, active: AppScreen) {
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp), ambientColor = Color.Black.copy(.06f), spotColor = Color.Black.copy(.06f))
            .background(Color.White)
            .padding(horizontal = 10.dp, vertical = 5.dp)
            .navigationBarsPadding(),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NavItem(Icons.Default.Home, "首页", active == AppScreen.Dashboard) { vm.navigate(AppScreen.Dashboard) }
        SecondTabNav(vm, active)
        Box(
            Modifier
                .size(52.dp)
                .shadow(5.dp, CircleShape, ambientColor = BoRed.copy(.14f), spotColor = BoRed.copy(.18f))
                .clip(CircleShape)
                .background(BoRed)
                .clickable { vm.newListing() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.CameraAlt, null, tint = Color.White, modifier = Modifier.size(25.dp))
        }
        NavItem(Icons.Default.Notifications, "消息", active == AppScreen.Notifications) { vm.navigate(AppScreen.Notifications) }
        NavItem(Icons.Default.Person, "我的", active == AppScreen.Profile) { vm.navigate(AppScreen.Profile) }
    }
}

@Composable
private fun SecondTabNav(vm: MainViewModel, active: AppScreen) {
    val state by vm.state.collectAsState()
    val tab = state.secondTab
    val context = LocalContext.current
    val accessibility = remember(context) { context.getSystemService(AccessibilityManager::class.java) }
    var touchExploration by remember(accessibility) { mutableStateOf(accessibility.isTouchExplorationEnabled) }
    DisposableEffect(accessibility) {
        val listener = AccessibilityManager.TouchExplorationStateChangeListener { touchExploration = it }
        accessibility.addTouchExplorationStateChangeListener(listener)
        onDispose { accessibility.removeTouchExplorationStateChangeListener(listener) }
    }
    val reducedMotion = !ValueAnimator.areAnimatorsEnabled()
    val start = tab.flipStartedAt
    val progress = remember(start) {
        Animatable(if (start == null) 1f else ((SystemClock.uptimeMillis() - start) / 260f).coerceIn(0f, 1f))
    }
    LaunchedEffect(start) {
        if (progress.value < 1f) progress.animateTo(1f, tween(((1f - progress.value) * 260).toInt()))
    }
    val face = if (progress.value < .5f) tab.previousMode else tab.mode
    val targetLabel = if (tab.mode == SecondTabMode.Products) "商品" else "订单"
    val otherLabel = if (tab.mode == SecondTabMode.Products) "订单" else "商品"
    NavItem(
        if (face == SecondTabMode.Products) Icons.Default.Inventory2 else Icons.Default.ReceiptLong,
        if (face == SecondTabMode.Products) "商品" else "订单",
        active == AppScreen.Products || active == AppScreen.Orders,
        modifier = Modifier.heightIn(min = 44.dp).semantics {
            stateDescription = "当前为${targetLabel}模式"
            customActions = listOf(CustomAccessibilityAction("切换到$otherLabel") {
                vm.navigate(if (tab.mode == SecondTabMode.Products) AppScreen.Orders else AppScreen.Products)
                true
            })
        },
        contentModifier = Modifier.graphicsLayer {
            // Swap faces edge-on; neither text nor icon is ever mirrored.
            rotationY = if (reducedMotion) 0f else if (progress.value < .5f) progress.value * 180f else (progress.value - 1f) * 180f
            alpha = if (reducedMotion) kotlin.math.abs(progress.value * 2f - 1f) else 1f
            cameraDistance = 12f * density
        },
    ) { vm.tapSecondTab(allowDoubleTap = !touchExploration) }
}

@Composable
private fun OperationScaffold(
    vm: MainViewModel,
    title: String,
    backTo: AppScreen,
    content: @Composable ColumnScope.() -> Unit,
) {
    Scaffold(containerColor = BoBg) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
        ) {
            BoTopBar(onBack = { vm.navigate(backTo) })
            Text(title, color = BoInk, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = BoFont)
            val state by vm.state.collectAsState()
            if (state.status.isNotBlank() && state.status != "请先拍照") {
                Spacer(Modifier.height(8.dp))
                StatusBanner(state.status)
            }
            Spacer(Modifier.height(14.dp))
            content()
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun StatusBanner(text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(BoNavySoft)
            .border(1.dp, BoBlue.copy(.10f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Default.CheckCircle, null, tint = BoNavy, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = BoNavy, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RedButton(text: String, modifier: Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(54.dp).shadow(3.dp, RoundedCornerShape(16.dp), ambientColor = BoRed.copy(.08f), spotColor = BoRed.copy(.12f)),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = BoRed, contentColor = Color.White),
    ) {
        if (icon != null) {
            Icon(icon, null, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(7.dp))
        }
        Text(text, fontWeight = FontWeight.Bold, fontFamily = BoFont)
    }
}

@Composable
private fun OutlineButton(text: String, modifier: Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BoLine),
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = BoInk),
    ) {
        if (icon != null) {
            Icon(icon, null, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(7.dp))
        }
        Text(text, fontWeight = FontWeight.Bold, fontFamily = BoFont)
    }
}

@Composable
private fun ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) BoNavy else Color.White)
            .border(1.dp, if (selected) BoNavy else BoLine, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
    ) {
        Text(text, color = if (selected) Color.White else BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ScanLine(code: String, status: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.CheckCircle, null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(code, color = BoInk, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(status, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProgressBar(progress: Float, color: Color) {
    Box(Modifier.fillMaxWidth().height(9.dp).clip(CircleShape).background(BoSoft)) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .height(9.dp)
                .clip(CircleShape)
                .background(color),
        )
    }
}

@Composable
private fun StepPanel(icon: ImageVector, title: String, desc: String, action: @Composable ColumnScope.() -> Unit) {
    BoRaisedCard {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(82.dp).clip(CircleShape).background(BoRedSoft), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = BoRed, modifier = Modifier.size(38.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(title, color = BoInk, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(desc, color = BoSub, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(18.dp))
            action()
        }
    }
}

@Composable
private fun MiniMetric(label: String, value: String, color: Color, modifier: Modifier) {
    BoRaisedCard(modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = color, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text(label, color = BoSub, fontSize = 11.sp)
        }
    }
}

@Composable
private fun StatusPill(text: String, color: Color) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(color.copy(.10f))
            .border(1.dp, color.copy(.16f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HelpCard(title: String, desc: String) {
    BoRaisedCard(Modifier.padding(bottom = 9.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text(desc, color = BoSub, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, active: Boolean, modifier: Modifier = Modifier, contentModifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .width(58.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = if (active) BoRed else BoSub, modifier = contentModifier.size(20.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, modifier = contentModifier, color = if (active) BoRed else BoSub, fontSize = 9.sp, fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold)
    }
}

@Composable
private fun BoRaisedCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(BoCard),
        border = BorderStroke(1.dp, Color(0x0A111827)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp, pressedElevation = 1.dp),
        content = { content() },
    )
}

@Composable
private fun ProductThumb(path: String, size: Int) {
    ProductImage(path, Modifier.size(size.dp).clip(RoundedCornerShape(16.dp)).background(BoSoft), ContentScale.Crop)
}

@Composable
private fun ProductImage(path: String, modifier: Modifier, scale: ContentScale) {
    if (path.startsWith("http://") || path.startsWith("https://")) {
        AsyncImage(
            model = path,
            contentDescription = null,
            modifier = modifier,
            contentScale = scale,
        )
        return
    }
    val bitmap = remember(path) {
        if (path.isBlank()) null else runCatching { decodeSampledBitmap(path) }.getOrNull()
    }
    if (bitmap != null) {
        Image(bitmap.asImageBitmap(), null, modifier = modifier, contentScale = scale)
    } else {
        Box(modifier, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.CameraAlt, null, tint = BoMuted, modifier = Modifier.size(30.dp))
        }
    }
}

private fun decodeSampledBitmap(path: String, maxSide: Int = 1400): android.graphics.Bitmap? {
    if (path.startsWith("http://") || path.startsWith("https://")) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) {
        sample *= 2
    }
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
    }
    return BitmapFactory.decodeFile(path, options)
}

@Composable
private fun ImagePreviewDialog(path: String, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White)
                .padding(10.dp),
            contentAlignment = Alignment.Center,
        ) {
            ProductImage(
                path,
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                ContentScale.Fit,
            )
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(.48f))
                    .clickable(onClick = onDismiss),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun DetailField(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = BoSub, fontSize = 12.sp, modifier = Modifier.width(92.dp))
        Text(value.ifBlank { "-" }, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
    }
}

private fun conditionColor(grade: String): Color =
    when (grade.uppercase(Locale.ROOT)) {
        "N", "S" -> BoGreen
        "A" -> BoRed
        "B" -> BoBlue
        "C" -> BoOrange
        else -> BoSub
    }

@Composable
private fun FieldLabel(text: String) {
    Text(text, color = BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun SmallChip(text: String) {
    Box(Modifier.clip(CircleShape).background(Color.White).border(1.dp, BoLine, CircleShape).padding(horizontal = 13.dp, vertical = 7.dp)) {
        Text(text, color = BoSub, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GradeChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    Box(
        modifier
            .height(32.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(if (selected) BoRed else Color.White)
            .border(1.dp, if (selected) BoRed else BoLine, RoundedCornerShape(9.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Color.White else BoInk, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun TemplateCard(title: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .width(78.dp)
            .height(92.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(Color.White)
            .border(1.5.dp, if (selected) BoRed else BoLine, RoundedCornerShape(13.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.width(42.dp).height(28.dp).border(2.dp, BoSub.copy(.45f), RoundedCornerShape(2.dp)))
            Spacer(Modifier.height(10.dp))
            Text(title, color = if (selected) BoRed else BoInk, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun StepperRow(label: String, value: Int, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(32.dp).clip(RoundedCornerShape(9.dp)).border(1.dp, BoLine, RoundedCornerShape(9.dp)).clickable(onClick = onMinus), contentAlignment = Alignment.Center) {
                Text("−", color = BoInk, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Text("$value", color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 14.dp))
            Box(Modifier.size(32.dp).clip(RoundedCornerShape(9.dp)).border(1.dp, BoLine, RoundedCornerShape(9.dp)).clickable(onClick = onPlus), contentAlignment = Alignment.Center) {
                Text("+", color = BoInk, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ToggleValueRow(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, BoLine, RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)) {
            Text("$value  ˅", color = BoInk, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SettingRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, BoLine, RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 7.dp)) {
            Text(value, color = BoInk, fontSize = 13.sp)
        }
    }
}

@Composable
private fun PrinterInfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = BoSub, fontSize = 12.sp)
        Text(value.ifBlank { "-" }, color = BoInk, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun PrinterCapability(title: String, description: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(Modifier.padding(top = 3.dp).size(8.dp).clip(CircleShape).background(BoRed))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Black)
            Text(description, color = BoSub, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun SwipeTemplateCard(
    template: LabelTemplate,
    thumbnail: android.graphics.Bitmap,
    canDelete: Boolean,
    onEdit: () -> Unit,
    onDefault: () -> Unit,
    onDelete: () -> Unit,
) {
    var offsetX by remember(template.id) { mutableStateOf(0f) }
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))) {
        if (canDelete) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(BoRed),
                contentAlignment = Alignment.CenterEnd,
            ) {
                Text(
                    "删除",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .padding(end = 22.dp)
                        .clickable(onClick = onDelete),
                )
            }
        }
        BoRaisedCard(
            Modifier
                .offset(x = offsetX.dp)
                .pointerInput(template.id, canDelete) {
                    detectDragGestures(
                        onDragEnd = { offsetX = if (offsetX < -42f && canDelete) -76f else 0f },
                        onDragCancel = { offsetX = 0f },
                    ) { change, dragAmount ->
                        change.consume()
                        if (canDelete) offsetX = (offsetX + dragAmount.x / density).coerceIn(-88f, 0f)
                    }
                },
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.width(128.dp).aspectRatio(424f / 280f),
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, BoLine),
                ) {
                    Image(thumbnail.asImageBitmap(), null, modifier = Modifier.padding(6.dp), contentScale = ContentScale.Fit)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(template.templateName, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                    Text("${template.widthMm}×${template.heightMm}mm · ${template.elements.count { it.enabled }} 个元素", color = BoSub, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("编辑", color = BoRed, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable(onClick = onEdit))
                        Text("设为默认", color = BoInk, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.clickable(onClick = onDefault))
                    }
                }
            }
        }
    }
}

private fun LabelTemplate.updateElement(id: String, transform: (LabelElement) -> LabelElement): LabelTemplate =
    copy(elements = elements.map { element -> if (element.id == id) transform(element) else element })

private fun moveElement(element: LabelElement, deltaX: Float, deltaY: Float): LabelElement =
    element.copy(
        x = (element.x + deltaX).coerceIn(0f, LabelRenderer.WIDTH_DOTS - element.width),
        y = (element.y + deltaY).coerceIn(0f, LabelRenderer.HEIGHT_DOTS - element.height),
    )

@Composable
private fun SelectedElementQuickAdjust(selected: LabelElement?, onUpdate: ((LabelElement) -> LabelElement) -> Unit) {
    BoRaisedCard {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("选中元素调整", color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    Text(selected?.type?.title ?: "先点选标签上的元素", color = BoSub, fontSize = 11.sp)
                }
                selected?.let { StatusPill("${it.x.roundToInt()}, ${it.y.roundToInt()}", BoInk) }
            }
            if (selected == null) return@Column

            StepperRow("宽度", selected.width.roundToInt(), onMinus = {
                onUpdate {
                    val minWidth = if (it.type == LabelElementType.BARCODE) 120f else 24f
                    it.copy(width = (it.width - 4f).coerceAtLeast(minWidth))
                }
            }, onPlus = {
                onUpdate { it.copy(width = (it.width + 4f).coerceAtMost(LabelRenderer.WIDTH_DOTS - it.x)) }
            })
            StepperRow("高度", selected.height.roundToInt(), onMinus = {
                onUpdate { it.copy(height = (it.height - 4f).coerceAtLeast(12f)) }
            }, onPlus = {
                onUpdate { it.copy(height = (it.height + 4f).coerceAtMost(LabelRenderer.HEIGHT_DOTS - it.y)) }
            })
            if (selected.type !in setOf(LabelElementType.LOGO, LabelElementType.IMAGE, LabelElementType.BARCODE, LabelElementType.QR_CODE)) {
                StepperRow("字号", selected.textSize.roundToInt(), onMinus = {
                    onUpdate { it.copy(textSize = (it.textSize - 1f).coerceAtLeast(8f)) }
                }, onPlus = {
                    onUpdate { it.copy(textSize = (it.textSize + 1f).coerceAtMost(48f)) }
                })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceChip("黑体", selected.fontFamily == FONT_SANS) { onUpdate { it.copy(fontFamily = FONT_SANS) } }
                    ChoiceChip("宋体", selected.fontFamily == FONT_SERIF) { onUpdate { it.copy(fontFamily = FONT_SERIF) } }
                    ChoiceChip("等宽", selected.fontFamily == FONT_MONO) { onUpdate { it.copy(fontFamily = FONT_MONO) } }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlineButton(if (selected.bold) "取消加粗" else "加粗", Modifier.weight(1f), null) { onUpdate { it.copy(bold = !it.bold) } }
                    OutlineButton(if (selected.italic) "取消倾斜" else "倾斜", Modifier.weight(1f), null) { onUpdate { it.copy(italic = !it.italic) } }
                    OutlineButton(if (selected.boxed) "取消线框" else "线框", Modifier.weight(1f), null) { onUpdate { it.copy(boxed = !it.boxed) } }
                }
            }
        }
    }
}

@Composable
private fun ElementNudgePad(enabled: Boolean, onMove: (Float, Float) -> Unit) {
    BoRaisedCard {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text("位置微调", color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Black)
                Text(if (enabled) "每次移动 1 dot，用来做最后对齐" else "先点选一个元素", color = BoSub, fontSize = 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                NudgeButton("←", enabled) { onMove(-1f, 0f) }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    NudgeButton("↑", enabled) { onMove(0f, -1f) }
                    NudgeButton("↓", enabled) { onMove(0f, 1f) }
                }
                NudgeButton("→", enabled) { onMove(1f, 0f) }
            }
        }
    }
}

@Composable
private fun NudgeButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(if (enabled) BoRedSoft else Color(0xFFF3F3F3))
            .border(1.dp, if (enabled) BoRed.copy(.35f) else BoLine, RoundedCornerShape(11.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (enabled) BoRed else BoMuted, fontSize = 18.sp, fontWeight = FontWeight.Black)
    }
}

private fun scaleElementContent(element: LabelElement, deltaX: Float, deltaY: Float): LabelElement {
    val delta = if (abs(deltaX) > abs(deltaY)) deltaX else deltaY
    return when (element.type) {
        LabelElementType.BARCODE -> {
            element.copy(
                width = (element.width + deltaX).coerceIn(120f, LabelRenderer.WIDTH_DOTS - element.x),
                height = (element.height + deltaY).coerceIn(36f, LabelRenderer.HEIGHT_DOTS - element.y),
            )
        }
        LabelElementType.QR_CODE, LabelElementType.IMAGE, LabelElementType.LOGO -> {
            val factor = (1f + delta / 140f).coerceIn(.55f, 1.8f)
            val nextWidth = (element.width * factor).coerceIn(24f, LabelRenderer.WIDTH_DOTS - element.x)
            val nextHeight = (element.height * factor).coerceIn(16f, LabelRenderer.HEIGHT_DOTS - element.y)
            element.copy(width = nextWidth, height = nextHeight)
        }
        else -> {
            val factor = (1f + delta / 120f).coerceIn(.65f, 1.6f)
            val nextTextSize = (element.textSize * factor).coerceIn(7f, 54f)
            val lineHeight = nextTextSize * 1.45f
            val nextHeight = when (element.type) {
                LabelElementType.DESCRIPTION -> maxOf(element.height, lineHeight * 2.2f).coerceAtMost(LabelRenderer.HEIGHT_DOTS - element.y)
                else -> maxOf(element.height, lineHeight).coerceAtMost(LabelRenderer.HEIGHT_DOTS - element.y)
            }
            element.copy(textSize = nextTextSize, height = nextHeight)
        }
    }
}

private data class SnapResult(
    val x: Float,
    val y: Float,
    val guides: List<SnapGuide>,
)

private data class SnapGuide(
    val orientation: GuideOrientation,
    val position: Float,
)

private enum class GuideOrientation {
    Vertical,
    Horizontal,
}

private fun snapElement(rawX: Float, rawY: Float, element: LabelElement, elements: List<LabelElement>): SnapResult {
    val threshold = 6f
    var x = rawX
    var y = rawY
    var moving = visualBounds(element.copy(x = rawX, y = rawY))
    val guides = mutableListOf<SnapGuide>()
    elements.filter { it.id != element.id && it.enabled }.forEach { other ->
        val otherBounds = visualBounds(other)
        if (abs(moving.left - otherBounds.left) <= threshold) {
            x += otherBounds.left - moving.left
            guides += SnapGuide(GuideOrientation.Vertical, otherBounds.left)
        }
        if (abs(moving.right - otherBounds.right) <= threshold) {
            x += otherBounds.right - moving.right
            guides += SnapGuide(GuideOrientation.Vertical, otherBounds.right)
        }
        if (abs(moving.centerX - otherBounds.centerX) <= threshold) {
            x += otherBounds.centerX - moving.centerX
            guides += SnapGuide(GuideOrientation.Vertical, otherBounds.centerX)
        }
        moving = visualBounds(element.copy(x = x, y = y))
        if (abs(moving.top - otherBounds.top) <= threshold) {
            y += otherBounds.top - moving.top
            guides += SnapGuide(GuideOrientation.Horizontal, otherBounds.top)
        }
        if (abs(moving.bottom - otherBounds.bottom) <= threshold) {
            y += otherBounds.bottom - moving.bottom
            guides += SnapGuide(GuideOrientation.Horizontal, otherBounds.bottom)
        }
        if (abs(moving.centerY - otherBounds.centerY) <= threshold) {
            y += otherBounds.centerY - moving.centerY
            guides += SnapGuide(GuideOrientation.Horizontal, otherBounds.centerY)
        }
        moving = visualBounds(element.copy(x = x, y = y))
    }
    val uniqueGuides = guides.distinctBy { "${it.orientation}:${it.position.roundToInt()}" }.takeLast(2)
    return SnapResult(
        x = x.coerceIn(0f, LabelRenderer.WIDTH_DOTS - element.width),
        y = y.coerceIn(0f, LabelRenderer.HEIGHT_DOTS - element.height),
        guides = uniqueGuides,
    )
}

private data class ElementVisualBounds(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
) {
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
}

private fun visualBounds(element: LabelElement): ElementVisualBounds {
    if (element.type in setOf(LabelElementType.BARCODE, LabelElementType.QR_CODE, LabelElementType.IMAGE, LabelElementType.LOGO)) {
        return ElementVisualBounds(element.x, element.y, element.x + element.width, element.y + element.height)
    }
    if (element.boxed) {
        return ElementVisualBounds(element.x, element.y, element.x + element.width, element.y + element.height)
    }
    val textWidth = visualTextWidth(element)
    val left = when (element.align) {
        TEXT_ALIGN_LEFT -> element.x
        TEXT_ALIGN_RIGHT -> element.x + element.width - textWidth
        else -> element.x + (element.width - textWidth) / 2f
    }
    val top = element.y + ((element.height - element.textSize * 1.25f) / 2f).coerceAtLeast(0f)
    return ElementVisualBounds(left, top, left + textWidth, top + element.textSize * 1.25f)
}

private fun visualTextWidth(element: LabelElement): Float {
    val sampleChars = when (element.type) {
        LabelElementType.PRICE -> 5
        LabelElementType.CONDITION -> 3
        LabelElementType.ITEM_CODE -> 14
        LabelElementType.DESCRIPTION -> 12
        else -> 8
    }
    return (sampleChars * element.textSize * 0.62f).coerceAtMost(element.width)
}

private fun newTemplateElement(type: LabelElementType): LabelElement {
    val now = System.currentTimeMillis()
    return when (type) {
        LabelElementType.LOGO -> LabelElement(
            "el_$now",
            type,
            42f,
            4f,
            300f,
            30f,
            customText = LOGO_HORIZONTAL,
        )
        LabelElementType.BARCODE -> LabelElement("el_$now", type, 28f, 170f, 328f, 56f)
        LabelElementType.QR_CODE -> LabelElement("el_$now", type, 292f, 170f, 62f, 62f)
        LabelElementType.IMAGE -> LabelElement("el_$now", type, 20f, 42f, 68f, 68f)
        LabelElementType.PRICE -> LabelElement("el_$now", type, 96f, 100f, 192f, 52f, 36f, true)
        LabelElementType.ITEM_NAME -> LabelElement("el_$now", type, 36f, 42f, 312f, 34f, 22f, true)
        LabelElementType.CATEGORY -> LabelElement("el_$now", type, 36f, 66f, 170f, 24f, 12f, align = TEXT_ALIGN_LEFT)
        LabelElementType.DESCRIPTION -> LabelElement("el_$now", type, 36f, 70f, 240f, 40f, 11f, align = TEXT_ALIGN_LEFT)
        LabelElementType.CONDITION -> LabelElement("el_$now", type, 286f, 72f, 64f, 24f, 13f, true)
        LabelElementType.ITEM_CODE -> LabelElement("el_$now", type, 62f, 212f, 260f, 20f, 13f)
        LabelElementType.CUSTOM_TEXT -> LabelElement("el_$now", type, 80f, 232f, 224f, 24f, 13f, customText = "自定义文字")
        else -> LabelElement("el_$now", type, 80f, 80f, 224f, 24f, 14f)
    }
}

private fun editorElementText(item: Item, template: LabelTemplate, element: LabelElement): String =
    when (element.type) {
        LabelElementType.BARCODE -> "||||||||||||"
        LabelElementType.QR_CODE -> "QR"
        LabelElementType.IMAGE -> "图片"
        else -> LabelRenderer.sampleValue(item, template, element)
    }

@Composable
private fun EmptyCard(title: String, desc: String, action: () -> Unit) {
    BoRaisedCard(Modifier.fillMaxWidth().clickable(onClick = action)) {
        Column(
            Modifier.fillMaxWidth().padding(26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Default.AutoAwesome, null, tint = BoRed, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(10.dp))
            Text(
                title,
                color = BoInk,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                desc,
                color = BoSub,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun SyncLine(title: String, desc: String, color: Color, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(.12f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Sync, null, tint = color, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = BoInk, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = BoSub, fontSize = 11.sp)
        }
        Text(value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
fun ParcelsScreen(vm: MainViewModel) {
    val appState by vm.state.collectAsState()
    if (!appState.roles.contains("super_admin")) {
        LaunchedEffect(Unit) { vm.navigate(AppScreen.Dashboard) }
        return
    }

    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("parcel_mode", android.content.Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var bucket by remember { mutableStateOf(ParcelBucket.Pending) }
    var mode by remember {
        mutableStateOf(
            if (prefs.getString("mode", ParcelListMode.Item.wire) == ParcelListMode.Parcel.wire) {
                ParcelListMode.Parcel
            } else {
                ParcelListMode.Item
            },
        )
    }
    var query by remember { mutableStateOf("") }
    var debouncedQuery by remember { mutableStateOf("") }
    val effectiveMode = if (debouncedQuery.isNotBlank()) ParcelListMode.Item else mode
    var counts by remember { mutableStateOf(ParcelCounts()) }
    var parcelItems by remember { mutableStateOf<List<ParcelItem>>(emptyList()) }
    var parcelRows by remember { mutableStateOf<List<ParcelRow>>(emptyList()) }
    var hasMore by remember { mutableStateOf(false) }
    var nextOffset by remember { mutableStateOf<Int?>(0) }
    var loading by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var selectedItem by remember { mutableStateOf<ParcelItem?>(null) }
    var selectedDetail by remember { mutableStateOf<ParcelDetail?>(null) }
    var detailLoading by remember { mutableStateOf(false) }
    var packDialogItem by remember { mutableStateOf<ParcelItem?>(null) }

    fun refreshCounts() {
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { vm.parcelCounts() } }
                .onSuccess { counts = it }
        }
    }

    fun loadList(reset: Boolean) {
        if (loading || loadingMore) return
        val offset = if (reset) 0 else nextOffset ?: return
        if (reset) loading = true else loadingMore = true
        error = ""
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    vm.parcels(bucket = bucket, mode = effectiveMode, query = debouncedQuery, limit = 30, offset = offset)
                }
            }.onSuccess { result ->
                if (reset) {
                    parcelItems = result.items
                    parcelRows = result.rows
                } else {
                    parcelItems = parcelItems + result.items
                    parcelRows = parcelRows + result.rows
                }
                hasMore = result.hasMore
                nextOffset = result.nextOffset
            }.onFailure {
                error = it.message ?: "日本小包加载失败"
            }
            loading = false
            loadingMore = false
        }
    }

    fun openDetail(row: ParcelRow) {
        detailLoading = true
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { vm.parcelDetail(row.id) } }
                .onSuccess { selectedDetail = it }
                .onFailure { error = it.message ?: "包裹详情加载失败" }
            detailLoading = false
        }
    }

    fun applyPackResult(target: ParcelItem, result: PackPiecesResult) {
        val updated = target.copy(
            packPieces = result.packPieces,
            packPiecesSource = result.packPiecesSource,
            packUnitNote = result.packUnitNote.ifBlank { target.packUnitNote },
            piecePriceCny = result.piecePriceCny ?: target.piecePriceCny,
            piecePriceJpy = result.piecePriceJpy ?: target.piecePriceJpy,
        )
        parcelItems = parcelItems.map { if (it.id == target.id) updated else it }
        selectedDetail = selectedDetail?.let { detail ->
            detail.copy(items = detail.items.map { if (it.id == target.id) updated else it })
        }
        selectedItem = selectedItem?.let { if (it.id == target.id) updated else it }
    }

    LaunchedEffect(query) {
        delay(300)
        debouncedQuery = query.trim()
    }
    LaunchedEffect(Unit) { refreshCounts() }
    LaunchedEffect(bucket, effectiveMode, debouncedQuery) { loadList(reset = true) }

    Scaffold(containerColor = BoPage, bottomBar = { CleanBottomNav(vm, AppScreen.Dashboard) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 18.dp),
        ) {
            ParcelCompactHeader(
                onBack = { vm.navigate(AppScreen.Dashboard) },
                onRefresh = {
                    refreshCounts()
                    loadList(reset = true)
                },
            )
            ParcelSearchBox(query, "搜索品名 / 订单号 / 包裹号") { query = it }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ParcelTab("待签收", counts.pending, bucket == ParcelBucket.Pending, Modifier.weight(1.05f)) { bucket = ParcelBucket.Pending }
                ParcelTab("已签收", counts.received, bucket == ParcelBucket.Received, Modifier.weight(1.05f)) { bucket = ParcelBucket.Received }
                if (debouncedQuery.isBlank()) {
                    ParcelModeButton("商品", mode == ParcelListMode.Item, Modifier.weight(.72f)) {
                        mode = ParcelListMode.Item
                        prefs.edit().putString("mode", mode.wire).apply()
                    }
                    ParcelModeButton("包裹", mode == ParcelListMode.Parcel, Modifier.weight(.72f)) {
                        mode = ParcelListMode.Parcel
                        prefs.edit().putString("mode", mode.wire).apply()
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            if (error.isNotBlank()) {
                DesignEmptyPanel("加载失败", error)
            }
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (loading) {
                    item { DesignEmptyPanel("正在加载", "正在获取日本小包数据") }
                } else if (effectiveMode == ParcelListMode.Item) {
                    if (parcelItems.isEmpty()) item { DesignEmptyPanel("暂无商品", "当前条件下没有日本小包商品") }
                    items(parcelItems, key = { it.id }) { item ->
                        ParcelItemCard(item, debouncedQuery) {
                            selectedItem = item
                        }
                    }
                } else {
                    if (parcelRows.isEmpty()) item { DesignEmptyPanel("暂无包裹", "当前条件下没有日本小包包裹") }
                    items(parcelRows, key = { it.id }) { row ->
                        ParcelRowCard(row, debouncedQuery) { openDetail(row) }
                    }
                }
                item {
                    ParcelListFooter(
                        loadingMore = loadingMore,
                        hasMore = hasMore,
                        onMore = { loadList(reset = false) },
                    )
                }
            }
        }
    }

    selectedDetail?.let { detail ->
        ParcelDetailScreen(
            detail = detail,
            loading = detailLoading,
            onClose = { selectedDetail = null },
            onItem = { selectedItem = it },
        )
    }

    selectedItem?.let { item ->
        ParcelItemSheet(
            item = item,
            onClose = { selectedItem = null },
            onPack = { packDialogItem = item },
        )
    }

    packDialogItem?.let { item ->
        PackPiecesDialog(
            vm = vm,
            item = item,
            onClose = { packDialogItem = null },
            onSaved = { result ->
                applyPackResult(item, result)
                packDialogItem = null
            },
        )
    }
}

@Composable
private fun ParcelCompactHeader(onBack: () -> Unit, onRefresh: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White)
                .border(1.dp, BoLine.copy(.72f), RoundedCornerShape(14.dp)),
        ) {
            Icon(Icons.Default.ArrowBack, null, tint = BoInk, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text("日本小包", color = BoInk, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        IconButton(
            onClick = onRefresh,
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White)
                .border(1.dp, BoLine.copy(.72f), RoundedCornerShape(14.dp)),
        ) {
            Icon(Icons.Default.Refresh, null, tint = BoInk, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun ParcelSearchBox(value: String, placeholder: String, onValueChange: (String) -> Unit) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = androidx.compose.ui.text.TextStyle(color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Medium),
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(1.dp, BoLine.copy(.72f), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp),
        decorationBox = { inner ->
            Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = BoMuted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (value.isBlank()) Text(placeholder, color = BoMuted, fontSize = 13.sp, maxLines = 1)
                    inner()
                }
            }
        },
    )
}

@Composable
private fun ParcelTab(label: String, count: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) BoRed else Color.White)
            .border(1.dp, if (selected) BoRed else BoLine, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Text(label, color = if (selected) Color.White else BoInk, fontSize = 12.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Spacer(Modifier.width(4.dp))
        Text(count.toString(), color = if (selected) Color.White else BoRed, fontSize = 11.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
private fun ParcelModeButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) BoRed else BoSub,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        modifier = modifier
            .height(32.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) BoRedSoft else Color.White)
            .border(1.dp, if (selected) BoRed.copy(.34f) else BoLine, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(top = 7.dp),
    )
}

@Composable
private fun ParcelItemCard(item: ParcelItem, query: String, onClick: () -> Unit) {
    BoRaisedCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            ProductImage(toThumbUrl(item.imageUrl, 200), Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).background(BoSoft), ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                HighlightedText(item.name, query, fontSize = 13, maxLines = 2)
                Text(item.subOrderNo, color = BoSub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    listOf(item.systemCode, item.addedBy, formatShortDateTime(item.addedAt)).filter { it.isNotBlank() }.joinToString(" · "),
                    color = BoMuted,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (item.packPieces != null && item.packPieces > 1) {
                    Spacer(Modifier.height(5.dp))
                    MiniBadge(
                        "拆 ${item.packPieces}${item.packUnitNote.ifBlank { "件" }} · ${formatMoney(item.piecePriceCny)}/${item.packUnitNote.ifBlank { "件" }}",
                        BoRed,
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(item.landedUnitCny?.let { formatMoney(it) } ?: "待核算", color = BoRed, fontSize = 16.sp, fontWeight = FontWeight.Black)
                Text("到手/件 ×${item.quantity}", color = BoSub, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ParcelRowCard(row: ParcelRow, query: String, onClick: () -> Unit) {
    BoRaisedCard(Modifier.clickable(onClick = onClick)) {
        Box {
            if (row.isProblem) {
                Box(Modifier.align(Alignment.CenterStart).width(4.dp).height(76.dp).clip(RoundedCornerShape(8.dp)).background(BoRed))
            }
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                ProductImage(toThumbUrl(row.firstImageUrl, 200), Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).background(BoSoft), ContentScale.Crop)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    HighlightedText("${row.firstItemName} 等 ${row.itemCount} 件", query, fontSize = 13, maxLines = 2)
                    Text(row.trackingNo.ifBlank { row.sourceOrderNo }, color = BoSub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("购 ${formatShortDate(row.purchasedAt)}", color = BoMuted, fontSize = 10.sp)
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(formatMoney(row.grandTotalCny), color = BoRed, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Text("${formatMoney(row.avgUnitCny)} × ${row.totalQty}件", color = BoSub, fontSize = 11.sp)
                }
            }
            if (row.isProblem) {
                Icon(Icons.Default.Warning, null, tint = BoRed, modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).size(18.dp))
            }
        }
    }
}

@Composable
private fun ParcelListFooter(loadingMore: Boolean, hasMore: Boolean, onMore: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(54.dp), contentAlignment = Alignment.Center) {
        when {
            loadingMore -> Text("加载中", color = BoSub, fontSize = 12.sp)
            hasMore -> {
                LaunchedEffect(Unit) { onMore() }
                Text("加载更多", color = BoRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onMore))
            }
            else -> Text("没有更多", color = BoMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ParcelDetailScreen(detail: ParcelDetail, loading: Boolean, onClose: () -> Unit, onItem: (ParcelItem) -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Surface(Modifier.fillMaxSize(), color = BoPage) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                BoTopBar(onBack = onClose)
                if (loading) {
                    DesignEmptyPanel("正在加载", "正在获取包裹详情")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProductImage(toThumbUrl(detail.parcel.firstImageUrl, 600), Modifier.size(74.dp).clip(RoundedCornerShape(16.dp)).background(BoSoft), ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(detail.parcel.firstItemName, color = BoInk, fontSize = 17.sp, fontWeight = FontWeight.Black, maxLines = 2)
                        Text(detail.parcel.trackingNo, color = BoSub, fontSize = 12.sp)
                        if (detail.parcel.isProblem) MiniBadge("异常包裹", BoRed)
                    }
                }
                Spacer(Modifier.height(14.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        BoRaisedCard {
                            Column(Modifier.padding(14.dp)) {
                                ParcelDetailLine("状态", detail.parcel.status)
                                ParcelDetailLine("国际单号", detail.parcel.trackingNo)
                                ParcelDetailLine("来源订单号", detail.parcel.sourceOrderNo)
                                ParcelDetailLine("卖家", detail.parcel.seller)
                                ParcelDetailLine("商品合计", formatMoney(detail.totals.goodsTotalCny))
                                ParcelDetailLine("国际运费", formatMoney(detail.totals.freightCny))
                                ParcelDetailLine("关税", formatMoney(detail.totals.tariffCny))
                                ParcelDetailLine("合计", formatMoney(detail.totals.grandTotalCny))
                                ParcelDetailLine("重量", detail.parcel.weight)
                                ParcelDetailLine("件数", detail.totals.totalQty.takeIf { it > 0 }?.toString().orEmpty())
                                ParcelDetailLine("购买时间", formatFullDate(detail.parcel.purchasedAt))
                                ParcelDetailLine("付款时间", formatFullDate(detail.parcel.paidAt))
                                ParcelDetailLine("签收时间", formatFullDate(detail.parcel.receivedAt))
                                ParcelDetailLine("仓位", detail.parcel.warehouseLocation)
                                ParcelDetailLine("系统编码", detail.parcel.systemCode)
                                ParcelDetailLine("添加时间", formatFullDate(detail.parcel.createdAt))
                                ParcelDetailLine("备注", detail.parcel.note)
                            }
                        }
                    }
                    item {
                        Text("子商品 ${detail.items.size}", color = BoInk, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                    items(detail.items, key = { it.id }) { item ->
                        BoRaisedCard(Modifier.clickable { onItem(item) }) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                ProductImage(toThumbUrl(item.imageUrl, 200), Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(BoSoft), ContentScale.Crop)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, color = BoInk, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text("×${item.quantity} · ${formatMoney(item.itemTotalCny)}", color = BoSub, fontSize = 11.sp)
                                }
                                Icon(Icons.Default.ChevronRight, null, tint = BoSub)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ParcelItemSheet(item: ParcelItem, onClose: () -> Unit, onPack: () -> Unit) {
    Dialog(onDismissRequest = onClose) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Surface(
                modifier = Modifier.fillMaxWidth().height(maxHeight * 0.90f),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                color = BoPage,
            ) {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                    BoTopBar(onBack = onClose)
                    Text(item.name.ifBlank { item.originalName }, color = BoInk, fontSize = 20.sp, fontWeight = FontWeight.Black, maxLines = 2)
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            ProductImage(toThumbUrl(item.imageUrl, 600), Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(18.dp)).background(BoSoft), ContentScale.Crop)
                        }
                        item {
                            BoRaisedCard {
                                Column(Modifier.padding(14.dp)) {
                                    ParcelDetailLine("sub_order_no", item.subOrderNo)
                                    ParcelDetailLine("JPY 小计", formatJpyCny(item.jpySubtotal, item.itemTotalCny))
                                    ParcelDetailLine("单价", formatJpy(item.unitPriceJpy))
                                    ParcelDetailLine("数量", item.quantity.toString())
                                    ParcelDetailLine("重量", item.weight)
                                    ParcelDetailLine("汇率", item.exchangeRate?.toString().orEmpty())
                                    ParcelDetailLine("手续费", formatMoney(item.serviceFeeCny))
                                    ParcelDetailLine("国内运费", formatMoney(item.domesticShippingCny))
                                    ParcelDetailLine("运费补差", formatMoney(item.shippingAdjustmentCny))
                                    ParcelDetailLine("关税类目", item.tariffCategory)
                                    ParcelDetailLine("税率", item.taxRate?.let { "${it}%" }.orEmpty())
                                    ParcelDetailLine("关税", formatJpy(item.tariffJpy))
                                    ParcelDetailLine("运费分摊", formatMoney(item.allocatedFreightCny))
                                    ParcelDetailLine("关税(¥)", formatMoney(item.tariffCny))
                                    ParcelDetailLine("到手价", formatMoney(item.landedCny), valueColor = BoRed, bold = true)
                                    ParcelDetailLine("支付方式", item.paymentMethod)
                                    ParcelDetailLine("支付时间", formatFullDate(item.paidAt))
                                    ParcelDetailLine("商户单号", item.merchantOrderNo)
                                    ParcelDetailLine("平台", item.platform)
                                    ParcelDetailLine("成色", item.condition)
                                    ParcelDetailLine("附加服务", item.extraService)
                                    ParcelDetailLine("系统编码", item.systemCode)
                                    ParcelDetailLine("添加人", item.addedBy)
                                    ParcelDetailLine("添加时间", formatFullDate(item.addedAt))
                                    ParcelDetailLine("备注", item.note)
                                }
                            }
                        }
                        item {
                            BoRaisedCard {
                                Column(Modifier.padding(14.dp)) {
                                    Text("拆包单价", color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black)
                                    Spacer(Modifier.height(8.dp))
                                    if (item.packPieces != null && item.packPieces > 0) {
                                        val unit = item.packUnitNote.ifBlank { "件" }
                                        Text("整包拆 ${item.packPieces}$unit · ${formatMoney(item.piecePriceCny)}/$unit", color = BoRed, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                        Spacer(Modifier.height(10.dp))
                                        Button(onClick = onPack, colors = ButtonDefaults.buttonColors(containerColor = BoInk)) { Text("重新计算") }
                                    } else {
                                        Button(onClick = onPack, colors = ButtonDefaults.buttonColors(containerColor = BoRed), modifier = Modifier.fillMaxWidth()) {
                                            Text("拆包单价计算")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PackPiecesDialog(vm: MainViewModel, item: ParcelItem, onClose: () -> Unit, onSaved: (PackPiecesResult) -> Unit) {
    val scope = rememberCoroutineScope()
    var piecesText by remember { mutableStateOf(item.packPieces?.toString().orEmpty()) }
    var unitText by remember { mutableStateOf(item.packUnitNote.ifBlank { "件" }) }
    var source by remember { mutableStateOf(item.packPiecesSource.ifBlank { "manual" }) }
    var reasoning by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val pieces = piecesText.toIntOrNull()
    val unit = unitText.ifBlank { "件" }
    val livePrice = pieces?.takeIf { it > 0 }?.let { item.landedCny?.div(it) }

    fun applyEstimate(estimate: PackPiecesEstimate, estimateSource: String) {
        if (estimate.pieces != null) {
            piecesText = estimate.pieces.toString()
            if (estimate.unit.isNotBlank()) unitText = estimate.unit
            source = estimateSource
        }
        reasoning = estimate.reasoning
    }

    LaunchedEffect(item.id) {
        busy = true
        error = ""
        runCatching {
            withContext(Dispatchers.IO) { vm.estimateParcelPackPieces(item.id, "title") }
        }.onSuccess { estimate ->
            applyEstimate(estimate, "title")
            if (estimate.pieces == null && item.imageUrl.isNotBlank()) {
                runCatching {
                    withContext(Dispatchers.IO) { vm.estimateParcelPackPieces(item.id, "image") }
                }.onSuccess { imageEstimate -> applyEstimate(imageEstimate, "image") }
                    .onFailure { error = it.message ?: "图片估算失败" }
            }
        }.onFailure {
            error = it.message ?: "标题估算失败"
        }
        busy = false
    }

    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(22.dp), color = Color.White) {
            Column(Modifier.padding(18.dp).fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProductImage(toThumbUrl(item.imageUrl, 200), Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(BoSoft), ContentScale.Crop)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.name, color = BoInk, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 2)
                        Text("到手价 ${formatMoney(item.landedCny)}", color = BoRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, null) }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = piecesText,
                    onValueChange = {
                        piecesText = it.filter(Char::isDigit)
                        source = "manual"
                    },
                    label = { Text("pieces") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = unitText,
                    onValueChange = {
                        unitText = it.take(12)
                        source = "manual"
                    },
                    label = { Text("unit") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                Text("实时单价 ${formatMoney(livePrice)}/$unit", color = BoRed, fontSize = 20.sp, fontWeight = FontWeight.Black)
                if (busy) Text("正在估算", color = BoSub, fontSize = 12.sp)
                if (reasoning.isNotBlank()) Text(reasoning, color = BoSub, fontSize = 12.sp, lineHeight = 16.sp)
                if (error.isNotBlank()) Text(error, color = BoRed, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        val cleanPieces = pieces?.takeIf { it > 0 }
                        busy = true
                        scope.launch {
                            runCatching {
                                withContext(Dispatchers.IO) {
                                    vm.saveParcelPackPieces(item.id, cleanPieces, source, unit)
                                }
                            }.onSuccess(onSaved)
                                .onFailure { error = it.message ?: "保存失败" }
                            busy = false
                        }
                    },
                    enabled = !busy && pieces != null && pieces > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = BoRed),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("保存")
                }
            }
        }
    }
}

@Composable
private fun ParcelDetailLine(label: String, value: String, valueColor: Color = BoInk, bold: Boolean = false) {
    if (value.isBlank() || value == "¥--" || value == "¥-- / --") return
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = BoSub, fontSize = 12.sp, modifier = Modifier.width(92.dp))
        Text(value, color = valueColor, fontSize = 12.sp, fontWeight = if (bold) FontWeight.Black else FontWeight.Medium, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun HighlightedText(value: String, query: String, fontSize: Int, maxLines: Int) {
    val text = value.ifBlank { "未命名商品" }
    if (query.isBlank()) {
        Text(text, color = BoInk, fontSize = fontSize.sp, fontWeight = FontWeight.Black, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
        return
    }
    val lower = text.lowercase(Locale.CHINA)
    val needle = query.lowercase(Locale.CHINA)
    val start = lower.indexOf(needle)
    if (start < 0) {
        Text(text, color = BoInk, fontSize = fontSize.sp, fontWeight = FontWeight.Black, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
        return
    }
    Text(
        buildAnnotatedString {
            append(text.substring(0, start))
            withStyle(SpanStyle(color = BoRed, fontWeight = FontWeight.Black, background = BoRedSoft)) {
                append(text.substring(start, start + query.length.coerceAtMost(text.length - start)))
            }
            append(text.substring((start + query.length).coerceAtMost(text.length)))
        },
        color = BoInk,
        fontSize = fontSize.sp,
        fontWeight = FontWeight.Black,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}

private fun toThumbUrl(url: String, size: Int): String {
    if (url.isBlank()) return ""
    if (url.contains("width=")) return url.replace(Regex("width=\\d+"), "width=$size")
    return if (url.contains("supabase.co")) {
        url + (if (url.contains("?")) "&" else "?") + "width=$size"
    } else {
        url
    }
}

private fun formatMoney(value: Double?): String =
    value?.let { "¥%.2f".format(Locale.CHINA, it) } ?: "¥--"

private fun formatJpy(value: Double?): String =
    value?.let { "JPY %.0f".format(Locale.CHINA, it) } ?: ""

private fun formatJpyCny(jpy: Double?, cny: Double?): String {
    val left = formatJpy(jpy)
    val right = cny?.let { "≈${formatMoney(it)}" }.orEmpty()
    return listOf(left, right).filter { it.isNotBlank() }.joinToString(" ")
}

private fun formatShortDate(value: String): String {
    if (value.length >= 10) return value.substring(5, 10)
    return value
}

private fun formatShortDateTime(value: String): String {
    if (value.length >= 16) return value.substring(5, 16).replace("T", " ")
    return formatShortDate(value)
}

private fun formatFullDate(value: String): String =
    value.replace("T", " ").removeSuffix("Z")

private fun todayText(): String = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date())
