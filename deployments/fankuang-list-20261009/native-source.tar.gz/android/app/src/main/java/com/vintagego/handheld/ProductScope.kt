package com.vintagego.handheld

import java.math.BigDecimal
import java.net.URLEncoder
import org.json.JSONObject

enum class ProductViewScope { Current, All }

class ProductScopeException : Exception("商品范围无法确认，请刷新后重试")

data class ProductScope(
    val generation: Long,
    val userName: String,
    val locationId: String,
    val locationKind: String,
    val authorizedLocations: Set<String>,
    val roles: Set<String>,
    val view: ProductViewScope = ProductViewScope.Current,
) {
    val canShowHQTools: Boolean get() = locationKind == "warehouse" &&
        locationId in authorizedLocations && roles.any { it == "super_admin" || it == "hq_operator" }
    val marker: String get() = if (view == ProductViewScope.All) "all" else "location:$locationId"

    fun validate() {
        if (locationId.isBlank() || locationId !in authorizedLocations ||
            (view == ProductViewScope.All && !canShowHQTools)) throw ProductScopeException()
    }
}

data class ProductQuery(
    val q: String = "",
    val type: String = "custom",
    val sort: String = "updated_desc",
    val category: String = "",
    val hasImage: Boolean? = null,
    val status: String = "selling",
    val pageSize: Int = 200,
    val onlyFankuang: Boolean = false,
) {
    fun path(scope: ProductScope, page: Int = 1): String {
        scope.validate()
        val params = linkedMapOf("q" to q.trim(), "type" to type, "sort" to sort, "status" to status,
            "page_size" to pageSize.toString(), "page" to page.toString())
        if (scope.view == ProductViewScope.All) params["scope"] = "all" else params["location_id"] = scope.locationId
        if (category.isNotBlank()) params["category"] = category
        if (hasImage != null && type == "custom") params["has_image"] = if (hasImage) "1" else "0"
        if (onlyFankuang) params["fankuang"] = "1"
        return "products?" + params.entries.joinToString("&") { "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}" }
    }
}

// Old location-namespaced entries may contain globally leaked products.
private const val PRODUCT_CACHE_VERSION = 2

data class ProductCacheKey(val scope: ProductScope, val query: ProductQuery, val version: Int = PRODUCT_CACHE_VERSION) {
    fun accepts(currentScope: ProductScope?, currentQuery: ProductQuery, sequence: Int, currentSequence: Int): Boolean =
        version == PRODUCT_CACHE_VERSION && scope == currentScope && query == currentQuery && sequence == currentSequence
}

data class ProductCounts(val custom: Int = 0, val bundle: Int = 0, val standard: Int = 0, val all: Int = 0)

data class ProductStock(val locationId: String, val locationName: String, val locationKind: String, val qty: Int)

fun productLocationLabel(name: String, kind: String): String = when {
    kind == "warehouse" && (name.contains("总部") || name.lowercase() in setOf("hq", "hq warehouse", "headquarters")) -> "总部"
    name.isNotBlank() -> name
    else -> "库位未命名"
}

fun productLocationBadges(stocks: List<ProductStock>): List<String> = stocks.distinctBy { it.locationId }
    .map { "${productLocationLabel(it.locationName, it.locationKind)} · ${it.qty}" }
    .ifEmpty { listOf("库位未返回") }

private fun JSONObject.productInt(key: String): Int = try {
    val value = opt(key) as? Number ?: throw ProductScopeException()
    BigDecimal(value.toString()).intValueExact()
} catch (_: ArithmeticException) { throw ProductScopeException() }
  catch (_: NumberFormatException) { throw ProductScopeException() }

fun parseProductCounts(json: JSONObject): ProductCounts {
    val counts = listOf("custom", "bundle", "standard", "all").map { json.productInt(it) }
    if (counts.any { it < 0 }) throw ProductScopeException()
    return ProductCounts(counts[0], counts[1], counts[2], counts[3])
}

fun parseProductStocks(json: JSONObject): List<ProductStock> {
    return parseStockRows(json, "stock_qty")
}

fun parseProductDetailStocks(json: JSONObject): List<ProductStock> = parseStockRows(json, "qty")

private fun parseStockRows(json: JSONObject, quantityKey: String): List<ProductStock> {
    val rows = json.optJSONArray("stocks") ?: return emptyList()
    return (0 until rows.length()).map { index ->
        val row = rows.optJSONObject(index) ?: throw ProductScopeException()
        val id = row.opt("location_id") as? String ?: throw ProductScopeException()
        if (id.isBlank()) throw ProductScopeException()
        ProductStock(id, row.opt("location_name") as? String ?: "", row.opt("location_kind") as? String ?: "", row.productInt(quantityKey))
    }
}

fun productDetailPath(scope: ProductScope, id: String): String {
    scope.validate()
    if (id.isBlank()) throw ProductScopeException()
    val query = if (scope.view == ProductViewScope.All) "scope=all" else "location_id=${URLEncoder.encode(scope.locationId, "UTF-8")}"
    return "items/${URLEncoder.encode(id, "UTF-8")}?$query"
}

fun validateProductDetail(data: JSONObject, scope: ProductScope, id: String) {
    scope.validate()
    if (data.opt("scope") != scope.marker || data.opt("id") != id || data.optJSONArray("stocks") == null) throw ProductScopeException()
    val stocks = parseProductDetailStocks(data)
    if (data.opt("product_type") !in setOf("standard", "custom", "bundle") || data.opt("is_unlimited_stock") !is Boolean) throw ProductScopeException()
    if (scope.view == ProductViewScope.Current && data.optString("product_type") != "standard" && stocks.none { it.locationId == scope.locationId }) {
        throw ProductScopeException()
    }
}

fun validateProductResponse(data: JSONObject, scope: ProductScope, onlyFankuang: Boolean = false) {
    scope.validate()
    if (data.opt("scope") != scope.marker) throw ProductScopeException()
    parseProductCounts(data.optJSONObject("counts") ?: throw ProductScopeException())
    val rows = data.optJSONArray("items") ?: throw ProductScopeException()
    for (index in 0 until rows.length()) {
        val row = rows.optJSONObject(index) ?: throw ProductScopeException()
        if (onlyFankuang && row.opt("in_fankuang") != true) throw ProductScopeException()
        if (row.optJSONArray("stocks") == null) throw ProductScopeException()
        val stocks = parseProductStocks(row)
        // Standard catalogue eligibility is decided by the server, not physical stock.
        val requiresMembership = row.optString("product_type") != "standard"
        if (scope.view == ProductViewScope.Current && requiresMembership && stocks.none { it.locationId == scope.locationId }) {
            throw ProductScopeException()
        }
    }
}
