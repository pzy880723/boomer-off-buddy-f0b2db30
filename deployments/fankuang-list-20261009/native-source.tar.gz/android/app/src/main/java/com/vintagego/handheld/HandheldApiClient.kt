package com.vintagego.handheld

import android.content.Context
import android.os.Build
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class HandheldApiException(
    val code: String,
    message: String,
    val httpCode: Int,
) : Exception(message)

data class ListingImageResult(
    val storagePath: String,
    val signedUrl: String,
    val mimeType: String,
)

data class UploadImageResult(
    val storagePath: String,
    val readUrl: String,
    val uploadUrl: String,
)

enum class ParcelBucket(val wire: String) {
    Pending("pending"),
    Received("received"),
}

enum class ParcelListMode(val wire: String) {
    Item("item"),
    Parcel("parcel"),
}

data class ParcelCounts(
    val pending: Int = 0,
    val received: Int = 0,
)

data class ParcelListResult(
    val mode: ParcelListMode,
    val items: List<ParcelItem> = emptyList(),
    val rows: List<ParcelRow> = emptyList(),
    val hasMore: Boolean = false,
    val nextOffset: Int? = null,
)

data class ParcelRow(
    val id: String,
    val trackingNo: String,
    val sourceOrderNo: String,
    val firstItemName: String,
    val firstImageUrl: String,
    val seller: String,
    val warehouseLocation: String,
    val status: String,
    val isProblem: Boolean,
    val grandTotalCny: Double?,
    val avgUnitCny: Double?,
    val itemCount: Int,
    val totalQty: Int,
    val purchasedAt: String,
    val paidAt: String,
    val receivedAt: String,
    val createdAt: String,
    val note: String,
    val internationalFreightCny: Double?,
    val tariffCny: Double?,
    val goodsTotalCny: Double?,
    val weight: String,
    val systemCode: String,
)

data class ParcelItem(
    val id: String,
    val parcelId: String,
    val name: String,
    val originalName: String,
    val imageUrl: String,
    val subOrderNo: String,
    val systemCode: String,
    val addedBy: String,
    val addedAt: String,
    val quantity: Int,
    val itemTotalCny: Double?,
    val avgCny: Double?,
    val landedCny: Double?,
    val piecePriceCny: Double?,
    val piecePriceJpy: Double?,
    val packPieces: Int?,
    val packPiecesSource: String,
    val packUnitNote: String,
    val jpySubtotal: Double?,
    val unitPriceJpy: Double?,
    val weight: String,
    val exchangeRate: Double?,
    val serviceFeeCny: Double?,
    val domesticShippingCny: Double?,
    val shippingAdjustmentCny: Double?,
    val tariffCategory: String,
    val taxRate: Double?,
    val tariffJpy: Double?,
    val allocatedFreightCny: Double?,
    val tariffCny: Double?,
    val paymentMethod: String,
    val paidAt: String,
    val merchantOrderNo: String,
    val platform: String,
    val condition: String,
    val extraService: String,
    val note: String,
) {
    val landedUnitCny: Double?
        get() = landedCny?.takeIf { it.isFinite() && it >= 0 && quantity > 0 }?.div(quantity)
}

data class ParcelDetail(
    val parcel: ParcelRow,
    val totals: ParcelTotals,
    val items: List<ParcelItem>,
)

data class ParcelTotals(
    val goodsTotalCny: Double?,
    val freightCny: Double?,
    val tariffCny: Double?,
    val grandTotalCny: Double?,
    val totalQty: Int,
    val itemCount: Int,
)

data class PackPiecesResult(
    val id: String,
    val packPieces: Int?,
    val packPiecesSource: String,
    val packUnitNote: String,
    val piecePriceCny: Double?,
    val piecePriceJpy: Double?,
)

data class PackPiecesEstimate(
    val pieces: Int?,
    val confidence: Double?,
    val reasoning: String,
    val unit: String,
)

data class SmartCreateResult(
    val skuId: String,
    val skuCode: String,
    val barcode: String,
    val youzanSyncStatus: String,
    val imageProcessingStatus: String,
)

data class RfidLookupResult(
    val known: Boolean,
    val epc: String,
    val currentLocationId: String?,
    val currentLocationName: String?,
    val skuId: String?,
)

data class RfidStockInResult(
    val queued: Int,
    val alreadyBound: List<String>,
)

data class BootstrapResult(
    val userName: String,
    val roles: Set<String>,
    val locations: List<HandheldLocation>,
    val selectedLocation: HandheldLocation?,
)

data class DashboardStats(
    val stockCount: Int = 0,
    val inventoryAccuracy: Double? = null,
    val inTransitCount: Int = 0,
)

data class DashboardTaskItem(
    val id: String,
    val type: String,
    val urgency: String,
    val title: String,
    val description: String,
    val meta: String,
    val action: String,
    val targetId: String,
)

data class DashboardRecentItem(
    val id: String,
    val name: String,
    val skuCode: String,
    val barcode: String,
    val price: Double,
    val conditionGrade: String,
    val imageUrl: String,
    val status: String,
)

data class DashboardData(
    val stats: DashboardStats = DashboardStats(),
    val tasks: List<DashboardTaskItem> = emptyList(),
    val recentItems: List<DashboardRecentItem> = emptyList(),
    val unreadNotifications: Int = 0,
)

data class ErpSkuItem(
    val id: String,
    val skuCode: String,
    val name: String,
    val category: String,
    val priceCents: Int,
    val stockQty: Int,
    val conditionGrade: String,
    val imageUrl: String,
    val notes: String,
    val productType: String,
    val isDisplay: Boolean,
    val listingStatus: String,
    val statusLabel: String,
    val canRestock: Boolean,
    val editable: Boolean,
    val isUnlimitedStock: Boolean = false,
    val imageProcessingStatus: String = "idle",
    val productStocks: List<ProductStock> = emptyList(),
    val brand: String = "",
    val era: String = "",
    val ipName: String = "",
    val material: String = "",
    val fankuangOverride: Boolean? = null,
    val fankuangMembership: Boolean? = null,
    val canEdit: Boolean? = null,
    val updatedAt: String = "",
)

data class ProductListResult(
    val items: List<ErpSkuItem>,
    val counts: ProductCounts = ProductCounts(),
)

data class GlobalStockSummary(
    val skuCount: Int = 0,
    val totalQty: Int = 0,
    val outOfStock: Int = 0,
    val lowStock: Int = 0,
)

data class GlobalStockItem(
    val skuId: String,
    val name: String,
    val skuCode: String,
    val barcode: String,
    val category: String,
    val productType: String,
    val imageUrl: String,
    val priceCents: Int,
    val totalQty: Int,
    val stocks: Map<String, Int>,
    val isDisplay: Boolean,
    val listingStatus: String,
    val statusLabel: String,
    val isUnlimitedStock: Boolean = false,
)

data class GlobalStockData(
    val locations: List<HandheldLocation> = emptyList(),
    val items: List<GlobalStockItem> = emptyList(),
    val summary: GlobalStockSummary = GlobalStockSummary(),
    val page: Int = 1,
    val pageSize: Int = 50,
    val total: Int = 0,
)

data class TransferSummary(
    val id: String,
    val code: String,
    val status: String,
    val qty: Int,
    val fromLocationId: String,
    val toLocationId: String,
    val shippedAt: String,
    val receivedAt: String,
    val createdAt: String,
    val notes: String,
)

data class TransferLine(
    val skuId: String,
    val expectedQty: Int,
    val shippedQty: Int,
    val receivedQty: Int,
)

data class TransferEpc(
    val epc: String,
    val skuId: String,
    val shipScannedAt: String,
    val receiveScannedAt: String,
)

data class TransferDetail(
    val summary: TransferSummary,
    val lines: List<TransferLine>,
    val epcs: List<TransferEpc>,
)

data class TransferScanResult(
    val side: String,
    val received: Int,
    val unknownCount: Int,
    val unknown: List<String>,
)

data class TransferConfirmResult(
    val stage: String,
    val lines: Int,
)

data class StocktakeSummaryItem(
    val id: String,
    val code: String,
    val status: String,
    val openedAt: String,
    val submittedAt: String,
    val reviewedAt: String,
    val notes: String,
)

data class NotificationRecord(
    val id: String,
    val kind: String,
    val title: String,
    val payloadText: String,
    val ts: String,
    val isRead: Boolean? = null,
) {
    val category: MessageCategory get() = messageCategory(kind)
}

data class SyncRecord(
    val id: String,
    val skuId: String,
    val targetStock: Int,
    val reason: String,
    val status: String,
    val attempts: Int,
    val lastError: String,
    val createdAt: String,
    val updatedAt: String,
)

data class BindRfidResult(
    val epc: String,
    val skuId: String,
    val locationId: String,
    val stockAfter: Int,
)

data class CloudLabelTemplates(
    val defaultTemplateIds: Map<PrintTemplateType, String>,
    val items: List<LabelTemplate>,
    val canManage: Boolean,
)

enum class AuthFailureAction {
    THROW,
    REFRESH_AND_RETRY,
    CLEAR_SESSION,
}

fun authenticatedFailureAction(statusCode: Int, refreshAttempted: Boolean): AuthFailureAction = when {
    statusCode != 401 -> AuthFailureAction.THROW
    refreshAttempted -> AuthFailureAction.CLEAR_SESSION
    else -> AuthFailureAction.REFRESH_AND_RETRY
}

class HandheldApiClient(
    context: Context,
    private val session: HandheldSessionStore = HandheldSessionStore(context.applicationContext),
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .build(),
) {
    private val appContext = context.applicationContext
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private val baseUrl = BuildConfig.HANDHELD_BASE_URL.trimEnd('/') + "/"
    private val publicBaseUrl = baseUrl.removeSuffix("handheld/")

    fun sendOtp(phone: String): Int {
        val data = postPublicWithoutAuth(
            "auth/otp/send",
            JSONObject()
                .put("phone", phone.trim())
                .put("purpose", "login"),
        )
        return data.optInt("ttl", 300)
    }

    fun verifyOtp(phone: String, code: String): BootstrapResult {
        val body = baseAuthBody()
            .put("phone", phone.trim())
            .put("code", code.trim())
        return saveBootstrap(postPublicWithoutAuth("auth/otp/verify", body))
    }

    fun bootstrap(identity: String, password: String): BootstrapResult {
        val trimmed = identity.trim()
        val body = baseAuthBody()
            .put(if (trimmed.contains("@")) "email" else "phone", trimmed)
            .put("password", password)
        val data = postWithoutAuth("auth/bootstrap", body)
        return saveBootstrap(data)
    }

    fun refreshSession() {
        if (session.refreshToken.isBlank()) throw HandheldApiException("unauthorized", "登录已过期，请重新登录", 401)
        val body = JSONObject().put("refresh_token", session.refreshToken)
        val request = Request.Builder()
            .url(baseUrl + "auth/refresh")
            .post(body.toString().toRequestBody(jsonType))
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .header("X-App-Version", BuildConfig.VERSION_NAME)
            .header("X-Device-Model", Build.MODEL ?: "Android")
            .apply { if (session.deviceToken.isNotBlank()) header("X-Device-Token", session.deviceToken) }
            .build()
        val data = executeJson(request)
        val accessToken = data.optionalString("access_token")
        session.saveTokens(
            deviceToken = session.deviceToken,
            accessToken = accessToken,
            refreshToken = data.optionalString("refresh_token"),
            sessionToken = data.optionalString("session_token").ifBlank { accessToken },
            expiresAt = data.optionalString("expires_at"),
        )
    }

    fun productTaxonomy(): ProductTaxonomy =
        ProductCategoryContract.parseTaxonomyBundle(getPublicWithoutAuth("storefront/taxonomy"))

    fun productCategories(): List<ProductCategoryOption> = productTaxonomy().categories

    private fun saveBootstrap(data: JSONObject): BootstrapResult {
        val deviceToken = data.optionalString("device_token")
            .ifBlank { data.optJSONObject("device")?.optionalString("device_token").orEmpty() }
        val accessToken = data.optionalString("access_token")
        val refreshToken = data.optionalString("refresh_token")
        val sessionToken = data.optionalString("session_token").ifBlank { accessToken }
        if (deviceToken.isBlank() || sessionToken.isBlank()) {
            throw HandheldApiException("invalid_bootstrap", "ERP 登录成功但未返回 device_token/session token", 200)
        }
        session.saveTokens(
            deviceToken = deviceToken,
            accessToken = accessToken,
            refreshToken = refreshToken,
            sessionToken = sessionToken,
            expiresAt = data.optionalString("expires_at"),
        )
        val locations = parseLocations(data.optJSONArray("locations") ?: JSONArray())
        val selected = data.optJSONObject("location")?.toLocation()
            ?: data.optJSONObject("device")?.optJSONObject("location")?.toLocation()
            ?: data.optJSONObject("device")?.optJSONObject("default_location")?.toLocation()
            ?: data.optJSONObject("device")?.toFlatLocation()
        val visibleSelected = selected?.takeUnless { it.isYouzanShellLocation() }
        visibleSelected?.let(session::saveSelectedLocation)
        val user = data.optJSONObject("user")
        val userName = employeeDisplayName(user?.optionalString("display_name") ?: user?.optionalString("name"))
        val roles = parseStringSet(user?.optJSONArray("roles") ?: JSONArray())
        session.saveUser(userName, roles, user?.optionalString("avatar_url").orEmpty())
        return BootstrapResult(
            userName = userName,
            roles = roles,
            locations = locations,
            selectedLocation = visibleSelected,
        )
    }

    private fun baseAuthBody(): JSONObject =
        JSONObject()
            .put("install_id", session.installId)
            .put("device_label", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
            .put("app_version", BuildConfig.VERSION_NAME)
            .put("os_version", "Android ${Build.VERSION.RELEASE}")
            .put(
                "capabilities",
                JSONObject()
                    .put("reader_model", "SUNMI_V3")
                    .put("has_camera", true)
                    .put("has_printer", true)
                    .put("has_rfid_reader", true)
                    .put("has_barcode_scanner", true),
            )

    fun locations(): List<HandheldLocation> {
        val data = get("locations")
        val items = data.getJSONArray("items")
        return parseLocations(items)
    }

    fun currentEmployeeProfile(): EmployeeProfile {
        val user = get("auth/me").getJSONObject("user")
        return EmployeeProfile(employeeDisplayName(user.optionalString("display_name")),
            user.optionalString("avatar_url").orEmpty().takeIf { it.startsWith("https://") }.orEmpty(),
            parseStringSet(user.optJSONArray("roles") ?: JSONArray()))
    }

    fun switchLocation(location: HandheldLocation): HandheldLocation {
        val data = post("location/switch", JSONObject().put("location_id", location.id))
        val switched = data.optJSONObject("location")?.toLocation() ?: location
        return switched
    }

    fun dashboard(locationId: String): DashboardData {
        val data = get("dashboard?location_id=${locationId.urlPathSafe()}")
        val stats = data.optJSONObject("stats") ?: JSONObject()
        val tasks = data.optJSONArray("tasks") ?: JSONArray()
        val recent = data.optJSONArray("recent_items") ?: JSONArray()
        return DashboardData(
            stats = DashboardStats(
                stockCount = stats.optInt("stock_count", 0),
                inventoryAccuracy = stats.optDoubleOrNull("inventory_accuracy"),
                inTransitCount = stats.optInt("in_transit_count", 0),
            ),
            tasks = buildList {
                for (index in 0 until tasks.length()) {
                    val item = tasks.getJSONObject(index)
                    add(
                        DashboardTaskItem(
                            id = item.optionalString("id"),
                            type = item.optionalString("type"),
                            urgency = item.optionalString("urgency"),
                            title = item.optionalString("title"),
                            description = item.optionalString("description"),
                            meta = item.optionalString("meta"),
                            action = item.optionalString("action"),
                            targetId = item.optionalString("target_id"),
                        ),
                    )
                }
            },
            recentItems = buildList {
                for (index in 0 until recent.length()) {
                    val item = recent.getJSONObject(index)
                    add(
                        DashboardRecentItem(
                            id = item.optionalString("id"),
                            name = item.optionalString("name"),
                            skuCode = item.optionalString("sku_code"),
                            barcode = item.optionalString("barcode"),
                            price = item.optDouble("price", 0.0),
                            conditionGrade = item.optionalString("condition_grade"),
                            imageUrl = item.optionalString("image_url"),
                            status = item.optionalString("status"),
                        ),
                    )
                }
            },
            unreadNotifications = data.optInt("unread_notifications", 0),
        )
    }

    fun parcelCounts(): ParcelCounts {
        val data = get("parcels/counts")
        return ParcelCounts(
            pending = data.optInt("pending", 0),
            received = data.optInt("received", 0),
        )
    }

    fun parcels(
        bucket: ParcelBucket,
        mode: ParcelListMode,
        query: String = "",
        limit: Int = 30,
        offset: Int = 0,
    ): ParcelListResult {
        val params = buildList {
            add("bucket=${bucket.wire}")
            add("mode=${mode.wire}")
            if (query.isNotBlank()) add("q=${query.urlQuerySafe()}")
            add("limit=${limit.coerceIn(1, 50)}")
            add("offset=${offset.coerceAtLeast(0)}")
        }.joinToString("&")
        val data = get("parcels?$params")
        val resultMode = when (data.optionalString("mode")) {
            ParcelListMode.Parcel.wire -> ParcelListMode.Parcel
            else -> ParcelListMode.Item
        }
        return ParcelListResult(
            mode = resultMode,
            items = data.optJSONArray("items").orEmptyObjects().map { it.toParcelItem() },
            rows = data.optJSONArray("rows").orEmptyObjects().map { it.toParcelRow() },
            hasMore = data.optBoolean("has_more", false),
            nextOffset = data.optIntOrNull("next_offset"),
        )
    }

    fun parcelDetail(id: String): ParcelDetail {
        val data = get("parcels/${id.urlPathSafe()}")
        val parcel = data.optJSONObject("parcel")?.toParcelRow() ?: data.toParcelRow()
        val totals = data.optJSONObject("totals")?.toParcelTotals() ?: ParcelTotals(
            goodsTotalCny = parcel.goodsTotalCny,
            freightCny = parcel.internationalFreightCny,
            tariffCny = parcel.tariffCny,
            grandTotalCny = parcel.grandTotalCny,
            totalQty = parcel.totalQty,
            itemCount = parcel.itemCount,
        )
        return ParcelDetail(
            parcel = parcel,
            totals = totals,
            items = data.optJSONArray("items").orEmptyObjects().map { it.toParcelItem(parcel.id) },
        )
    }

    fun estimateParcelPackPieces(itemId: String, source: String): PackPiecesEstimate {
        val safeSource = if (source == "image") "image" else "title"
        val data = post("parcels/items/${itemId.urlPathSafe()}/pack-pieces/estimate-$safeSource", JSONObject())
        return data.toPackPiecesEstimate()
    }

    fun saveParcelPackPieces(itemId: String, pieces: Int?, source: String?, unit: String?): PackPiecesResult {
        val opId = clientOpId("pack")
        val body = JSONObject()
            .put("pack_pieces", pieces ?: JSONObject.NULL)
            .put("pack_pieces_source", source ?: JSONObject.NULL)
            .put("pack_unit_note", unit?.takeIf { it.isNotBlank() } ?: JSONObject.NULL)
            .put("client_op_id", opId)
        val data = post("parcels/items/${itemId.urlPathSafe()}/pack-pieces", body, clientOpId = opId)
        return data.toPackPiecesResult()
    }

    fun skuSearch(query: String = ""): List<ErpSkuItem> {
        val data = get("sku/search?q=${query.urlQuerySafe()}")
        return data.optJSONArray("items").orEmptyObjects().map { it.toErpSkuItem() }
    }

    fun products(
        scope: ProductScope,
        query: ProductQuery,
    ): ProductListResult {
        requireProductSession(scope)
        val data = get(query.path(scope))
        requireProductSession(scope)
        validateProductResponse(data, scope, query.onlyFankuang)
        val rows = data.getJSONArray("items").orEmptyObjects().toMutableList()
        val total = data.optInt("total", rows.size)
        var page = 1
        while (rows.size < total) {
            val next = get(query.path(scope, page = ++page))
            requireProductSession(scope)
            validateProductResponse(next, scope, query.onlyFankuang)
            val remaining = next.getJSONArray("items").orEmptyObjects()
            if (remaining.isEmpty()) throw ProductScopeException()
            rows.addAll(remaining)
        }
        return ProductListResult(
            items = rows.map { row ->
                val item = row.toErpSkuItem(parseProductStocks(row))
                item.copy(stockQty = item.productStocks
                    .filter { scope.view == ProductViewScope.All || it.locationId == scope.locationId }.sumOf { it.qty })
            },
            counts = parseProductCounts(data.getJSONObject("counts")),
        )
    }

    private fun requireProductSession(scope: ProductScope) {
        scope.validate()
        if (!session.hasAuth || session.userName != scope.userName || session.roles != scope.roles ||
            session.selectedLocation()?.id != scope.locationId || session.selectedLocation()?.kind != scope.locationKind) {
            throw ProductScopeException()
        }
    }

    fun globalStock(
        type: String,
        query: String = "",
        category: String = "",
        stockState: String = "all",
        status: String = "all",
        lowThreshold: Int = 5,
        pageSize: Int = 50,
    ): GlobalStockData {
        val params = buildList {
            add("type=${type.urlQuerySafe()}")
            if (query.isNotBlank()) add("q=${query.urlQuerySafe()}")
            if (category.isNotBlank()) add("category=${category.urlQuerySafe()}")
            if (stockState.isNotBlank()) add("stock_state=${stockState.urlQuerySafe()}")
            if (status.isNotBlank()) add("status=${status.urlQuerySafe()}")
            add("low_threshold=$lowThreshold")
            add("page_size=$pageSize")
        }.joinToString("&")
        val data = get("global-stock?$params")
        return data.toGlobalStockData()
    }

    fun itemDetail(scope: ProductScope, id: String): ErpSkuItem {
        requireProductSession(scope)
        val data = get(productDetailPath(scope, id))
        requireProductSession(scope)
        validateProductDetail(data, scope, id)
        val item = data.toErpSkuItem(parseProductDetailStocks(data))
        return item.copy(stockQty = item.productStocks
            .filter { scope.view == ProductViewScope.All || it.locationId == scope.locationId }.sumOf { it.qty })
    }

    fun setItemFankuang(scope: ProductScope, item: Item, enabled: Boolean) {
        requireProductSession(scope)
        require(item.productType == "custom" && item.canEdit == true && item.updatedAt.isNotBlank()) {
            "请重新打开商品详情获取编辑权限"
        }
        val body = JSONObject()
            .put("location_id", scope.locationId)
            .put("expected_updated_at", item.updatedAt)
            .put("client_op_id", clientOpId("fankuang"))
            .put("fankuang_override", enabled)
        patch("items/${item.erpId.urlPathSafe()}", body)
        requireProductSession(scope)
    }

    fun setItemDisplay(id: String, isDisplay: Boolean): ErpSkuItem {
        val data = post(
            "items/${id.urlPathSafe()}/set-status",
            JSONObject().put("is_display", isDisplay),
            clientOpId = clientOpId("status"),
        )
        return (data.optJSONObject("sku") ?: data).toErpSkuItem()
    }

    fun restockItem(
        id: String,
        locationId: String?,
        delta: Int = 1,
        printLabels: Boolean = true,
        labelTemplateId: String? = null,
        note: String = "手持终端补货入库",
    ): ErpSkuItem {
        val body = JSONObject()
            .put("delta", delta.coerceAtLeast(1))
            .put("print_labels", printLabels)
            .put("note", note)
        if (!locationId.isNullOrBlank()) body.put("location_id", locationId)
        if (!labelTemplateId.isNullOrBlank()) body.put("label_template_id", labelTemplateId)
        val data = post("items/${id.urlPathSafe()}/restock", body, clientOpId = clientOpId("restock"))
        return (data.optJSONObject("sku") ?: data).toErpSkuItem()
    }

    fun transfers(locationId: String, role: String? = null, status: String? = null): List<TransferSummary> {
        val query = buildList {
            add("location_id=${locationId.urlPathSafe()}")
            if (!role.isNullOrBlank()) add("role=${role.urlPathSafe()}")
            if (!status.isNullOrBlank()) add("status=${status.urlPathSafe()}")
        }.joinToString("&")
        val data = get("transfers?$query")
        return data.optJSONArray("items").orEmptyObjects().map { it.toTransferSummary() }
    }

    fun transferDetail(id: String): TransferDetail {
        val data = get("transfers/${id.urlPathSafe()}")
        val summary = data.toTransferSummary()
        val lines = data.optJSONArray("lines").orEmptyObjects().map {
            TransferLine(
                skuId = it.optionalString("sku_id"),
                expectedQty = it.optInt("expected_qty", 0),
                shippedQty = it.optInt("shipped_qty", 0),
                receivedQty = it.optInt("received_qty", 0),
            )
        }
        val epcs = data.optJSONArray("epcs").orEmptyObjects().map {
            TransferEpc(
                epc = it.optionalString("epc"),
                skuId = it.optionalString("sku_id"),
                shipScannedAt = it.optionalString("ship_scanned_at"),
                receiveScannedAt = it.optionalString("receive_scanned_at"),
            )
        }
        return TransferDetail(summary = summary, lines = lines, epcs = epcs)
    }

    fun transferScan(summary: TransferSummary, currentLocationId: String, epcs: List<String>): TransferScanResult {
        val cleanEpcs = epcs.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val body = JSONObject()
            .put("transfer_id", summary.id)
            .put("epcs", JSONArray(cleanEpcs))
        val side = if (currentLocationId == summary.fromLocationId) {
            "ship"
        } else if (currentLocationId == summary.toLocationId) {
            "receive"
        } else {
            throw HandheldApiException("location_forbidden", "当前库位不是该调拨单的发货方或收货方", 403)
        }
        val path = if (side == "ship") "transfer/ship-scan" else "transfer/receive-scan"
        val data = post(path, body)
        val unknown = data.optJSONArray("unknown").orEmptyStrings()
        return TransferScanResult(
            side = side,
            received = data.optInt("received", 0),
            unknownCount = data.optInt("unknown_count", unknown.size),
            unknown = unknown,
        )
    }

    fun transferConfirm(summary: TransferSummary, currentLocationId: String): TransferConfirmResult {
        val side = if (currentLocationId == summary.fromLocationId) {
            "ship"
        } else if (currentLocationId == summary.toLocationId) {
            "receive"
        } else {
            throw HandheldApiException("location_forbidden", "当前库位不是该调拨单的发货方或收货方", 403)
        }
        val path = if (side == "ship") "transfer/ship-confirm" else "transfer/receive-confirm"
        val data = post(path, JSONObject().put("transfer_id", summary.id))
        return TransferConfirmResult(
            stage = if (side == "ship") "shipped" else "received",
            lines = if (side == "ship") data.optInt("shipped", 0) else data.optInt("received", 0),
        )
    }

    fun stocktakes(locationId: String, status: String? = null): List<StocktakeSummaryItem> {
        val query = buildList {
            add("location_id=${locationId.urlPathSafe()}")
            if (!status.isNullOrBlank()) add("status=${status.urlPathSafe()}")
        }.joinToString("&")
        val data = get("stocktakes?$query")
        return data.optJSONArray("items").orEmptyObjects().map { it.toStocktakeSummaryItem() }
    }

    fun stocktakeOpen(): StocktakeSummaryItem {
        val data = post("stocktake/open", JSONObject())
        return data.toStocktakeSummaryItem()
    }

    fun stocktakeScan(stocktakeId: String, epcs: List<String>): Int {
        val cleanEpcs = epcs.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val body = JSONObject()
            .put("stocktake_id", stocktakeId)
            .put("epcs", JSONArray(cleanEpcs))
        val data = post("stocktake/scan", body)
        return data.optInt("scanned", cleanEpcs.size)
    }

    fun stocktakeSubmit(stocktakeId: String): Boolean {
        post("stocktake/submit", JSONObject().put("stocktake_id", stocktakeId))
        return true
    }

    fun notifications(locationId: String, limit: Int = 50): List<NotificationRecord> {
        val data = get("notifications?location_id=${locationId.urlPathSafe()}&limit=$limit")
        return data.optJSONArray("items").orEmptyObjects().filter {
            val declaredLocation = it.optionalString("location_id")
            declaredLocation.isBlank() || declaredLocation == locationId
        }.map { it.toNotificationRecord() }
    }

    private fun JSONObject.toNotificationRecord(): NotificationRecord {
        val kind = optionalString("kind")
        val payload = optJSONObject("payload")
        val fields = listOf("order_no", "order_number", "product_name", "sku_code", "status", "quantity", "channel")
            .associateWith { payload?.opt(it) }
        val presentation = notificationPresentation(kind, fields)
        return NotificationRecord(
            id = optionalString("id"), kind = kind,
            title = presentation.title, payloadText = presentation.summary,
            ts = optionalString("ts").ifBlank { optionalString("created_at") },
            isRead = opt("is_read") as? Boolean,
        )
    }

    fun syncRecords(status: String? = null, limit: Int = 50): List<SyncRecord> {
        val query = buildList {
            if (!status.isNullOrBlank()) add("status=${status.urlPathSafe()}")
            add("limit=$limit")
        }.joinToString("&")
        val data = get("sync-records?$query")
        return data.optJSONArray("items").orEmptyObjects().map {
            SyncRecord(
                id = it.optionalString("id"),
                skuId = it.optionalString("sku_id"),
                targetStock = it.optInt("target_stock", 0),
                reason = it.optionalString("reason"),
                status = it.optionalString("status"),
                attempts = it.optInt("attempts", 0),
                lastError = it.optionalString("last_error"),
                createdAt = it.optionalString("created_at"),
                updatedAt = it.optionalString("updated_at"),
            )
        }
    }

    fun labelTemplates(): CloudLabelTemplates {
        val data = get("label-templates")
        val items = data.optJSONArray("items").orEmptyObjects().map { it.toLabelTemplate() }
        val defaults = data.optJSONObject("default_template_ids")
        return CloudLabelTemplates(
            defaultTemplateIds = mapOf(
                PrintTemplateType.LABEL to (
                    defaults?.optionalString("label").orEmpty()
                        .ifBlank { data.optionalString("default_template_id") }
                    ),
                PrintTemplateType.RECEIPT to defaults?.optionalString("receipt").orEmpty(),
            ),
            items = items,
            canManage = data.optBoolean("can_manage", false),
        )
    }

    fun createLabelTemplate(template: LabelTemplate, isDefault: Boolean = false): LabelTemplate {
        val data = post("label-templates", template.toLabelTemplateBody(isDefault = isDefault))
        return data.toLabelTemplate()
    }

    fun updateLabelTemplate(template: LabelTemplate): LabelTemplate {
        val data = put("label-templates/${template.id.urlPathSafe()}", template.toLabelTemplateBody())
        return data.toLabelTemplate()
    }

    fun deleteLabelTemplate(id: String) {
        delete("label-templates/${id.urlPathSafe()}")
    }

    fun setDefaultLabelTemplate(id: String): String {
        val data = post("label-templates/${id.urlPathSafe()}/set-default", JSONObject())
        return data.optionalString("default_template_id")
    }

    fun recognizeItem(
        storagePath: String? = null,
        imageBase64: String? = null,
        imageStoragePaths: List<String> = emptyList(),
        imageStorageBucket: String = "sku-raw",
        imageUrls: List<String> = emptyList(),
        primaryIndex: Int = 0,
        hint: String? = null,
    ): RecognitionResult {
        val body = JSONObject()
            .put("hint", hint ?: ProductCategoryContract.recognitionHint)
        if (!storagePath.isNullOrBlank()) body.put("image_url", storagePath)
        if (!imageBase64.isNullOrBlank()) body.put("image_base64", imageBase64)
        val storageInputs = imageStoragePaths
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(6)
        if (storageInputs.isNotEmpty()) {
            val arr = JSONArray()
            storageInputs.forEach { path ->
                arr.put(
                    JSONObject()
                        .put("bucket", imageStorageBucket)
                        .put("storage_path", path),
                )
            }
            body.put("image_storage_paths", arr)
            body.put("primary_index", primaryIndex.coerceIn(0, storageInputs.lastIndex))
        }
        val urlInputs = imageUrls.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(6)
        if (urlInputs.isNotEmpty()) {
            val arr = JSONArray()
            urlInputs.forEach(arr::put)
            body.put("image_urls", arr)
            if (storageInputs.isEmpty()) body.put("primary_index", primaryIndex.coerceIn(0, urlInputs.lastIndex))
        }
        val data = post("ai/recognize-item", body)
        val categoryCode = data.optionalString("category_code")
            .ifBlank { data.optionalString("category") }
        val category = data.optionalString("category_name")
            .ifBlank { mapCategoryToDisplay(categoryCode) }
        val era = data.optionalString("era")
        val brand = data.optionalString("brand")
        val description = vintageSummary(
            raw = data.optionalString("description"),
            name = data.optionalString("name"),
            category = category,
            brand = brand,
            era = era,
        )
        return RecognitionResult(
            name = data.optionalString("name"),
            category = category,
            categoryCode = categoryCode,
            facetCodes = data.optJSONArray("facet_codes").orEmptyStrings(),
            tags = data.optJSONArray("tags").orEmptyStrings(),
            requestId = data.optionalString("request_id"),
            classificationStatus = data.optionalString("status"),
            brand = brand,
            ipName = data.optionalString("ip_name"),
            ipMatchStatus = data.optionalString("ip_match_status").ifBlank { "empty" },
            ipSuggestions = data.optJSONArray("ip_suggestions").orEmptyObjects().map {
                RecognitionIpSuggestion(
                    id = it.optionalString("id"),
                    name = it.optionalString("name"),
                    confidence = it.optDouble("score", 0.0),
                )
            },
            material = era,
            color = "",
            conditionGrade = data.optionalString("condition_grade"),
            conditionNote = description,
            confidence = data.optDouble("confidence", 0.0),
            warning = data.optionalString("warning"),
            alternatives = data.optJSONArray("alternatives").orEmptyObjects().take(3).map {
                RecognitionAlternative(
                    name = it.optionalString("name"),
                    category = mapCategoryToDisplay(it.optionalString("category")),
                    confidence = it.optNumberAsDouble("confidence"),
                )
            },
            suggestedPriceCny = data.optDoubleOrNull("suggested_price_cny"),
        )
    }

    private fun vintageSummary(raw: String, name: String, category: String, brand: String, era: String): String {
        val clean = raw.trim().replace("\n", " ").replace(Regex("\\s+"), " ")
        if (clean.length in 12..45) return clean
        val subject = listOf(era, brand, name.ifBlank { category }).filter { it.isNotBlank() }.joinToString(" ")
        return when {
            subject.isNotBlank() -> "${subject.take(16)}，复古质感鲜明，适合收藏陈列。"
            category.isNotBlank() -> "${category.take(10)}中古单品，复古质感鲜明，适合收藏陈列。"
            else -> "中古杂货单品，复古质感鲜明，适合收藏陈列。"
        }
    }

    fun prepareListingImage(storagePath: String? = null, imageBase64: String? = null): ListingImageResult {
        val body = JSONObject()
            .put(
                "instruction",
                "将随手拍商品图优化为电商上架主图：只允许裁切、透视/角度微调、白底或干净浅色背景、光线修正；不得改变商品本体、文字、条码、瑕疵和品牌细节。",
            )
        if (!storagePath.isNullOrBlank()) body.put("image_url", storagePath)
        if (!imageBase64.isNullOrBlank()) body.put("image_base64", imageBase64)
        val data = post("ai/prepare-listing-image", body)
        return ListingImageResult(
            storagePath = data.getString("storage_path"),
            signedUrl = data.getString("signed_url"),
            mimeType = data.optString("mime_type", "image/png"),
        )
    }

    fun uploadImage(file: File, bucket: String = "sku-raw"): UploadImageResult {
        val contentType = "image/jpeg"
        val data = post(
            "items/upload-image",
            JSONObject()
                .put("bucket", bucket)
                .put("filename", file.name)
                .put("content_type", contentType)
                .put("mode", "signed"),
        )
        val uploadUrl = data.getString("upload_url")
        val headers = data.optJSONObject("headers") ?: JSONObject()
        val requestBuilder = Request.Builder()
            .url(uploadUrl)
            .put(file.asRequestBody(contentType.toMediaTypeOrNull()))
        for (key in headers.keys()) requestBuilder.header(key, headers.getString(key))
        client.newCall(requestBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) {
                throw HandheldApiException("upload_failed", "图片上传失败：${response.code}", response.code)
            }
        }
        return UploadImageResult(
            storagePath = data.getString("storage_path"),
            readUrl = data.optString("read_url", ""),
            uploadUrl = uploadUrl,
        )
    }

    fun downloadTo(url: String, destination: File): File {
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw HandheldApiException("download_failed", "图片下载失败：${response.code}", response.code)
            destination.outputStream().use { output ->
                response.body?.byteStream()?.copyTo(output)
            }
        }
        return destination
    }

    fun smartCreate(item: Item, autoPushYouzan: Boolean = true): SmartCreateResult {
        val body = JSONObject()
            .put("name", item.name)
            .put(
                "category",
                ProductCategoryContract.resolveSubmitCode(item.categoryCode, item.category),
            )
            .put("price_tier", item.priceCents / 100.0)
            .put("is_custom_price", true)
            .put("fankuang_override", item.fankuangOverride ?: JSONObject.NULL)
            .put("grade", item.conditionGrade)
            .put("notes", item.conditionNote)
            .put("brand", item.brand)
            .put("ip_name", item.ipName)
            .put("ip_confirmed", item.ipConfirmed)
            .put("facet_codes", JSONArray(item.facetCodes.distinct().take(20)))
            .put("auto_push_youzan", autoPushYouzan)
            .put("client_op_id", clientOpId("smart"))
        ProductCategoryContract.recognitionMetadata(
            requestId = item.recognitionRequestId,
            confidence = item.categoryConfidence,
            classificationStatus = item.classificationStatus,
            suggestedPriceCny = item.aiSuggestedPriceCny,
        )?.let { metadata ->
            body.put("recognition_request_id", metadata.requestId)
            body.put("category_confidence", metadata.confidence)
            body.put("classification_status", metadata.classificationStatus)
            body.put("ai_suggested_price", metadata.suggestedPriceCny)
        }
        val listingPaths = (item.listingStoragePaths + item.listingStoragePath)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(6)
        if (listingPaths.isNotEmpty()) {
            val imagePaths = JSONArray()
            listingPaths.forEach { path ->
                imagePaths.put(
                    JSONObject()
                        .put("bucket", "sku-raw")
                        .put("storage_path", path),
                )
            }
            body.put("image_storage_paths", imagePaths)
        }
        session.selectedLocation()?.let { body.put("location_id", it.id) }
        val data = post("items/smart-create", body, clientOpId = body.getString("client_op_id"))
        return SmartCreateResult(
            skuId = data.getString("sku_id"),
            skuCode = data.getString("sku_code"),
            barcode = data.optionalString("barcode"),
            youzanSyncStatus = data.optString("youzan_sync_status", "manual"),
            imageProcessingStatus = data.optJSONObject("image_processing")
                ?.optionalString("status")
                .orEmpty()
                .ifBlank { "idle" },
        )
    }

    fun itemImageCount(skuId: String): Int {
        val data = get("items/${skuId.trim()}")
        return data.optJSONArray("images")?.length() ?: 0
    }

    fun rfidLookup(epc: String): RfidLookupResult {
        val data = get("rfid/${epc.urlPathSafe()}")
        val location = data.optJSONObject("location")
        return RfidLookupResult(
            known = data.optBoolean("known", false),
            epc = data.optString("epc", epc),
            currentLocationId = data.optionalString("current_location_id").ifBlank { location?.optionalString("id") },
            currentLocationName = location?.optionalString("name"),
            skuId = data.optionalString("sku_id"),
        )
    }

    fun rfidStockIn(epc: String): RfidStockInResult {
        val body = JSONObject()
            .put("epcs", JSONArray().put(epc))
        val data = post("inbound/scan", body)
        val duplicated = data.optJSONArray("duplicated") ?: JSONArray()
        return RfidStockInResult(
            queued = data.optInt("accepted_count", 0) + data.optInt("unclaimed_count", 0),
            alreadyBound = buildList {
                for (index in 0 until duplicated.length()) add(duplicated.getJSONObject(index).getString("epc"))
            },
        )
    }

    fun rfidTransfer(epc: String, toLocationId: String): Boolean {
        val body = JSONObject()
            .put("epc", epc)
            .put("to_location_id", toLocationId)
            .put("reason", "手持终端现场确认转仓")
            .put("client_op_id", clientOpId("transfer"))
        post("rfid/transfer-location", body)
        return true
    }

    fun bindRfid(skuId: String, epc: String, locationId: String? = null): BindRfidResult {
        val body = JSONObject()
            .put("sku_id", skuId.trim())
            .put("epc", epc.trim())
            .put("client_op_id", clientOpId("bind"))
        if (!locationId.isNullOrBlank()) body.put("location_id", locationId)
        val data = post("items/bind-rfid", body)
        return BindRfidResult(
            epc = data.optionalString("epc"),
            skuId = data.optionalString("sku_id"),
            locationId = data.optionalString("location_id"),
            stockAfter = data.optInt("stock_after", 0),
        )
    }

    fun posBootstrap(locationId: String): PosBootstrap {
        val data = posGet("pos/bootstrap?location_id=${locationId.urlQuerySafe()}")
        val locations = data.optJSONArray("locations").orEmptyObjects().map { item ->
            PosLocation(
                id = item.optionalString("id"),
                name = item.optionalString("name"),
                kind = item.optionalString("kind"),
            )
        }
        val openShift = data.optJSONArray("open_shifts").orEmptyObjects()
            .firstOrNull { it.optionalString("location_id") == locationId }
            ?.toPosShift()
        return PosBootstrap(locations = locations, openShift = openShift)
    }

    fun posOpenShift(location: HandheldLocation): PosShift {
        val data = posPost(
            "pos/shifts/open",
            JSONObject()
                .put("location_id", location.id)
                .put("register_code", "APP-${session.installId.take(8).uppercase()}")
                .put("register_name", "${Build.MODEL ?: "Android"} 移动收银"),
        )
        return data.toPosShift()
    }

    fun posProducts(locationId: String, query: String = "", type: PosProductType? = null): List<PosProduct> =
        posProductPage(locationId, query, type).items

    fun posProductPage(locationId: String, query: String = "", type: PosProductType? = null, offset: Int = 0): PosProductPage {
        require(offset >= 0)
        val path = buildString {
            append("pos/products?location_id=")
            append(locationId.urlQuerySafe())
            if (query.isNotBlank()) append("&q=${query.urlQuerySafe()}")
            if (type != null) append("&type=${type.wire}")
            if (type == PosProductType.CUSTOM) append("&offset=$offset")
        }
        val data = posGet(path)
        val products = data.optJSONArray("items").orEmptyObjects().map { item ->
            val product = item.toPosProduct()
            require(product.locationId.isBlank() || product.locationId == locationId) { "商品门店不匹配" }
            product.copy(locationId = locationId)
        }
        return PosProductPage(products, posNextOffset(data, offset))
    }

    fun posStandardCatalog(locationId: String): List<PosStandardGroup> =
        parsePosStandardCatalog(
            posGet("pos/standard-catalog?location_id=${locationId.urlQuerySafe()}"),
            locationId,
        )

    fun posResolveCode(locationId: String, code: String): Pair<String, JSONObject> {
        val data = posGet(
            "pos/resolve-code?code=${code.trim().urlQuerySafe()}&location_id=${locationId.urlQuerySafe()}",
        )
        return data.optionalString("code_type") to data
    }

    fun posProductFromResolved(data: JSONObject): PosProduct =
        (data.optJSONObject("product") ?: data).toPosProduct()

    fun posSearchCustomers(query: String): List<PosCustomer> =
        posGet("pos/customers/search?q=${query.trim().urlQuerySafe()}")
            .optJSONArray("items")
            .orEmptyObjects()
            .map { item ->
                val wallet = item.optJSONObject("wallet") ?: JSONObject()
                PosCustomer(
                    id = item.optionalString("id"),
                    phone = item.optionalString("phone"),
                    nickname = item.optionalString("nickname"),
                    points = if (wallet.isNull("points")) null else wallet.optInt("points"),
                    storeCreditCents = wallet.optMoneyCents("store_credit"),
                    memberLevel = wallet.optionalString("member_level"),
                )
            }

    fun posPreviewDiscount(
        locationId: String,
        cart: PosCart,
        type: String,
        value: Double,
        reason: String,
        customerId: String? = null,
        pointsToRedeem: Int = 0,
    ): PosDiscountPreview {
        require(pointsToRedeem >= 0)
        val items = JSONArray().apply {
            cart.lines.forEach { line ->
                put(JSONObject().put("sku_id", line.product.skuId).put("quantity", line.quantity))
            }
        }
        val data = posPost(
            "pos/discounts/preview",
            JSONObject()
                .put("location_id", locationId)
                .put("customer_id", customerId ?: JSONObject.NULL)
                .put("points_to_redeem", pointsToRedeem)
                .put("items", items)
                .put(
                    "discount",
                    JSONObject().put("type", type).put("value", value).put("reason", reason),
                ),
        )
        return parsePosDiscountPreview(data)
    }

    fun posCustomerBenefits(customerId: String): PosCustomerBenefits {
        val data = posGet("pos/customers/${customerId.urlPathSafe()}/benefits")
        val customer = data.getJSONObject("customer")
        require(customer.optionalString("id") == customerId) { "会员权益响应不匹配" }
        val wallet = data.optJSONObject("wallet") ?: JSONObject()
        return PosCustomerBenefits(
            customer = PosCustomer(
                id = customerId,
                phone = customer.optionalString("phone"),
                nickname = customer.optionalString("nickname"),
                points = if (wallet.isNull("points")) null else wallet.getInt("points"),
                storeCreditCents = wallet.optMoneyCents("store_credit"),
                memberLevel = wallet.optionalString("member_level"),
            ),
            points = parsePosPointsRedemption(data.optJSONObject("points_redemption")),
        )
    }

    fun posPaymentProfile(locationId: String): PosPaymentProfile {
        val data = posGet("pos/payment-code?location_id=${locationId.urlQuerySafe()}")
        return PosPaymentProfile(
            ready = data.optBoolean("ready_for_payment", false),
            subjectName = data.optionalString("subject_name"),
            merchantIdMasked = data.optionalString("merchant_id_masked"),
            message = data.optionalString("message"),
        )
    }

    fun posStartMicropay(
        locationId: String,
        shiftId: String,
        cart: PosCart,
        provider: String,
        authCode: String,
        customerId: String?,
        discountType: String,
        discountValue: Double,
        discountReason: String,
    ): PosPaymentAttempt {
        val body = posPaymentBody(
            locationId = locationId,
            shiftId = shiftId,
            cart = cart,
            provider = provider,
            customerId = customerId,
            discountType = discountType,
            discountValue = discountValue,
            discountReason = discountReason,
        ).put("auth_code", authCode.trim())
        return posPost("pos/payments/micropay", body).toPosPaymentAttempt()
    }

    fun posCreateQrPayment(
        locationId: String,
        shiftId: String,
        cart: PosCart,
        provider: String,
        customerId: String?,
        discountType: String,
        discountValue: Double,
        discountReason: String,
    ): PosPaymentAttempt =
        posPost(
            "pos/payments/qr-order",
            posPaymentBody(
                locationId = locationId,
                shiftId = shiftId,
                cart = cart,
                provider = provider,
                customerId = customerId,
                discountType = discountType,
                discountValue = discountValue,
                discountReason = discountReason,
            ),
        ).toPosPaymentAttempt()

    fun posPaymentStatus(id: String): PosPaymentAttempt =
        posGet("pos/payments/${id.urlPathSafe()}").toPosPaymentAttempt()

    fun posClosePayment(id: String): PosPaymentAttempt =
        posPost("pos/payments/${id.urlPathSafe()}/close", JSONObject()).toPosPaymentAttempt()

    fun posRetryCashSale(attempt: PosCashSaleAttempt): PosCashRecoveryResult {
        val data = posPost("pos/sales", attempt.validatedBody(), attempt.owner, attempt.locationId)
        return PosCashRecoveryResult.completed(attempt, data)
    }

    fun posReconcileOrCancelCashSale(attempt: PosCashSaleAttempt): PosCashRecoveryResult {
        val original = attempt.validatedBody()
        val body = JSONObject().put("shift_id", original.getString("shift_id")).put("client_op_id", attempt.operationId)
        val data = posPost("pos/sales/recover/cancel", body, attempt.owner, attempt.locationId)
        return parsePosCashRecovery(data, attempt)
    }

    fun posHoldCart(
        shiftId: String,
        cart: PosCart,
        customerId: String?,
        discountType: String = "amount",
        discountValue: Double = 0.0,
        discountReason: String = "",
        pointsRequest: Int = 0,
        clientOperationId: String,
        expectedOwner: String,
        expectedLocationId: String,
    ): String {
        require(pointsRequest >= 0)
        val body = JSONObject()
            .put("shift_id", shiftId)
            .put("client_op_id", clientOperationId)
            .put("discount_snapshot", JSONObject().put("type", discountType).put("value", discountValue).put("reason", discountReason))
            .put("benefit_snapshot", JSONObject().put("points_to_redeem", pointsRequest).put("requires_cart_preview", true))
            .put(
                "items",
                JSONArray().apply {
                    cart.lines.forEach { line ->
                        put(JSONObject().put("sku_id", line.product.skuId).put("quantity", line.quantity))
                    }
                },
            )
        if (!customerId.isNullOrBlank()) body.put("customer_id", customerId)
        val data = posPost("pos/carts/hold", body, expectedOwner, expectedLocationId)
        val id = data.getString("id")
        require(id.isNotBlank() && data.getString("status") == "held") { "挂单未返回完整确认，请先核对挂单列表" }
        return id
    }

    fun posHeldCarts(locationId: String): List<PosHeldCart> {
        val items = posGet("pos/carts/held?location_id=${locationId.urlQuerySafe()}").getJSONArray("items")
        return List(items.length()) { parsePosHeldCart(items.getJSONObject(it), locationId) }
    }

    fun posLookupProduct(skuId: String, locationId: String): PosProduct {
        val product = posGet("pos/products/lookup?code=${skuId.urlQuerySafe()}&location_id=${locationId.urlQuerySafe()}").toPosProduct()
        require(product.skuId == skuId && product.locationId == locationId) { "挂单商品或门店不匹配" }
        return product
    }

    fun posResumeHeldCart(held: PosHeldCart, expectedOwner: String) {
        val data = posPost("pos/carts/${held.id.urlPathSafe()}/resume", JSONObject(), expectedOwner, held.locationId)
        validatePosHeldResume(data, held)
    }

    fun posCashDrawer(shiftId: String): PosCashDrawer {
        val data = posGet("pos/cash-movements?shift_id=${shiftId.urlQuerySafe()}")
        return PosCashDrawer(
            balanceCents = data.optMoneyCents("balance"),
            movements = data.optJSONArray("items").orEmptyObjects().map { item ->
                PosCashMovement(
                    id = item.optionalString("id"),
                    type = item.optionalString("type"),
                    amountCents = item.optMoneyCents("amount"),
                    reason = item.optionalString("reason"),
                    createdAt = item.optionalString("created_at"),
                )
            },
        )
    }

    fun authHeadersReady(): Boolean = session.hasAuth

    fun orderCenterPage(scope: OrderScope, query: OrderQuery, page: Int): OrderPage {
        requireOrderSession(scope)
        return parseOrderPage(get(query.path(scope, page)), query.view)
    }

    fun orderCenterDetail(scope: OrderScope, id: String): CommerceOrder {
        requireOrderSession(scope)
        if (!scope.isHq || id.isBlank()) throw OrderAccessException()
        return parseCommerceOrder(get("orders/${id.urlPathSafe()}"))
    }

    fun orderFulfillmentDetail(scope: OrderScope, id: String): FulfillmentWorkDetail {
        requireOrderSession(scope)
        if (id.isBlank()) throw OrderAccessException()
        return parseFulfillmentWorkDetail(get("fulfillments/${id.urlPathSafe()}"))
    }

    fun orderFulfillmentMutation(scope: OrderScope, detail: FulfillmentWorkDetail, operation: FulfillmentOperation): Boolean {
        requireOrderSession(scope)
        operation.validate(detail, scope)
        return parseFulfillmentMutation(post(operation.path(), operation.body()), operation)
    }

    private fun requireOrderSession(scope: OrderScope) {
        if (!session.hasAuth || session.userName != scope.userName || session.roles != scope.roles ||
            session.selectedLocation()?.id != scope.locationId) throw OrderAccessException()
    }

    private fun posGet(path: String): JSONObject {
        return executeAuthenticated {
            Request.Builder()
                .url(publicBaseUrl + path.trimStart('/'))
                .get()
                .applyAuthHeaders()
                .build()
        }
    }

    fun posSessionOwner(): String? = posSaleOwner(session.deviceToken, session.hasAuth)

    private fun posPost(path: String, body: JSONObject, expectedOwner: String? = null, expectedLocationId: String? = null): JSONObject {
        val idempotencyKey = body.optionalString("client_op_id").ifBlank { clientOpId("pos-request") }
        return executeAuthenticated {
            if (expectedOwner != null) check(posSessionOwner() == expectedOwner && session.selectedLocation()?.id == expectedLocationId) {
                "登录账号或门店已变更，未重试原现金收款"
            }
            Request.Builder()
                .url(publicBaseUrl + path.trimStart('/'))
                .post(body.toString().toRequestBody(jsonType))
                .applyAuthHeaders()
                .header("Idempotency-Key", idempotencyKey)
                .build()
                .also { request ->
                    if (expectedOwner != null) check(
                        posSaleOwner(request.header("X-Device-Token").orEmpty(), true) == expectedOwner &&
                            posSessionOwner() == expectedOwner && session.selectedLocation()?.id == expectedLocationId
                    ) { "登录账号或门店已变更，未重试原现金收款" }
                }
        }
    }

    private fun posPaymentBody(
        locationId: String,
        shiftId: String,
        cart: PosCart,
        provider: String,
        customerId: String?,
        discountType: String,
        discountValue: Double,
        discountReason: String,
    ): JSONObject {
        cart.requireNoAsyncPoints()
        val body = JSONObject()
            .put("location_id", locationId)
            .put("shift_id", shiftId)
            .put("provider", provider)
            .put("client_op_id", clientOpId("pos-payment"))
            .put(
                "items",
                JSONArray().apply {
                    cart.lines.forEach { line ->
                        put(JSONObject().put("sku_id", line.product.skuId).put("quantity", line.quantity))
                    }
                },
            )
        if (!customerId.isNullOrBlank()) body.put("customer_id", customerId)
        if (cart.discountCents > 0) {
            body.put(
                "discount",
                JSONObject()
                    .put("type", discountType)
                    .put("value", discountValue)
                    .put("reason", discountReason.ifBlank { "移动收银优惠" }),
            )
        }
        return body
    }

    private fun get(path: String): JSONObject {
        return executeAuthenticated {
            Request.Builder()
                .url(baseUrl + path.trimStart('/'))
                .get()
                .applyAuthHeaders()
                .build()
        }
    }

    private fun post(path: String, body: JSONObject, clientOpId: String? = null): JSONObject {
        return executeAuthenticated {
            Request.Builder()
                .url(baseUrl + path.trimStart('/'))
                .post(body.toString().toRequestBody(jsonType))
                .applyAuthHeaders()
                .apply {
                    if (!clientOpId.isNullOrBlank()) {
                        header("X-Client-Op-Id", clientOpId)
                        header("ClientOpId", clientOpId)
                    }
                }
                .build()
        }
    }

    private fun patch(path: String, body: JSONObject): JSONObject {
        return executeAuthenticated {
            Request.Builder()
                .url(baseUrl + path.trimStart('/'))
                .patch(body.toString().toRequestBody(jsonType))
                .applyAuthHeaders()
                .build()
        }
    }

    private fun put(path: String, body: JSONObject): JSONObject {
        return executeAuthenticated {
            Request.Builder()
                .url(baseUrl + path.trimStart('/'))
                .put(body.toString().toRequestBody(jsonType))
                .applyAuthHeaders()
                .build()
        }
    }

    private fun delete(path: String): JSONObject {
        return executeAuthenticated {
            Request.Builder()
                .url(baseUrl + path.trimStart('/'))
                .delete()
                .applyAuthHeaders()
                .build()
        }
    }

    private fun executeAuthenticated(buildRequest: () -> Request): JSONObject {
        ensureFreshSession()
        var refreshAttempted = false
        while (true) {
            try {
                return executeJson(buildRequest(), clearAuthOnUnauthorized = refreshAttempted)
            } catch (error: HandheldApiException) {
                when (authenticatedFailureAction(error.httpCode, refreshAttempted)) {
                    AuthFailureAction.THROW -> throw error
                    AuthFailureAction.REFRESH_AND_RETRY -> {
                        refreshSession()
                        refreshAttempted = true
                    }
                    AuthFailureAction.CLEAR_SESSION -> {
                        session.clearAuth()
                        throw error
                    }
                }
            }
        }
    }

    private fun ensureFreshSession() {
        if (!session.hasAuth || session.refreshToken.isBlank()) return
        if (!session.sessionExpiresWithin(seconds = 300)) return
        refreshSession()
    }

    private fun postWithoutAuth(path: String, body: JSONObject): JSONObject {
        val request = Request.Builder()
            .url(baseUrl + path.trimStart('/'))
            .post(body.toString().toRequestBody(jsonType))
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .header("X-App-Version", BuildConfig.VERSION_NAME)
            .header("X-Device-Model", Build.MODEL ?: "Android")
            .build()
        return executeJson(request)
    }

    private fun postPublicWithoutAuth(path: String, body: JSONObject): JSONObject {
        val request = Request.Builder()
            .url(publicBaseUrl + path.trimStart('/'))
            .post(body.toString().toRequestBody(jsonType))
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .header("X-App-Version", BuildConfig.VERSION_NAME)
            .header("X-Device-Model", Build.MODEL ?: "Android")
            .build()
        return executeJson(request)
    }

    private fun getPublicWithoutAuth(path: String): JSONObject {
        val request = Request.Builder()
            .url(publicBaseUrl + path.trimStart('/'))
            .get()
            .header("Accept", "application/json")
            .header("X-App-Version", BuildConfig.VERSION_NAME)
            .header("X-Device-Model", Build.MODEL ?: "Android")
            .build()
        return executeJson(request, clearAuthOnUnauthorized = false)
    }

    private fun Request.Builder.applyAuthHeaders(): Request.Builder {
        header("Accept", "application/json")
        header("Content-Type", "application/json")
        if (session.deviceToken.isNotBlank()) header("X-Device-Token", session.deviceToken)
        header("X-App-Version", BuildConfig.VERSION_NAME)
        header("X-Device-Model", Build.MODEL ?: "Android")
        if (session.sessionToken.isNotBlank()) header("X-Session-Token", session.sessionToken)
        if (session.accessToken.isNotBlank()) header("Authorization", "Bearer ${session.accessToken}")
        return this
    }

    private fun executeJson(request: Request, clearAuthOnUnauthorized: Boolean = true): JSONObject {
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val root = runCatching { JSONObject(text) }.getOrElse {
                val message = when {
                    text.contains("Only HTML requests are supported here", ignoreCase = true) ||
                        text.contains("<!DOCTYPE", ignoreCase = true) ||
                        text.contains("<html", ignoreCase = true) ->
                        "ERP 接口未命中：${request.url.encodedPath} 当前返回网页，请 Lovable 发布 JSON API"

                    text.isBlank() -> "ERP 返回空响应：${response.code}"
                    else -> text.take(120)
                }
                throw HandheldApiException("invalid_response", message, response.code)
            }
            if (!response.isSuccessful || !root.optBoolean("ok", false)) {
                val errorObject = root.optJSONObject("error")
                val errorText = when (val raw = root.opt("error")) {
                    is String -> raw
                    else -> null
                }
                val code = errorObject?.optString("code") ?: root.optString("code").ifBlank { "http_${response.code}" }
                val message = errorObject?.optString("message")
                    ?: errorText
                    ?: root.optString("message").ifBlank { null }
                    ?: root.optString("detail").ifBlank { "ERP 请求失败：${response.code}" }
                if (clearAuthOnUnauthorized && response.code == 401 && request.header("X-Device-Token") != null) {
                    session.clearAuth()
                }
                throw HandheldApiException(code = code, message = mapApiError(code, message), httpCode = response.code)
            }
            if (request.url.encodedPath.endsWith("/pos/sales") || request.url.encodedPath.endsWith("/pos/sales/recover/cancel")) {
                return parsePosCashEnvelope(text)
            }
            return root.optJSONObject("data") ?: JSONObject()
        }
    }

    private fun clientOpId(prefix: String): String = "$prefix-${UUID.randomUUID().toString().replace("-", "")}"

    private fun mapApiError(code: String, message: String): String {
        if (message.contains("Only HTML requests are supported here", ignoreCase = true)) {
            return "ERP 接口未命中：请确认 OTP JSON API 已发布"
        }
        return when (code) {
            "rate_limited" -> "发送过于频繁，请稍后再试"
            "invalid_phone" -> "手机号格式不正确"
            "sms_not_configured" -> "短信服务未配置，请联系管理员"
            "sms_send_failed" -> "短信发送失败，请稍后重试"
            "otp_not_found" -> "请先获取验证码"
            "otp_expired" -> "验证码已过期，请重新获取"
            "otp_invalid" -> "验证码不正确"
            "otp_locked" -> "验证码错误次数过多，请稍后再试"
            "user_not_found" -> "该手机号未绑定 ERP 账号"
            "unauthorized" -> if (message.contains("Phone logins are disabled", true)) "手机号登录未开启，请联系管理员" else message
            "ai_credits_exhausted", "rate_limited_ai", "http_402", "http_429" -> "AI 暂时繁忙，请稍后重试"
            else -> message
        }
    }

    private fun JSONObject.optDoubleOrNull(key: String): Double? =
        if (!has(key) || isNull(key)) null else optDouble(key)

    private fun JSONObject.optIntOrNull(key: String): Int? =
        if (!has(key) || isNull(key)) null else optInt(key)

    private fun parseLocations(items: JSONArray): List<HandheldLocation> = buildList {
        for (index in 0 until items.length()) {
            val location = items.getJSONObject(index).toLocation()
            if (!location.isYouzanShellLocation()) add(location)
        }
    }

    private fun parseStringSet(items: JSONArray): Set<String> = buildSet {
        for (index in 0 until items.length()) add(items.optString(index))
    }.filter { it.isNotBlank() }.toSet()

    private fun JSONArray?.orEmptyObjects(): List<JSONObject> = buildList {
        val array = this@orEmptyObjects ?: return@buildList
        for (index in 0 until array.length()) {
            array.optJSONObject(index)?.let(::add)
        }
    }

    private fun JSONArray?.orEmptyStrings(): List<String> = buildList {
        val array = this@orEmptyStrings ?: return@buildList
        for (index in 0 until array.length()) {
            val value = array.optString(index)
            if (value.isNotBlank()) add(value)
        }
    }

    private fun JSONObject.toParcelRow(): ParcelRow {
        val firstItem = optJSONObject("first_item")
            ?: optJSONArray("items")?.optJSONObject(0)
            ?: JSONObject()
        return ParcelRow(
            id = optionalString("id").ifBlank { optionalString("parcel_id") },
            trackingNo = optionalString("tracking_no").ifBlank { optionalString("international_tracking_no") },
            sourceOrderNo = optionalString("source_order_no").ifBlank { optionalString("order_no") },
            firstItemName = optionalString("first_item_name")
                .ifBlank { firstItem.optionalString("item_title_cn") }
                .ifBlank { firstItem.optionalString("item_title") }
                .ifBlank { firstItem.optionalString("name") }
                .ifBlank { firstItem.optionalString("title") }
                .ifBlank { "未命名商品" },
            firstImageUrl = extractImageUrl().ifBlank { firstItem.extractImageUrl() },
            seller = optionalString("seller"),
            warehouseLocation = optionalString("warehouse_location").ifBlank { optionalString("location") },
            status = optionalString("status"),
            isProblem = optBoolean("is_problem", false),
            grandTotalCny = optNumberAsDouble("grand_total_cny").orElseKeys(this, "total_cny", "landed_cny"),
            avgUnitCny = optNumberAsDouble("avg_unit_cny"),
            itemCount = optInt("item_count", optJSONArray("items")?.length() ?: 0),
            totalQty = optInt("total_qty", optInt("quantity", 0)),
            purchasedAt = optionalString("purchased_at"),
            paidAt = optionalString("paid_at"),
            receivedAt = optionalString("received_at"),
            createdAt = optionalString("created_at").ifBlank { optionalString("added_at") },
            note = optionalString("note").ifBlank { optionalString("remarks") },
            internationalFreightCny = optNumberAsDouble("international_freight_cny").orElseKeys(this, "freight_cny", "shipping_cny"),
            tariffCny = optNumberAsDouble("tariff_cny").orElseKeys(this, "duty_cny"),
            goodsTotalCny = optNumberAsDouble("goods_total_cny").orElseKeys(this, "item_total_cny"),
            weight = optionalString("weight").ifBlank { optionalString("weight_g") },
            systemCode = optionalString("system_code").ifBlank { optionalString("code") },
        )
    }

    private fun JSONObject.toParcelItem(fallbackParcelId: String = ""): ParcelItem {
        val landed = optJSONObject("landed") ?: JSONObject()
        val imageUrl = extractImageUrl()
        val qty = optInt("quantity", optInt("qty", 1)).coerceAtLeast(1)
        val itemTotal = optNumberAsDouble("item_total_cny").orElseKeys(this, "total_cny", "subtotal_cny")
        return ParcelItem(
            id = optionalString("id").ifBlank { optionalString("item_id") },
            parcelId = optionalString("parcel_id").ifBlank { fallbackParcelId },
            name = optionalString("item_title_cn")
                .ifBlank { optionalString("cn_name") }
                .ifBlank { optionalString("name") }
                .ifBlank { optionalString("item_title") }
                .ifBlank { optionalString("title") }
                .ifBlank { "未命名商品" },
            originalName = optionalString("item_title")
                .ifBlank { optionalString("original_name") }
                .ifBlank { optionalString("original_title") }
                .ifBlank { optionalString("title_original") },
            imageUrl = imageUrl,
            subOrderNo = optionalString("sub_order_no").ifBlank { optionalString("source_item_no") },
            systemCode = optionalString("system_code").ifBlank { optionalString("sku_code") }.ifBlank { optionalString("code") },
            addedBy = optionalString("added_by").ifBlank { optionalString("created_by") }.ifBlank { optionalString("parcel_created_by") },
            addedAt = optionalString("added_at").ifBlank { optionalString("created_at") },
            quantity = qty,
            itemTotalCny = itemTotal,
            avgCny = optNumberAsDouble("avg_cny") ?: itemTotal?.let { it / qty },
            landedCny = optNumberAsDouble("landed_cny") ?: landed.optNumberAsDouble("landed_cny"),
            piecePriceCny = optNumberAsDouble("piece_price_cny"),
            piecePriceJpy = optNumberAsDouble("piece_price_jpy"),
            packPieces = optIntOrNull("pack_pieces"),
            packPiecesSource = optionalString("pack_pieces_source"),
            packUnitNote = optionalString("pack_unit_note").ifBlank { optionalString("unit") },
            jpySubtotal = optNumberAsDouble("jpy_subtotal").orElseKeys(this, "subtotal_jpy", "item_total_jpy"),
            unitPriceJpy = optNumberAsDouble("unit_price_jpy").orElseKeys(this, "price_jpy"),
            weight = optionalString("weight").ifBlank { optionalString("weight_g") },
            exchangeRate = optNumberAsDouble("exchange_rate").orElseKeys(landed, "exchange_rate"),
            serviceFeeCny = optNumberAsDouble("service_fee_cny").orElseKeys(landed, "service_fee_cny"),
            domesticShippingCny = optNumberAsDouble("domestic_shipping_cny").orElseKeys(landed, "domestic_shipping_cny"),
            shippingAdjustmentCny = optNumberAsDouble("shipping_adjustment_cny").orElseKeys(landed, "shipping_adjustment_cny"),
            tariffCategory = optionalString("tariff_category").ifBlank { landed.optionalString("tariff_category") },
            taxRate = optNumberAsDouble("tax_rate").orElseKeys(landed, "tax_rate"),
            tariffJpy = optNumberAsDouble("tariff_jpy").orElseKeys(landed, "tariff_jpy"),
            allocatedFreightCny = optNumberAsDouble("allocated_freight_cny").orElseKeys(landed, "allocated_freight_cny", "freight_share_cny"),
            tariffCny = optNumberAsDouble("tariff_cny").orElseKeys(landed, "tariff_cny"),
            paymentMethod = optionalString("payment_method").ifBlank { optionalString("pay_method") },
            paidAt = optionalString("paid_at").ifBlank { optionalString("payment_at") }.ifBlank { optionalString("pay_at") },
            merchantOrderNo = optionalString("merchant_order_no").ifBlank { optionalString("seller_order_no") },
            platform = optionalString("platform").ifBlank { optionalString("source_platform") },
            condition = optionalString("condition").ifBlank { optionalString("condition_grade") },
            extraService = optionalString("extra_service").ifBlank { optionalString("additional_service") }.ifBlank { optionalString("addon_service") },
            note = optionalString("note").ifBlank { optionalString("notes") }.ifBlank { optionalString("remarks") },
        )
    }

    private fun JSONObject.toParcelTotals(): ParcelTotals =
        ParcelTotals(
            goodsTotalCny = optNumberAsDouble("goods_total_cny").orElseKeys(this, "item_total_cny"),
            freightCny = optNumberAsDouble("freight_cny").orElseKeys(this, "international_freight_cny"),
            tariffCny = optNumberAsDouble("tariff_cny"),
            grandTotalCny = optNumberAsDouble("grand_total_cny").orElseKeys(this, "total_cny"),
            totalQty = optInt("total_qty", optInt("quantity", 0)),
            itemCount = optInt("item_count", 0),
        )

    private fun JSONObject.toPackPiecesResult(): PackPiecesResult =
        PackPiecesResult(
            id = optionalString("id"),
            packPieces = optIntOrNull("pack_pieces"),
            packPiecesSource = optionalString("pack_pieces_source"),
            packUnitNote = optionalString("pack_unit_note"),
            piecePriceCny = optNumberAsDouble("piece_price_cny"),
            piecePriceJpy = optNumberAsDouble("piece_price_jpy"),
        )

    private fun JSONObject.toPackPiecesEstimate(): PackPiecesEstimate =
        PackPiecesEstimate(
            pieces = optIntOrNull("pieces"),
            confidence = optNumberAsDouble("confidence"),
            reasoning = optionalString("reasoning"),
            unit = optionalString("unit"),
        )

    private fun JSONObject.extractImageUrl(): String {
        val firstImage = optJSONArray("images")?.optJSONObject(0)
        val imageObject = optJSONObject("image")
        val coverObject = optJSONObject("cover")
        return optionalString("image_url")
            .ifBlank { optionalString("imageUrl") }
            .ifBlank { optionalString("item_image_url") }
            .ifBlank { optionalString("first_image_url") }
            .ifBlank { optionalString("thumbnail_url") }
            .ifBlank { optionalString("thumb_url") }
            .ifBlank { optionalString("main_image_url") }
            .ifBlank { optionalString("cover_image_url") }
            .ifBlank { firstImage?.optionalString("image_url").orEmpty() }
            .ifBlank { firstImage?.optionalString("url").orEmpty() }
            .ifBlank { imageObject?.optionalString("image_url").orEmpty() }
            .ifBlank { imageObject?.optionalString("url").orEmpty() }
            .ifBlank { coverObject?.optionalString("image_url").orEmpty() }
            .ifBlank { coverObject?.optionalString("url").orEmpty() }
    }

    private fun Double?.orElseKeys(source: JSONObject, vararg keys: String): Double? =
        this ?: keys.firstNotNullOfOrNull { source.optNumberAsDouble(it) }

    private fun JSONObject.toTransferSummary(): TransferSummary =
        TransferSummary(
            id = optionalString("id"),
            code = optionalString("code"),
            status = optionalString("status"),
            qty = optInt("qty", optInt("quantity", 0)),
            fromLocationId = optionalString("from_location_id"),
            toLocationId = optionalString("to_location_id"),
            shippedAt = optionalString("shipped_at"),
            receivedAt = optionalString("received_at"),
            createdAt = optionalString("created_at"),
            notes = optionalString("notes"),
        )

    private fun JSONObject.toStocktakeSummaryItem(): StocktakeSummaryItem =
        StocktakeSummaryItem(
            id = optionalString("id"),
            code = optionalString("code"),
            status = optionalString("status"),
            openedAt = optionalString("opened_at"),
            submittedAt = optionalString("submitted_at"),
            reviewedAt = optionalString("reviewed_at"),
            notes = optionalString("notes"),
        )

    private fun JSONObject.toErpSkuItem(productStocks: List<ProductStock> = emptyList()): ErpSkuItem {
        val images = optJSONArray("images")
        val firstImage = images?.optJSONObject(0)
        val firstImageString = images?.optString(0).orEmpty().takeIf { it.startsWith("http") || it.startsWith("sku-") }.orEmpty()
        val imageObject = optJSONObject("image")
        val coverObject = optJSONObject("cover_image")
        val imageUrl = optionalString("image_url")
            .ifBlank { optionalString("imageUrl") }
            .ifBlank { optionalString("read_url") }
            .ifBlank { optionalString("signed_url") }
            .ifBlank { optionalString("url") }
            .ifBlank { optionalString("cover_image_url") }
            .ifBlank { optionalString("thumbnail_url") }
            .ifBlank { optionalString("thumb_url") }
            .ifBlank { optionalString("main_image_url") }
            .ifBlank { firstImage?.optionalString("image_url").orEmpty() }
            .ifBlank { firstImage?.optionalString("imageUrl").orEmpty() }
            .ifBlank { firstImage?.optionalString("read_url").orEmpty() }
            .ifBlank { firstImage?.optionalString("signed_url").orEmpty() }
            .ifBlank { firstImage?.optionalString("url").orEmpty() }
            .ifBlank { firstImage?.optionalString("public_url").orEmpty() }
            .ifBlank { imageObject?.optionalString("image_url").orEmpty() }
            .ifBlank { imageObject?.optionalString("read_url").orEmpty() }
            .ifBlank { imageObject?.optionalString("signed_url").orEmpty() }
            .ifBlank { imageObject?.optionalString("url").orEmpty() }
            .ifBlank { coverObject?.optionalString("image_url").orEmpty() }
            .ifBlank { coverObject?.optionalString("read_url").orEmpty() }
            .ifBlank { coverObject?.optionalString("signed_url").orEmpty() }
            .ifBlank { coverObject?.optionalString("url").orEmpty() }
            .ifBlank { firstImageString }
        val price = optNumberAsDouble("price_tier")
            ?: optNumberAsDouble("price")
            ?: optNumberAsDouble("price_cny")
            ?: optNumberAsDouble("priceCny")
            ?: optNumberAsDouble("sale_price")
            ?: 0.0
        val type = optionalString("product_type")
            .ifBlank { optionalString("productType") }
            .ifBlank { optionalString("type") }
            .ifBlank { if (optBoolean("is_custom_price", false)) "custom" else "standard" }
        val stockQty = optInt("total_stock_qty", optInt("stock_qty", optInt("stock", 0)))
        val isUnlimitedStock = optBoolean("is_unlimited_stock", false)
        val listingStatus = optionalString("listing_status").ifBlank {
            if (isUnlimitedStock || stockQty > 0) "selling" else "sold_out"
        }
        return ErpSkuItem(
            id = optionalString("id").ifBlank { optionalString("sku_id") },
            skuCode = optionalString("sku_code").ifBlank { optionalString("barcode") },
            name = optionalString("name").ifBlank { "未命名商品" },
            category = mapCategoryToDisplay(optionalString("category")),
            priceCents = (price * 100).toInt(),
            stockQty = stockQty,
            conditionGrade = optionalString("condition_grade").ifBlank { optionalString("grade") }.ifBlank { "A" },
            imageUrl = imageUrl,
            notes = optionalString("notes"),
            productType = type,
            isDisplay = optBoolean("is_display", true),
            listingStatus = listingStatus,
            statusLabel = optionalString("status_label").ifBlank {
                statusLabelFor(listingStatus)
            },
            canRestock = optBoolean("can_restock", false),
            editable = if (has("editable")) optBoolean("editable", true) else type != "standard",
            isUnlimitedStock = isUnlimitedStock,
            imageProcessingStatus = optionalString("image_processing_status").ifBlank { "idle" },
            productStocks = productStocks,
            brand = optionalString("brand"),
            era = optionalString("era"),
            ipName = optionalString("ip_character"),
            material = optionalString("material"),
            fankuangOverride = opt("fankuang_override") as? Boolean,
            fankuangMembership = opt("in_fankuang") as? Boolean,
            canEdit = opt("can_edit") as? Boolean,
            updatedAt = optionalString("updated_at"),
        )
    }

    private fun JSONObject.toGlobalStockData(): GlobalStockData {
        val locations = optJSONArray("locations").orEmptyObjects().mapNotNull { it.toLocationOrNull() }
        val items = optJSONArray("items").orEmptyObjects().map { item ->
            val stocksObject = item.optJSONObject("stocks") ?: JSONObject()
            val stocks = buildMap {
                stocksObject.keys().forEach { key -> put(key, stocksObject.optInt(key, 0)) }
            }
            val price = item.optNumberAsDouble("price") ?: item.optNumberAsDouble("price_tier") ?: 0.0
            GlobalStockItem(
                skuId = item.optionalString("sku_id").ifBlank { item.optionalString("id") },
                name = item.optionalString("name").ifBlank { "未命名商品" },
                skuCode = item.optionalString("sku_code"),
                barcode = item.optionalString("barcode"),
                category = mapCategoryToDisplay(item.optionalString("category")),
                productType = item.optionalString("product_type"),
                imageUrl = item.optionalString("image_url"),
                priceCents = (price * 100).toInt(),
                totalQty = item.optInt("total_qty", 0),
                stocks = stocks,
                isDisplay = item.optBoolean("is_display", true),
                listingStatus = item.optionalString("listing_status").ifBlank {
                    if (item.optInt("total_qty", 0) <= 0) "sold_out" else "selling"
                },
                statusLabel = item.optionalString("status_label").ifBlank {
                    statusLabelFor(item.optionalString("listing_status"))
                },
                isUnlimitedStock = item.optBoolean("is_unlimited_stock", false),
            )
        }
        val summary = optJSONObject("summary") ?: JSONObject()
        return GlobalStockData(
            locations = locations,
            items = items,
            summary = GlobalStockSummary(
                skuCount = summary.optInt("sku_count", 0),
                totalQty = summary.optInt("total_qty", 0),
                outOfStock = summary.optInt("out_of_stock", 0),
                lowStock = summary.optInt("low_stock", 0),
            ),
            page = optInt("page", 1),
            pageSize = optInt("page_size", 50),
            total = optInt("total", items.size),
        )
    }

    private fun statusLabelFor(status: String): String =
        when (status) {
            "selling" -> "销售中"
            "sold_out" -> "已售罄"
            "in_warehouse" -> "仓库中"
            else -> "销售中"
        }

    private fun JSONObject.toLabelTemplate(): LabelTemplate {
        val printType = PrintTemplateType.fromApiValue(optionalString("print_type").ifBlank { optionalString("printType") })
        return LabelTemplate(
            id = optionalString("id").ifBlank { "default" },
            templateName = optionalString("name").ifBlank { optionalString("templateName") }.ifBlank { "默认模板" },
            printType = printType,
            widthMm = optInt("width_mm", optInt("widthMm", 53)),
            heightMm = optInt("height_mm", optInt("heightMm", 35)),
            shopName = optionalString("shopName").ifBlank { LabelTemplate().shopName },
            footer = optionalString("footer").ifBlank { LabelTemplate().footer },
            showDescription = if (has("showDescription")) optBoolean("showDescription", true) else true,
            elements = parseLabelElements(optJSONArray("elements"), printType),
        ).normalizedForPrint()
    }

    private fun LabelTemplate.toLabelTemplateBody(isDefault: Boolean? = null): JSONObject =
        JSONObject()
            .put("name", templateName)
            .put("print_type", printType.apiValue)
            .put("width_mm", normalizedForPrint().widthMm)
            .put("height_mm", heightMm)
            .put("elements", serializeLabelElements(elements))
            .apply {
                if (isDefault != null) put("is_default", isDefault)
            }

    private fun parseLabelElements(array: JSONArray?, printType: PrintTemplateType): List<LabelElement> {
        if (array == null || array.length() == 0) {
            return if (printType == PrintTemplateType.RECEIPT) defaultReceiptElements() else defaultLabelElements()
        }
        return buildList {
            for (index in 0 until array.length()) {
                val json = array.getJSONObject(index)
                val rawType = json.optString("type").trim().uppercase(Locale.ROOT)
                val type = if (rawType == "ITEM_LINES") {
                    LabelElementType.DESCRIPTION
                } else {
                    runCatching { LabelElementType.valueOf(rawType) }.getOrDefault(LabelElementType.CUSTOM_TEXT)
                }
                add(
                    LabelElement(
                        id = json.optString("id", "el_$index"),
                        type = type,
                        x = json.optDouble("x", 0.0).toFloat(),
                        y = json.optDouble("y", 0.0).toFloat(),
                        width = json.optDouble("width", 80.0).toFloat(),
                        height = json.optDouble("height", 24.0).toFloat(),
                        textSize = json.optDouble("textSize", json.optDouble("text_size", 16.0)).toFloat(),
                        bold = json.optBoolean("bold", false),
                        enabled = json.optBoolean("enabled", true),
                        customText = if (type == LabelElementType.IMAGE) "" else json.optString("customText", json.optString("custom_text", "")),
                        align = json.optString("align", TEXT_ALIGN_CENTER),
                        fontFamily = json.optString("fontFamily", json.optString("font_family", FONT_SANS)),
                        italic = json.optBoolean("italic", false),
                        underline = json.optBoolean("underline", false),
                        boxed = json.optBoolean("boxed", false),
                    ),
                )
            }
        }
    }

    private fun serializeLabelElements(elements: List<LabelElement>): JSONArray =
        JSONArray().also { array ->
            elements.forEach { element ->
                array.put(
                    JSONObject()
                        .put("id", element.id)
                        .put("type", element.type.name)
                        .put("x", element.x)
                        .put("y", element.y)
                        .put("width", element.width)
                        .put("height", element.height)
                        .put("textSize", element.textSize)
                        .put("bold", element.bold)
                        .put("enabled", element.enabled)
                        .put("customText", element.customText)
                        .put("align", element.align)
                        .put("fontFamily", element.fontFamily)
                        .put("italic", element.italic)
                        .put("underline", element.underline)
                        .put("boxed", element.boxed),
                )
            }
        }

    private fun JSONObject.toLocation(): HandheldLocation =
        HandheldLocation(
            id = getString("id"),
            name = getString("name"),
            kind = optString("kind", "shop"),
        )

    private fun JSONObject.toLocationOrNull(): HandheldLocation? {
        val id = optionalString("id")
        val name = optionalString("name")
        if (id.isBlank() || name.isBlank()) return null
        return HandheldLocation(id = id, name = name, kind = optString("kind", "shop"))
    }

    private fun JSONObject.toFlatLocation(): HandheldLocation? {
        val id = optionalString("location_id")
        val name = optionalString("location_name")
        val kind = optionalString("location_kind")
        if (id.isBlank() || name.isBlank() || kind.isBlank()) return null
        return HandheldLocation(id = id, name = name, kind = kind)
    }

    private fun HandheldLocation.isYouzanShellLocation(): Boolean {
        val normalized = name.lowercase()
            .replace("-", " ")
            .replace("·", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        return normalized == "boomer off vintage" ||
            normalized == "boomer off" ||
            normalized == "vintage"
    }

    private fun String.urlPathSafe(): String = replace("/", "%2F").replace("#", "%23").replace("?", "%3F")

    private fun String.urlQuerySafe(): String = URLEncoder.encode(this, Charsets.UTF_8.name())

    private fun JSONObject.optNumberAsDouble(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        val value = opt(key)
        return when (value) {
            is Number -> value.toDouble()
            is String -> value.replace("¥", "").trim().toDoubleOrNull()
            else -> null
        }
    }

    private fun JSONObject.optMoneyCents(key: String): Int =
        ((optNumberAsDouble(key) ?: 0.0) * 100.0).roundToInt()

    private fun JSONObject.toPosProduct(): PosProduct = PosProduct(
        skuId = optionalString("sku_id").ifBlank { optionalString("id") },
        name = optionalString("name"),
        unitPriceCents = optMoneyCents("unit_price"),
        availableQty = optInt("available_qty", 0),
        productType = PosProductType.fromWire(optionalString("product_type")),
        skuCode = optionalString("sku_code"),
        barcode = optionalString("barcode"),
        epc = optionalString("epc"),
        conditionGrade = optionalString("condition_grade"),
        imageUrl = optionalString("image_url"),
        locationId = optionalString("location_id"),
        saleOwnership = optionalString("sale_ownership").ifBlank { "owned" },
        discountEligible = !has("discount_eligible") || optBoolean("discount_eligible", true),
        isUnlimitedStock = optBoolean("is_unlimited_stock", false),
    )

    private fun JSONObject.toPosShift(): PosShift {
        val register = optJSONObject("register") ?: JSONObject()
        return PosShift(
            id = optionalString("id"),
            locationId = optionalString("location_id"),
            status = optionalString("status").ifBlank { "open" },
            registerName = register.optionalString("name").ifBlank { "移动收银" },
        )
    }

    private fun JSONObject.toPosPaymentAttempt(): PosPaymentAttempt {
        val receiptJson = optJSONObject("receipt")
        return PosPaymentAttempt(
            id = optionalString("id"),
            provider = optionalString("provider"),
            mode = PosPaymentMode.fromWire(optionalString("mode")),
            status = PosPaymentStatus.fromWire(optionalString("status")),
            amountCents = optMoneyCents("amount"),
            outTradeNo = optionalString("out_trade_no"),
            providerTransactionId = optionalString("provider_transaction_id"),
            qrContent = optionalString("qr_content").ifBlank { optionalString("code_url") },
            expiresAt = optionalString("expires_at"),
            message = optionalString("message"),
            receipt = receiptJson?.toPosReceipt(),
        )
    }

    private fun JSONObject.toPosReceipt(): PosReceipt =
        PosReceipt(
            orderId = optionalString("order_id").ifBlank { optionalString("id") },
            orderNo = optionalString("order_no"),
            receiptNo = optionalString("receipt_no"),
            totalCents = optMoneyCents("total_amount").takeIf { it > 0 } ?: optMoneyCents("total"),
            paymentProvider = optionalString("payment_provider").ifBlank { optionalString("provider") },
            providerTransactionId = optionalString("provider_transaction_id"),
            paidAt = optionalString("paid_at"),
            locationName = optionalString("location_name"),
            cashierName = optionalString("cashier_name"),
            subtotalCents = optMoneyCents("subtotal"),
            discountCents = optMoneyCents("discount_total"),
            items = optJSONArray("items").orEmptyObjects().map { line ->
                PosReceiptLine(
                    name = line.optionalString("name"),
                    skuCode = line.optionalString("sku_code"),
                    quantity = line.optInt("quantity", 1),
                    unitPriceCents = line.optMoneyCents("unit_price"),
                    lineTotalCents = line.optMoneyCents("line_total"),
                )
            },
            customerName = optionalString("customer_name"),
        )

    private fun mapCategoryToDisplay(category: String): String =
        when (category) {
            "jp_porcelain" -> "日瓷 · 器皿"
            "eu_porcelain" -> "欧瓷 · 器皿"
            "vintage_toy" -> "玩具 · 中古玩具"
            "anime_goods" -> "动漫周边"
            "media" -> "唱片书影音"
            "digital" -> "相机 · 数码"
            "jewelry" -> "饰品 · 珠宝"
            "fashion" -> "服饰箱包"
            "antique" -> "古董摆件"
            "ai_low_confidence" -> "AI低置信度 · 待确认"
            "new_category_candidate" -> "新品类候选 · 待确认"
            "compliance_review" -> "合规待审"
            else -> category.ifBlank { "日用杂货" }
        }

    private fun JSONObject.optionalString(key: String): String =
        if (!has(key) || isNull(key)) "" else optString(key).takeUnless { it == "null" }.orEmpty()
}
