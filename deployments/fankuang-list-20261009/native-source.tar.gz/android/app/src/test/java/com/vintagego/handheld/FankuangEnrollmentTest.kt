package com.vintagego.handheld

import org.junit.Assert.*
import org.junit.Test

class FankuangEnrollmentTest {
    @Test fun listBadgeUsesCanonicalMembership() {
        val item = Item(itemNo = "a", name = "杯", priceCents = 990, category = "cup", imagePath = "", fankuangOverride = false)
        assertFalse(item.inFankuang)
        assertTrue(item.copy(fankuangMembership = true, priceCents = 19900).inFankuang)
        assertFalse(item.copy(fankuangMembership = true, productType = "standard").inFankuang)
        assertFalse(item.copy(fankuangMembership = true, isUnlimitedStock = true).inFankuang)
    }
    @Test fun filteredQueryHasSeparateCacheAndPreservesScope() {
        val scope = ProductScope(1, "staff", "xtd", "shop", setOf("xtd"), setOf("shop_manager"))
        val all = ProductQuery(q = "杯", status = "sold_out")
        val filtered = all.copy(onlyFankuang = true)
        assertNotEquals(ProductCacheKey(scope, all), ProductCacheKey(scope, filtered))
        assertTrue(filtered.path(scope).contains("fankuang=1"))
        assertTrue(filtered.path(scope).contains("location_id=xtd"))
        assertTrue(filtered.path(scope).contains("status=sold_out"))
        assertFalse(all.path(scope).contains("fankuang="))
        assertTrue(filtered.path(scope, page = 3).contains("page=3"))
        assertTrue(filtered.path(scope, page = 3).contains("fankuang=1"))
        val wrong = org.json.JSONObject("""{"scope":"location:xtd","counts":{"custom":1,"bundle":0,"standard":0,"all":1},"items":[{"product_type":"custom","in_fankuang":false,"stocks":[{"location_id":"xtd","stock_qty":1}]}]}""")
        assertThrows(ProductScopeException::class.java) { validateProductResponse(wrong, scope, onlyFankuang = true) }
    }
    @Test fun automaticBoundaryAndManualPriority() {
        assertTrue(fankuangEnrollment("49.9", null))
        assertFalse(fankuangEnrollment("49.91", null))
        assertFalse(fankuangEnrollment("50", null))
        assertFalse(fankuangEnrollment("", null))
        assertFalse(fankuangEnrollment("9.9", false))
        assertTrue(fankuangEnrollment("199", true))
        assertFalse(fankuangEnrollment("9.9", true, "standard"))
    }
}
