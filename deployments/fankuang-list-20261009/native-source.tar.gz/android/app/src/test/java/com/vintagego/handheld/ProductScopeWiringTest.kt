package com.vintagego.handheld

import java.io.File
import org.junit.Assert.*
import org.junit.Test

class ProductScopeWiringTest {
    private fun source(name: String) = File("src/main/java/com/vintagego/handheld/$name.kt").readText()
    private fun method(source: String, name: String) = source.substringAfter("fun $name(")
        .substringBefore("\n    fun ").substringBefore("\n    private fun ")

    @Test fun `product request has one explicit scoped route with no global stock fallback`() {
        val api = source("HandheldApiClient")
        val products = method(api, "products")
        assertTrue(products.contains("query.path(scope)"))
        assertTrue(products.contains("validateProductResponse(data, scope, query.onlyFankuang)"))
        assertTrue(products.contains("validateProductResponse(next, scope, query.onlyFankuang)"))
        assertTrue(products.contains("query.path(scope, page = ++page)"))
        assertTrue(products.contains("requireProductSession(scope)"))
        assertFalse(api.contains("fun scopedProducts("))
        val load = method(source("MainViewModel"), "loadProductsFromErp")
        assertFalse(load.contains("skuSearch"))
        assertFalse(load.contains("store.all()"))
        assertTrue(load.contains("productScope()"))
    }

    @Test fun `product reset covers account location and auth loss`() {
        val vm = source("MainViewModel")
        for (name in listOf("handleLoginSuccess", "switchLocation", "loadLocations", "logout", "handleAuthLost")) {
            assertTrue(name, method(vm, name).contains("resetProducts()"))
        }
        assertFalse(vm.contains("items = store.all()"))
        assertTrue(vm.contains("ProductCacheKey"))
        assertTrue(vm.contains("productRequestVersion.get()"))
    }

    @Test fun `only product scope selector changes not bottom navigation`() {
        val ui = source("CleanRetailScreens")
        val products = ui.substringAfter("fun CleanProductsScreen(").substringBefore("private fun ProductTypeTab")
        assertTrue(products.contains("state.canShowHQTools"))
        assertTrue(products.contains("vm.selectProductScope(ProductViewScope.Current)"))
        assertTrue(products.contains("vm.selectProductScope(ProductViewScope.All)"))
        assertTrue(products.contains("bottomBar = { CleanBottomNav(vm, AppScreen.Products) }"))
        assertTrue(products.contains("productLocationBadges(item.productStocks)"))
        assertTrue(ui.contains("SecondTabNav(vm, active)"))
        assertTrue(ui.contains("NavItem(Icons.Default.Home, \"首页\", active == AppScreen.Dashboard)"))
        assertTrue(ui.contains("NavItem(Icons.Default.Notifications, \"消息\", active == AppScreen.Notifications)"))
        assertTrue(ui.contains("NavItem(Icons.Default.Person, \"我的\", active == AppScreen.Profile)"))
    }

    @Test fun `unscoped mutation responses cannot populate product cache`() {
        val vm = source("MainViewModel")
        for (name in listOf("setSelectedItemDisplay", "restockSelectedItem")) {
            assertTrue(name, method(vm, name).contains("cacheKey.accepts("))
            assertTrue(name, method(vm, name).contains("reloadSelectedProductDetail()"))
        }
        assertFalse(vm.contains("listOf(item) + list"))
        assertFalse(vm.contains("entry.copy(items = cacheItems)"))
    }

    @Test fun `product details require explicit scope and real ERP id and reject late results`() {
        val api = method(source("HandheldApiClient"), "itemDetail")
        assertTrue(api.contains("scope: ProductScope"))
        assertTrue(api.contains("productDetailPath(scope, id)"))
        assertTrue(api.contains("validateProductDetail(data, scope, id)"))
        val vm = source("MainViewModel")
        assertTrue(method(vm, "selectItem").contains("item.erpId"))
        assertTrue(method(vm, "loadProductDetail").contains("acceptsProductDetail("))
        assertTrue(method(vm, "navigate").contains("productDetailRequestVersion.incrementAndGet()"))
    }
}
