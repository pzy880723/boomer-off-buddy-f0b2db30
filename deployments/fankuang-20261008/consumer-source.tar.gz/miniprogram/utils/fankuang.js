const TAGS = ['翻框乐', '翻筐乐'];
function eligible(product) {
  if (!product || !product.id || product.price == null || product.price === '') return false;
  const price = Number(product.price), stock = Number(product.stock);
  if (!Number.isFinite(price) || price < 0 || !Number.isFinite(stock) || stock < 1) return false;
  if (product.status && !['active', 'published', 'on_sale', 'available'].includes(product.status)) return false;
  if (product.product_type === 'standard' || product.type === 'standard') return false;
  if (typeof product.in_fankuang === 'boolean') return product.in_fankuang;
  if (typeof product.fankuang_override === 'boolean') return product.fankuang_override;
  const labels = [...(product.keywords || []), ...(product.tags || []), ...(product.facets || [])];
  return price <= 49.9 || labels.some(tag => TAGS.includes(typeof tag === 'string' ? tag : tag.name));
}
function createFlipFeed(api) {
  const streams = [{ fankuang: 1 }].map(filters => ({ filters, page: 1, done: false }));
  const seen = new Set();
  let pending;
  const feed = {
    partialError: false,
    hasMore: () => streams.some(stream => !stream.done),
    next(onRows) {
      if (pending) return pending;
      pending = (async () => {
        const active = streams.filter(stream => !stream.done);
        const collected = [];
        const results = await Promise.all(active.map(async stream => {
          try {
            const response = await api.listProducts({ ...stream.filters, page: stream.page, page_size: 20 }, { force: true });
            const rows = response.data || [];
            const total = response.pagination?.total;
            stream.done = total == null ? rows.length < 20 : stream.page * 20 >= Number(total);
            stream.page++;
            const fresh = rows.filter(row => {
              if (!eligible(row) || seen.has(String(row.id))) return false;
              seen.add(String(row.id)); return true;
            });
            collected.push(...fresh);
            if (fresh.length && onRows) onRows(fresh);
            return { rows: fresh };
          } catch (error) { return { error }; }
        }));
        feed.partialError = results.some(result => result.error);
        if (results.length && results.every(result => result.error)) throw results[0].error;
        return collected;
      })().finally(() => { pending = null; });
      return pending;
    }
  };
  return feed;
}
function swipeChoice(dx, dy) {
  if (Math.abs(dx) < 65 || Math.abs(dx) < Math.abs(dy) * 1.3) return 'none';
  return dx > 0 ? 'like' : 'skip';
}
function pullAction(distance) { return distance >= 160 ? 'fankuang' : distance >= 65 ? 'refresh' : 'none'; }
module.exports = { eligible, createFlipFeed, swipeChoice, pullAction };
