const test = require('node:test');
const assert = require('node:assert/strict');
const { eligible, createFlipFeed, swipeChoice, pullAction } = require('../utils/fankuang');
const raw = (id, price = 39.9, extra = {}) => ({ id, price, stock: 1, ...extra });
test('automatic threshold and explicit choices respect availability', () => {
  assert.equal(eligible(raw('low', 49.9)), true);
  assert.equal(eligible(raw('gap', 49.91)), false);
  assert.equal(eligible(raw('edge', 50)), false);
  assert.equal(eligible(raw('excluded', 9.9, { in_fankuang: false, tags: ['翻筐乐'] })), false);
  assert.equal(eligible(raw('manual', 199, { in_fankuang: true })), true);
  assert.equal(eligible(raw('standard', 9.9, { in_fankuang: true, product_type: 'standard' })), false);
  assert.equal(eligible(raw('tag', 199, { keywords: ['翻框乐'] })), true);
  assert.equal(eligible(raw('facet', 199, { facets: [{ name: '翻筐乐' }] })), true);
  assert.equal(eligible(raw('title', 199, { name: '翻框乐玩具' })), false);
  for (const extra of [{ stock: 0 }, { stock: 'invalid' }, { status: 'offline' }, { price: null }, { price: -1 }]) assert.equal(eligible(raw('bad', 39.9, extra)), false);
});
test('canonical filtered feed requests fresh data and deduplicates', async () => {
  const calls = [];
  const feed = createFlipFeed({ listProducts: async (filters, options) => {
    calls.push(filters);
    assert.equal(options.force, true);
    return { data: [raw('manual', 199, { in_fankuang: true }), raw('low'), raw('low')], pagination: { total: 2 } };
  } });
  const rows = await feed.next();
  assert.deepEqual(rows.map(p => p.id).sort(), ['low', 'manual']);
  assert.deepEqual(calls, [{ fankuang: 1, page: 1, page_size: 20 }]);
  assert.equal(feed.hasMore(), false);
  assert.deepEqual(await feed.next(), []);
});
test('failed request retains page for retry', async () => {
  let fail = true;
  const pages = [];
  const feed = createFlipFeed({ listProducts: async f => {
    pages.push(f.page);
    if (fail) throw Error('offline');
    return { data: [raw('low')], pagination: { total: 1 } };
  } });
  await assert.rejects(feed.next(), /offline/);
  assert.equal(feed.hasMore(), true);
  fail = false;
  assert.deepEqual((await feed.next()).map(p => p.id), ['low']);
  assert.deepEqual(pages, [1, 1]);
});
test('all failed streams reject without falsely saying the basket is empty', async () => {
  const feed = createFlipFeed({ listProducts: async () => { throw Error('offline'); } });
  await assert.rejects(feed.next(), /offline/);
  assert.equal(feed.hasMore(), true);
});
test('gestures distinguish horizontal choice, vertical scrolling and refresh/deep pull', () => {
  assert.equal(swipeChoice(75, 10), 'like');
  assert.equal(swipeChoice(-75, 10), 'skip');
  assert.equal(swipeChoice(70, 90), 'none');
  assert.equal(swipeChoice(10, 0), 'none');
  assert.equal(pullAction(40), 'none');
  assert.equal(pullAction(85), 'refresh');
  assert.equal(pullAction(180), 'fankuang');
});
test('concurrent loads share the same request', async () => {
  let release;
  const slow = new Promise(resolve => { release = resolve; });
  let calls = 0;
  const feed = createFlipFeed({ listProducts: async () => { calls++; return slow; } });
  const partial = [];
  const pending = feed.next(rows => partial.push(...rows));
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(feed.next(), pending);
  release({data:[raw('tag',99,{in_fankuang:true}),raw('fast')],pagination:{total:2}});
  assert.deepEqual((await pending).map(row => row.id).sort(), ['fast','tag']);
  assert.deepEqual(partial.map(row => row.id).sort(), ['fast','tag']);
  assert.equal(calls, 1);
});
