import XCTest

final class ListingSummaryUITests: XCTestCase {
    @MainActor
    func testFankuangFollowsPriceUntilManuallyChanged() {
        let app = XCUIApplication()
        app.launchArguments = ["--test-listing-summary"]
        app.launch()
        XCTAssertTrue(app.staticTexts["商品信息确认"].waitForExistence(timeout: 15))
        let toggle = app.switches["listing-fankuang-toggle"]
        for _ in 0..<12 where !toggle.isHittable { app.swipeUp() }
        XCTAssertTrue(toggle.isHittable)
        XCTAssertEqual(toggle.value as? String, "0")
        let price = app.textFields["listing-price-editor"]
        func replacePrice(_ value: String) {
            price.tap()
            let count = (price.value as? String)?.count ?? 0
            price.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: count) + value)
        }
        replacePrice("49.9")
        XCTAssertEqual(toggle.value as? String, "1")
        toggle.tap()
        XCTAssertEqual(toggle.value as? String, "0")
        replacePrice("9.9")
        XCTAssertEqual(toggle.value as? String, "0")
        toggle.tap()
        replacePrice("199")
        XCTAssertEqual(toggle.value as? String, "1")
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "listing-fankuang-manual-high-price"
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor
    func testRefreshButtonBelowSummaryFillsBlankWithoutRestartingRecognition() {
        let app = XCUIApplication()
        app.launchArguments = ["--test-listing-summary"]
        app.launch()
        let button = app.buttons["listing-summary-refresh"]
        XCTAssertTrue(app.staticTexts["商品信息确认"].waitForExistence(timeout: 15))
        for _ in 0..<12 where !button.isHittable { app.swipeUp() }
        XCTAssertTrue(button.isHittable)
        let editor = app.textViews["listing-summary-editor"]
        XCTAssertGreaterThanOrEqual(button.frame.minY, editor.frame.maxY)
        button.tap()
        XCTAssertTrue(app.staticTexts["简介已更新"].waitForExistence(timeout: 5))
        XCTAssertEqual(editor.value as? String, "双子星图案收纳盒，让桌面小物整齐归位。")
        XCTAssertTrue(app.buttons["listing-summary-refresh"].isEnabled)
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "listing-summary-refreshed"
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
