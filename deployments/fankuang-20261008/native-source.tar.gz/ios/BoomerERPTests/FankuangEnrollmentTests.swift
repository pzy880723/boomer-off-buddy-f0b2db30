import XCTest
@testable import BOOMER_ERP

final class FankuangEnrollmentTests: XCTestCase {
    func testAutomaticBoundaryAndManualPriority() {
        var draft = ListingDraft()
        for (price, expected) in [("49.9", true), ("49.91", false), ("50", false), ("", false)] {
            draft.price = price
            XCTAssertEqual(draft.inFankuang, expected)
        }
        draft.fankuangOverride = false
        draft.price = "9.9"
        XCTAssertFalse(draft.inFankuang)
        draft.fankuangOverride = true
        draft.price = "199"
        XCTAssertTrue(draft.inFankuang)
    }

    func testRecognitionResetAndDraftRestorePreserveManualChoice() throws {
        var draft = ListingDraft()
        draft.price = "9.9"
        draft.fankuangOverride = false
        draft.clearRecognition()
        XCTAssertEqual(draft.fankuangOverride, false)
        draft.invalidateProcessedImages()
        XCTAssertEqual(draft.fankuangOverride, false)
        let restored = try JSONDecoder().decode(ListingDraft.self, from: JSONEncoder().encode(draft))
        XCTAssertFalse(restored.inFankuang)
        var legacy = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(draft)) as? [String: Any])
        legacy.removeValue(forKey: "fankuangOverride")
        let old = try JSONDecoder().decode(ListingDraft.self, from: JSONSerialization.data(withJSONObject: legacy))
        XCTAssertNil(old.fankuangOverride)
        XCTAssertTrue(old.inFankuang)
    }

    func testRequestFreezesOverrideAndEditSupportsAutomaticNull() throws {
        var draft = ListingDraft()
        draft.price = "9.9"
        draft.fankuangOverride = false
        try draft.prepareSubmission(locationID: "store", userID: "employee")
        let first = try XCTUnwrap(draft.submission)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: first.body) as? [String: Any])
        XCTAssertEqual(body["fankuang_override"] as? Bool, false)
        draft.fankuangOverride = true
        try draft.prepareSubmission(locationID: "store", userID: "employee")
        XCTAssertEqual(draft.submission?.body, first.body)
        let auto = ProductEditInput(name: "杯", price: "49.9", grade: "A", description: "")
        XCTAssertTrue(try auto.fields()["fankuang_override"] is NSNull)
        var manual = auto
        manual.fankuangOverride = false
        XCTAssertEqual(try manual.fields()["fankuang_override"] as? Bool, false)
    }
}
