import AVFoundation
import PhotosUI
import SwiftUI

enum ListingBackGesture {
    static func shouldReturn(startX: CGFloat, horizontal: CGFloat, vertical: CGFloat) -> Bool {
        startX <= 24 && horizontal > 70 && horizontal > abs(vertical) * 1.5
    }
}

struct ListingCameraGuide: Shape {
    static func previewHeight(in viewport: CGSize) -> CGFloat {
        max(300, min(viewport.width + 148, viewport.height - 224))
    }

    static func frame(in bounds: CGRect) -> CGRect {
        let side = max(0, min(bounds.width - 24, bounds.height - 208))
        return CGRect(x: bounds.midX - side / 2, y: bounds.midY - side / 2, width: side, height: side)
    }

    func path(in rect: CGRect) -> Path {
        RoundedRectangle(cornerRadius: 22, style: .continuous).path(in: Self.frame(in: rect))
    }
}

struct ListingFlowView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        Group {
            switch model.listingStage {
            case 1:
                ListingProcessingView()
            case 2:
                ListingConfirmView()
            default:
                ListingCaptureView()
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }
}

private struct ListingCaptureView: View {
    @EnvironmentObject private var model: AppModel
    @State private var cameraTrigger = 0
    @State private var cameraRetryTrigger = 0
    @State private var cameraState: CameraPreviewState = .starting
    @State private var selectedPhotos: [PhotosPickerItem] = []

    var body: some View {
        GeometryReader { proxy in
            let cameraHeight = ListingCameraGuide.previewHeight(in: proxy.size)
            VStack(spacing: 0) {
                HStack {
                    VStack(alignment: .leading, spacing: BORootHeader.subtitleSpacing) {
                        Text("拍照上架")
                            .font(BORootHeader.titleFont)
                        Text("单图即可识别，也可连续拍摄最多 6 个角度")
                            .font(BORootHeader.subtitleFont)
                            .foregroundStyle(BOColor.secondary)
                    }
                    Spacer()
                    Button("清空") { model.resetListing() }
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(BOColor.secondary)
                }
                .padding(.horizontal, BORootHeader.horizontalInset)
                .padding(.vertical, BORootHeader.topInset)

                ZStack {
                    CameraPreview(
                        trigger: $cameraTrigger,
                        retryTrigger: cameraRetryTrigger,
                        state: $cameraState,
                        isActive: model.selectedTab == 2
                    ) { image in
                        model.addCapturedImage(image)
                    }

                    if cameraState != .running {
                        cameraStatusOverlay
                    }

                    ListingCameraGuide()
                        .stroke(.white.opacity(0.5), lineWidth: 1)
                        .allowsHitTesting(false)

                    VStack {
                        HStack {
                            Text("\(model.listingDraft.images.count)/\(ListingCapturePlan.maximumImages)")
                                .font(.system(size: 12, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 11)
                                .frame(height: 32)
                                .background(.black.opacity(0.4))
                                .clipShape(Capsule())
                            Spacer()
                            Text(nextAngleHint)
                                .font(.system(size: 11, weight: .semibold, design: .rounded))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 11)
                                .frame(height: 32)
                                .background(.black.opacity(0.4))
                                .clipShape(Capsule())
                        }
                        Text("点击商品对焦 · 双指缩放；过近时稍微后退")
                            .font(.system(size: 11))
                            .foregroundStyle(.white)
                            .padding(6)
                            .background(.black.opacity(0.4), in: Capsule())
                            .allowsHitTesting(false)
                        Spacer()
                        cameraControls
                    }
                    .padding(16)
                }
                .frame(height: cameraHeight)
                .background(Color.black)
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .padding(.horizontal, 18)

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 9) {
                        ForEach(Array(model.listingDraft.images.enumerated()), id: \.offset) { index, data in
                            ZStack {
                                if let image = UIImage(data: data) {
                                    Image(uiImage: image)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 64, height: 64)
                                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                }
                                Button {
                                    model.removeListingImage(at: index)
                                } label: {
                                    Image(systemName: "xmark")
                                        .font(.system(size: 8, weight: .bold))
                                        .foregroundStyle(.white)
                                        .frame(width: 20, height: 20)
                                        .background(Color.black.opacity(0.72))
                                        .clipShape(Circle())
                                }
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                                .offset(x: 4, y: -4)
                                Text(ListingCapturePlan.angleName(for: index))
                                    .font(.system(size: 8, weight: .bold, design: .rounded))
                                    .foregroundStyle(.white)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.7)
                                    .padding(.horizontal, 5)
                                    .frame(height: 18)
                                    .background(Color.black.opacity(0.68))
                                    .clipShape(Capsule())
                                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                    .padding(4)
                            }
                            .frame(width: 68, height: 68)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                }

                Spacer(minLength: 4)

                BOPrimaryButton(
                    title: recognitionButtonTitle,
                    disabled: !ListingCapturePlan.canProcess(
                        imageCount: model.listingDraft.images.count
                    )
                ) {
                    model.processListingImages()
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 12)
            }
        }
        .onChange(of: selectedPhotos) { _, newItems in
            Task {
                for item in newItems {
                    if let data = try? await item.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        model.addCapturedImage(image)
                    }
                }
                selectedPhotos = []
            }
        }
    }

    private var recognitionButtonTitle: String {
        let count = model.listingDraft.images.count
        return count == 0 ? "拍摄后处理并预览" : "处理并预览（\(count) 张）"
    }

    private var nextAngleHint: String {
        let count = model.listingDraft.images.count
        guard count < ListingCapturePlan.maximumImages else { return "已达 6 张上限" }
        return count == 0 ? "建议先拍正面" : "可补充\(ListingCapturePlan.angleName(for: count))"
    }

    private var cameraControls: some View {
        HStack {
            PhotosPicker(
                selection: $selectedPhotos,
                maxSelectionCount: max(
                    0,
                    ListingCapturePlan.maximumImages - model.listingDraft.images.count
                ),
                matching: .images
            ) {
                VStack(spacing: 4) {
                    Image(systemName: "photo.on.rectangle")
                        .font(.system(size: 20, weight: .semibold))
                    Text("相册")
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                }
                .foregroundStyle(.white)
                .frame(width: 54, height: 54)
                .background(.black.opacity(0.42))
                .clipShape(Circle())
            }

            Spacer()

            Button {
                guard cameraState == .running,
                      model.listingDraft.images.count < ListingCapturePlan.maximumImages
                else { return }
                cameraTrigger += 1
            } label: {
                Circle()
                    .fill(.white)
                    .frame(width: 72, height: 72)
                    .overlay(
                        Circle()
                            .stroke(.white.opacity(0.55), lineWidth: 5)
                            .padding(-7)
                    )
            }
            .disabled(
                cameraState != .running
                    || model.listingDraft.images.count >= ListingCapturePlan.maximumImages
            )

            Spacer()

            VStack(spacing: 4) {
                Image(systemName: "square.stack.3d.up")
                    .font(.system(size: 19, weight: .semibold))
                Text("连续拍")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(width: 54, height: 54)
            .background(.black.opacity(0.42))
            .clipShape(Circle())
        }
        .padding(.horizontal, 10)
    }

    @ViewBuilder
    private var cameraStatusOverlay: some View {
        ZStack {
            Color.black.opacity(0.78)
            VStack(spacing: 12) {
                switch cameraState {
                case .starting:
                    ProgressView()
                        .tint(.white)
                    Text("正在启动相机")
                case .denied:
                    Image(systemName: "camera.fill")
                        .font(.system(size: 30))
                    Text("相机权限未开启")
                    Button("前往系统设置") {
                        guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                        UIApplication.shared.open(url)
                    }
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 16)
                    .frame(height: 36)
                    .background(BOColor.red)
                    .clipShape(Capsule())
                case .unavailable, .interrupted:
                    Image(systemName: "camera.slash.fill")
                        .font(.system(size: 30))
                    Text(cameraState == .interrupted ? "相机暂时被系统中断" : "相机未能启动")
                    Button("重新启动相机") { cameraRetryTrigger += 1 }
                        .padding(.horizontal, 16)
                        .frame(height: 36)
                        .background(BOColor.red, in: Capsule())
                    Text("也可从左下角相册选择商品图")
                        .font(.system(size: 11, design: .rounded))
                        .foregroundStyle(.white.opacity(0.65))
                case .running:
                    EmptyView()
                }
            }
            .font(.system(size: 14, weight: .semibold, design: .rounded))
            .foregroundStyle(.white)
        }
    }
}

private struct ListingProcessingView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            ZStack {
                Circle().stroke(BOColor.line, lineWidth: 10)
                Circle()
                    .trim(from: 0, to: 0.72)
                    .stroke(BOColor.red, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                Image(systemName: "sparkles")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundStyle(BOColor.red)
            }
            .frame(width: 136, height: 136)
            Text("AI 正在处理")
                .font(.system(size: 24, weight: .heavy, design: .rounded))
            Text(model.listingProgress)
                .font(.system(size: 14, design: .rounded))
                .foregroundStyle(BOColor.secondary)
            Text("会分别优化每个角度，并保留商品真实细节")
                .font(.system(size: 12, design: .rounded))
                .foregroundStyle(BOColor.secondary)
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .padding(24)
    }
}

private struct ListingConfirmView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var printer: BluetoothPrinterManager
    @StateObject private var templates = LabelTemplateLibrary()
    @State private var selectedImageIndex = 0
    @State private var showingGallery = false
    @State private var showingFacetPicker = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Button {
                        model.returnToListingCapture()
                    } label: {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 17, weight: .semibold))
                            .frame(width: 36, height: 44)
                    }
                    .accessibilityLabel("返回拍照，保留草稿")
                    Text("商品信息确认")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                    Spacer()
                    Button("重新识别") {
                        model.processListingImages()
                    }
                    .disabled(model.listingRecognitionActive || model.listingUploadActive || model.listingDraft.submission != nil)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(BOColor.secondary)
                }

                ListingImageGallery(
                    urls: model.listingDraft.listingURLs,
                    localImages: model.listingDraft.images,
                    selectedIndex: $selectedImageIndex,
                    onOpen: { showingGallery = true }
                )

                if !model.listingProgress.isEmpty || !model.listingUploadProgress.isEmpty || model.listingUploadFailed {
                    HStack(alignment: .top, spacing: 10) {
                        if model.listingRecognitionActive || model.listingUploadActive {
                            ProgressView()
                                .controlSize(.small)
                                .tint(BOColor.red)
                        } else {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(BOColor.green)
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            Text(model.listingProgress)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(BOColor.ink)
                            if !model.listingUploadProgress.isEmpty {
                                Text(model.listingUploadProgress)
                                    .font(.system(size: 11))
                                    .foregroundStyle(BOColor.secondary)
                            }
                            if model.listingUploadFailed {
                                Button("重试原图备份") { model.retryListingUploads() }
                                    .font(.system(size: 12, weight: .semibold))
                                    .disabled(model.listingUploadActive || model.listingSubmissionActive || model.listingDraft.submission != nil)
                                    .accessibilityIdentifier("listing.retryOriginalUpload")
                            }
                            Text("原图保存后即可继续操作；主图修整会在上架后由 ERP 后台完成")
                                .font(.system(size: 11, design: .rounded))
                                .foregroundStyle(BOColor.secondary)
                        }
                        Spacer()
                    }
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(BOColor.field)
                    .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                }

                if !model.listingDraft.recognitionWarning.isEmpty {
                    Label(model.listingDraft.recognitionWarning, systemImage: "exclamationmark.triangle.fill")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color.orange)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.orange.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                }

                VStack(spacing: 14) {
                    FormField(title: "商品名称") {
                        TextField("待识别，可手动填写", text: $model.listingDraft.name)
                    }
                    FormField(title: "商品分类") {
                        Picker("商品分类", selection: $model.listingDraft.categoryCode) {
                            Text("待识别 / 选择分类").tag("")
                            if !model.listingDraft.categoryCode.isEmpty,
                               !model.productCategories.contains(where: { $0.code == model.listingDraft.categoryCode }) {
                                Text(model.listingDraft.category.isEmpty ? model.listingDraft.categoryCode : model.listingDraft.category)
                                    .tag(model.listingDraft.categoryCode)
                            }
                            ForEach(model.productCategories) { category in
                                Text(category.displayName).tag(category.code)
                            }
                        }
                        .labelsHidden()
                        .pickerStyle(.menu)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .onChange(of: model.listingDraft.categoryCode) { _, code in
                            model.listingDraft.category = model.productCategories
                                .first(where: { $0.code == code })?.displayName ?? model.listingDraft.category
                            model.reconcileListingFacetSelection()
                        }
                    }
                    FormField(title: "品牌") {
                        VStack(alignment: .leading, spacing: 8) {
                            TextField("品牌不确定可留空", text: Binding(
                                get: { model.listingDraft.brand },
                                set: {
                                    model.listingDraft.brand = $0
                                    model.listingDraft.brandID = nil
                                    model.listingDraft.brandConfirmed = false
                                    model.listingDraft.brandMatchStatus = "review_required"
                                }))
                            if model.listingDraft.brandMatchStatus == "matched" {
                                Label("已匹配 ERP 品牌", systemImage: "checkmark.circle.fill")
                                    .font(.caption).foregroundStyle(.green)
                            } else if !model.listingDraft.brand.isEmpty {
                                ForEach(model.listingDraft.brandSuggestions ?? []) { candidate in
                                    Button("选择 \(candidate.name)") {
                                        model.listingDraft.brand = candidate.name
                                        model.listingDraft.brandID = candidate.id
                                        model.listingDraft.brandConfirmed = true
                                        model.listingDraft.brandMatchStatus = "matched"
                                    }.font(.caption.weight(.semibold))
                                }
                                Button(model.listingDraft.brandConfirmed == true ? "已确认新品牌，提交后待总部审核" : "都不匹配？确认申请新建此品牌") {
                                    model.listingDraft.brandID = nil
                                    model.listingDraft.brandConfirmed = true
                                }.font(.caption).foregroundStyle(BOColor.navy)
                                Text("近似品牌需要确认；不确定可留空，不影响上架")
                                    .font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                    }
                    FormField(title: "年代 / 大致范围") {
                        TextField("例如：约1980年代，无依据可留空", text: $model.listingDraft.era)
                    }
                    FormField(title: "IP / 角色 / 系列") {
                        VStack(alignment: .leading, spacing: 8) {
                            TextField(
                                "例如：哆啦A梦、宝可梦",
                                text: Binding(
                                    get: { model.listingDraft.ipName },
                                    set: { value in
                                        model.listingDraft.ipName = value
                                        model.listingDraft.ipMatchStatus = value.isEmpty ? "empty" : "review_required"
                                        model.listingDraft.ipConfirmed = value.isEmpty
                                    }
                                )
                            )
                            if model.listingDraft.ipMatchStatus == "matched" {
                                Label("已匹配 ERP IP 库", systemImage: "checkmark.circle.fill")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(Color.green)
                            } else if !model.listingDraft.ipName.isEmpty {
                                HStack {
                                    Text("未找到完全匹配，请确认名称")
                                        .font(.caption)
                                        .foregroundStyle(Color.orange)
                                    Spacer()
                                    Button(model.listingDraft.ipConfirmed ? "已确认" : "确认新建") {
                                        model.listingDraft.ipConfirmed = true
                                    }
                                    .font(.caption.weight(.bold))
                                }
                            }
                        }
                    }
                    FormField(title: "商品标签") {
                        Button {
                            showingFacetPicker = true
                        } label: {
                            HStack(spacing: 8) {
                                let names = model.listingFacetsForCurrentCategory()
                                    .filter { model.listingDraft.normalizedFacetCodes.contains($0.code) }
                                    .map(\.name)
                                Text(names.isEmpty ? "选择 ERP 商品标签（可多选）" : names.joined(separator: "、"))
                                    .foregroundStyle(names.isEmpty ? BOColor.secondary : BOColor.ink)
                                    .multilineTextAlignment(.leading)
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 11, weight: .bold))
                                    .foregroundStyle(BOColor.secondary)
                            }
                        }
                        .buttonStyle(.plain)
                        .disabled(model.listingDraft.categoryCode.isEmpty)
                    }
                    FormField(title: "商品编码") {
                        HStack {
                            Image(systemName: "barcode")
                                .foregroundStyle(BOColor.secondary)
                            Text("由 ERP 确认上架后自动生成")
                                .foregroundStyle(BOColor.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    ConditionGradePicker(selection: $model.listingDraft.conditionGrade)
                    FormField(title: "售价") {
                        HStack {
                            Text("¥").foregroundStyle(BOColor.secondary)
                            TextField("0", text: $model.listingDraft.price)
                                .keyboardType(.decimalPad)
                                .accessibilityIdentifier("listing-price-editor")
                        }
                    }
                    Toggle("加入翻筐乐", isOn: Binding(
                        get: { model.listingDraft.inFankuang },
                        set: { model.listingDraft.fankuangOverride = $0 }
                    ))
                    .tint(BOColor.red)
                    .accessibilityIdentifier("listing-fankuang-toggle")
                    FormField(title: "商品简介（用于价签）") {
                        TextEditor(text: $model.listingDraft.description)
                            .frame(minHeight: 72)
                            .scrollContentBackground(.hidden)
                            .accessibilityIdentifier("listing-summary-editor")
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Button {
                            Task { await model.refreshListingSummary() }
                        } label: {
                            HStack(spacing: 6) {
                                if model.listingSummaryActive {
                                    ProgressView().controlSize(.small)
                                } else {
                                    Image(systemName: "arrow.clockwise")
                                }
                                Text(model.listingSummaryActive ? "正在刷新简介…" : "刷新简介")
                            }
                            .font(.system(size: 13, weight: .semibold))
                            .frame(minHeight: 44)
                        }
                        .buttonStyle(.plain)
                        .foregroundStyle(BOColor.red)
                        .disabled(model.listingSummaryActive || model.listingRecognitionActive || model.listingSubmissionActive)
                        .accessibilityIdentifier("listing-summary-refresh")
                        Text(model.listingSummaryStatus.isEmpty
                             ? "仅刷新简介，不重新识别或修改其他资料"
                             : model.listingSummaryStatus)
                            .font(.caption)
                            .foregroundStyle(BOColor.secondary)
                            .accessibilityIdentifier("listing-summary-status")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(16)
                .boCard()
                .disabled(model.listingDraft.submission != nil)

                Button {
                    submit(.listOnly)
                } label: {
                    Text(model.listingDraft.submission == nil ? "确认上架" : "重试确认上架结果")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(BOColor.ink)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 15, style: .continuous)
                                .stroke(BOColor.line, lineWidth: 1)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                }
                .disabled(!canSubmit || model.busy || model.listingSubmissionActive)

                BOPrimaryButton(
                    title: model.listingDraft.submission == nil ? "上架并打印" : "确认上架后打印",
                    disabled: !canSubmit || model.busy || model.listingSubmissionActive
                ) {
                    submit(.listAndPrint)
                }
            }
            .padding(20)
            .padding(.bottom, 20)
        }
        .fullScreenCover(isPresented: $showingGallery) {
            FullScreenListingGallery(
                urls: model.listingDraft.listingURLs,
                localImages: model.listingDraft.images,
                initialIndex: selectedImageIndex
            )
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 24).onEnded { value in
                if ListingBackGesture.shouldReturn(startX: value.startLocation.x,
                    horizontal: value.translation.width, vertical: value.translation.height) {
                    model.returnToListingCapture()
                }
            }
        )
        .onDisappear { model.saveListingDraft() }
        .sheet(isPresented: $showingFacetPicker) {
            ProductFacetSelectionSheet(options: model.listingFacetsForCurrentCategory())
                .environmentObject(model)
        }
        .task {
            if model.selectedLocation != nil, templates.collection.items.isEmpty {
                await templates.load(model: model)
            }
        }
    }

    private var canSubmit: Bool {
        ListingConfirmationRules.canSubmit(
            model.listingDraft,
            processedImageCount: model.listingDraft.uploadedPaths.count
        )
    }

    private func submit(_ action: ListingSubmissionAction) {
        if action.shouldPrint {
            model.createListing(onSubmitting: {
                printer.prepareForListing()
            }, onCreated: { product in
                handleCreatedProduct(product)
            })
        } else {
            model.createListing()
        }
    }

    private func handleCreatedProduct(_ product: Product) {
        switch ListingAutoPrintPolicy.action(isPrinterConnected: printer.isConnected) {
        case .printLabel, .connectThenPrint:
            model.toastMessage = printer.isConnected
                ? "商品已上架，正在发送标签"
                : "商品已上架，正在连接打印机（最多 10 秒）"
            let template = templates.selected(for: .label) ?? .localDefault
            printer.printProductLabel(product, template: template) { result in
                switch result {
                case .success:
                    model.toastMessage = "商品已上架，标签已发送到打印机"
                case .failure(let error):
                    model.errorMessage = "商品已保存并上架，无需重复上架。标签未完成：\(error.localizedDescription)。可在商品详情补打标签。"
                }
            }
        }
    }
}

private struct ProductFacetSelectionSheet: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    let options: [ProductFacetOption]

    private var dimensions: [String] {
        let order = ["object_type", "function", "origin", "material", "era", "craft", "style", "ip", "character", "series", "release_method"]
        let configured = order.filter { dimension in options.contains(where: { $0.dimension == dimension }) }
        let remaining = Set(options.map(\.dimension)).subtracting(configured).sorted()
        return configured + remaining
    }

    var body: some View {
        NavigationStack {
            Group {
                if options.isEmpty {
                    ContentUnavailableView("当前分类暂无可选标签", systemImage: "tag")
                } else {
                    List {
                        ForEach(dimensions, id: \.self) { dimension in
                            let values = options.filter { $0.dimension == dimension }
                            Section(values.first?.dimensionName ?? "商品标签") {
                                ForEach(values) { option in
                                    Button {
                                        model.toggleListingFacet(option.code)
                                    } label: {
                                        HStack {
                                            Text(option.name)
                                                .foregroundStyle(BOColor.ink)
                                            Spacer()
                                            if model.listingDraft.normalizedFacetCodes.contains(option.code) {
                                                Image(systemName: "checkmark.circle.fill")
                                                    .foregroundStyle(BOColor.red)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("选择商品标签")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }
}

private struct ListingImageGallery: View {
    let urls: [String]
    let localImages: [Data]
    @Binding var selectedIndex: Int
    let onOpen: () -> Void

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selectedIndex) {
                ForEach(0..<ListingConfirmationRules.imageCount(urls: urls, localImages: localImages), id: \.self) { index in
                    ListingPreviewImage(url: urls.indices.contains(index) ? urls[index] : "", localData: localImages.indices.contains(index) ? localImages[index] : nil)
                        .tag(index)
                        .contentShape(Rectangle())
                        .onTapGesture(perform: onOpen)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .aspectRatio(1, contentMode: .fit)
            .background(BOColor.field)

            HStack {
                Label(
                    ListingCapturePlan.angleName(for: selectedIndex),
                    systemImage: "camera.viewfinder"
                )
                Spacer()
                Text("点击放大")
                Spacer()
                Text(ListingConfirmationRules.pageLabel(index: selectedIndex, count: ListingConfirmationRules.imageCount(urls: urls, localImages: localImages)))
                    .monospacedDigit()
            }
            .font(.system(size: 11, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .padding(.horizontal, 12)
            .frame(height: 36)
            .background(.black.opacity(0.52))
        }
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

private struct ListingPreviewImage: View {
    let url: String
    let localData: Data?

    var body: some View {
        CachedProductImage(urlString: url, pixelSize: 2400, contentMode: .fit, fallbackData: localData)
    }
}

struct FullScreenListingGallery: View {
    @Environment(\.dismiss) private var dismiss
    let urls: [String]
    let localImages: [Data]
    @State private var selectedIndex: Int

    init(urls: [String], localImages: [Data], initialIndex: Int) {
        self.urls = urls
        self.localImages = localImages
        _selectedIndex = State(initialValue: initialIndex)
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            TabView(selection: $selectedIndex) {
                ForEach(0..<ListingConfirmationRules.imageCount(urls: urls, localImages: localImages), id: \.self) { index in
                    ZoomableListingImage(
                        url: urls.indices.contains(index) ? urls[index] : "",
                        localData: localImages.indices.contains(index) ? localImages[index] : nil
                    )
                        .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))

            VStack {
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 40, height: 40)
                            .background(.black.opacity(0.55))
                            .clipShape(Circle())
                    }
                    Spacer()
                    Text(ListingConfirmationRules.pageLabel(index: selectedIndex, count: ListingConfirmationRules.imageCount(urls: urls, localImages: localImages)))
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 13)
                        .frame(height: 34)
                        .background(.black.opacity(0.55))
                        .clipShape(Capsule())
                }
                Spacer()
            }
            .padding(16)
        }
    }
}

private struct ZoomableListingImage: View {
    let url: String
    let localData: Data?

    var body: some View {
        ZoomablePhotoContainer(content: ListingPreviewImage(url: url, localData: localData))
            .modifier(ProductPhotoSaveMenu(urlString: url, fallbackData: localData))
    }
}

private struct ConditionGradePicker: View {
    @Binding var selection: String

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("商品成色")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(BOColor.secondary)

            ForEach(ConditionGrade.allCases) { grade in
                Button {
                    selection = grade.rawValue
                } label: {
                    HStack(spacing: 12) {
                        Text(grade.rawValue)
                            .font(.system(size: 16, weight: .heavy, design: .rounded))
                            .foregroundStyle(selection == grade.rawValue ? .white : BOColor.red)
                            .frame(width: 38, height: 38)
                            .background(selection == grade.rawValue ? BOColor.red : BOColor.red.opacity(0.1))
                            .clipShape(Circle())
                        VStack(alignment: .leading, spacing: 3) {
                            Text(grade.title)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(BOColor.ink)
                            Text(grade.description)
                                .font(.system(size: 10.5, design: .rounded))
                                .foregroundStyle(BOColor.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 4)
                        Image(systemName: selection == grade.rawValue ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(selection == grade.rawValue ? BOColor.red : BOColor.line)
                    }
                    .padding(11)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(selection == grade.rawValue ? BOColor.red.opacity(0.06) : BOColor.field)
                    .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
    }
}

private struct FormField<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(BOColor.secondary)
            content
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .padding(.horizontal, 13)
                .frame(minHeight: 46)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(BOColor.field)
                .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
        }
    }
}

enum CameraPreviewState: Equatable {
    case starting
    case running
    case denied
    case unavailable
    case interrupted

    static func resolve(isRunning: Bool, isPreviewing: Bool, isInterrupted: Bool) -> Self {
        if isInterrupted { return .interrupted }
        guard isRunning else { return .unavailable }
        return isPreviewing ? .running : .starting
    }
}

final class CameraPreviewSurface: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}

private struct CameraPreview: UIViewControllerRepresentable {
    @Binding var trigger: Int
    let retryTrigger: Int
    @Binding var state: CameraPreviewState
    let isActive: Bool
    let onImage: (UIImage) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(
            onImage: onImage,
            onStateChange: { newState in
                state = newState
            }
        )
    }

    func makeUIViewController(context: Context) -> CameraController {
        let controller = CameraController()
        controller.setEnabled(isActive)
        controller.photoDelegate = context.coordinator
        controller.stateHandler = { [weak coordinator = context.coordinator] newState in
            DispatchQueue.main.async {
                guard let coordinator, coordinator.isActive else { return }
                coordinator.onStateChange(newState)
            }
        }
        return controller
    }

    func updateUIViewController(_ controller: CameraController, context: Context) {
        controller.setEnabled(isActive)
        if retryTrigger != context.coordinator.lastRetryTrigger {
            context.coordinator.lastRetryTrigger = retryTrigger
            controller.retry()
        }
        guard trigger != context.coordinator.lastTrigger else { return }
        context.coordinator.lastTrigger = trigger
        controller.capture()
    }

    static func dismantleUIViewController(_ controller: CameraController, coordinator: Coordinator) {
        coordinator.isActive = false
        controller.setEnabled(false)
        controller.stateHandler = nil
        controller.photoDelegate = nil
    }

    final class Coordinator: NSObject, AVCapturePhotoCaptureDelegate {
        var lastTrigger = 0
        var lastRetryTrigger = 0
        var isActive = true
        let onImage: (UIImage) -> Void
        let onStateChange: (CameraPreviewState) -> Void

        init(
            onImage: @escaping (UIImage) -> Void,
            onStateChange: @escaping (CameraPreviewState) -> Void
        ) {
            self.onImage = onImage
            self.onStateChange = onStateChange
        }

        func photoOutput(
            _ output: AVCapturePhotoOutput,
            didFinishProcessingPhoto photo: AVCapturePhoto,
            error: Error?
        ) {
            guard error == nil,
                  let data = photo.fileDataRepresentation(),
                  let image = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                if self.isActive { self.onImage(image) }
            }
        }
    }
}

final class CameraController: UIViewController {
    let session = AVCaptureSession()
    let output = AVCapturePhotoOutput()
    weak var photoDelegate: AVCapturePhotoCaptureDelegate?
    var stateHandler: ((CameraPreviewState) -> Void)?
    private let surface = CameraPreviewSurface()
    private var preview: AVCaptureVideoPreviewLayer { surface.previewLayer }
    private var configured = false
    private let sessionQueue = DispatchQueue(label: "boomer.listing-camera", qos: .userInitiated)
    private var camera: AVCaptureDevice?
    private var subjectObserver: NSObjectProtocol?
    private var observers: [NSObjectProtocol] = []
    private var previewObservation: NSKeyValueObservation?
    private var startupTimeout: DispatchWorkItem?
    private var isVisible = false
    private var isEnabled = true
    private var wantsPreview = false
    private var startAttemptFinished = false
    private var activityRevision = 0
    private let focusIndicator = UIView()
    private var zoomStart: CGFloat = 1

    deinit {
        if let subjectObserver { NotificationCenter.default.removeObserver(subjectObserver) }
        observers.forEach(NotificationCenter.default.removeObserver)
        startupTimeout?.cancel()
    }

    override func loadView() {
        view = surface
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        preview.session = session
        preview.videoGravity = .resizeAspectFill
        previewObservation = preview.observe(\.isPreviewing, options: [.new]) { [weak self] _, _ in
            DispatchQueue.main.async { self?.refreshPreviewState() }
        }
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tapToFocus(_:))))
        view.addGestureRecognizer(UIPinchGestureRecognizer(target: self, action: #selector(pinchToZoom(_:))))
        focusIndicator.layer.borderColor = UIColor.systemYellow.cgColor
        focusIndicator.layer.borderWidth = 1.5
        focusIndicator.layer.cornerRadius = 8
        focusIndicator.isUserInteractionEnabled = false
        focusIndicator.alpha = 0
        view.addSubview(focusIndicator)
        observe(UIApplication.willResignActiveNotification) { $0.updateActivity(appActive: false) }
        observe(UIApplication.didBecomeActiveNotification) { $0.updateActivity(appActive: true) }
        observe(.AVCaptureSessionWasInterrupted, object: session) { $0.refreshPreviewState() }
        observe(.AVCaptureSessionInterruptionEnded, object: session) { $0.refreshPreviewState() }
        observe(.AVCaptureSessionRuntimeError, object: session) { controller in
            guard controller.wantsPreview else { return }
            controller.startupTimeout?.cancel()
            controller.stateHandler?(.unavailable)
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        isVisible = true
        updateActivity()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        isVisible = false
        updateActivity()
    }

    private func observe(_ name: Notification.Name, object: Any? = nil, action: @escaping (CameraController) -> Void) {
        observers.append(NotificationCenter.default.addObserver(forName: name, object: object, queue: .main) { [weak self] _ in
            if let self { action(self) }
        })
    }

    func setEnabled(_ enabled: Bool) {
        guard isEnabled != enabled else { return }
        isEnabled = enabled
        updateActivity()
    }

    func retry() {
        updateActivity(forceRestart: true)
    }

    private func updateActivity(appActive: Bool? = nil, forceRestart: Bool = false) {
        let active = isVisible && isEnabled && (appActive ?? (UIApplication.shared.applicationState == .active))
        guard active != wantsPreview || forceRestart else { return }
        wantsPreview = active
        activityRevision += 1
        startupTimeout?.cancel()
        startAttemptFinished = false
        if !active || forceRestart {
            sessionQueue.async { [session] in
                // Interrupted sessions also retain a start request even when isRunning is false.
                session.stopRunning()
            }
        }
        guard active else { return }
        stateHandler?(.starting)
        requestPermissionAndConfigure()
    }

    private func requestPermissionAndConfigure() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            startSessionIfNeeded()
        case .notDetermined:
            stateHandler?(.starting)
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    guard let self, self.wantsPreview else { return }
                    if granted {
                        self.startSessionIfNeeded()
                    } else {
                        self.stateHandler?(.denied)
                    }
                }
            }
        case .denied, .restricted:
            stateHandler?(.denied)
        @unknown default:
            stateHandler?(.unavailable)
        }
    }

    // Configuration, capture and start/stop share one queue so rapid tab changes cannot overlap them.
    private func configureAuthorizedSession() -> Bool {
        guard !configured else { return true }
        session.beginConfiguration()
        session.sessionPreset = .photo
        let preferred = AVCaptureDevice.default(.builtInTripleCamera, for: .video, position: .back)
            ?? AVCaptureDevice.default(.builtInDualWideCamera, for: .video, position: .back)
            ?? AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
        guard let camera = preferred,
              let input = try? AVCaptureDeviceInput(device: camera),
              session.canAddInput(input),
              session.canAddOutput(output) else {
            session.commitConfiguration()
            return false
        }
        session.addInput(input)
        session.addOutput(output)
        output.maxPhotoQualityPrioritization = .quality
        session.commitConfiguration()
        self.camera = camera
        if let wideZoom = camera.virtualDeviceSwitchOverVideoZoomFactors.first {
            do {
                try camera.lockForConfiguration()
                defer { camera.unlockForConfiguration() }
                camera.videoZoomFactor = min(max(CGFloat(truncating: wideZoom), camera.minAvailableVideoZoomFactor), camera.maxAvailableVideoZoomFactor)
            } catch { }
        }
        focus(at: CGPoint(x: 0.5, y: 0.5))
        subjectObserver = NotificationCenter.default.addObserver(
            forName: .AVCaptureDeviceSubjectAreaDidChange, object: camera, queue: nil
        ) { [weak self] _ in
            self?.sessionQueue.async { [weak self] in self?.focus(at: CGPoint(x: 0.5, y: 0.5)) }
        }
        configured = true
        return true
    }

    private func startSessionIfNeeded() {
        let revision = activityRevision
        let timeout = DispatchWorkItem { [weak self] in
            guard let self, self.wantsPreview, revision == self.activityRevision,
                  !self.preview.isPreviewing else { return }
            self.stateHandler?(self.session.isInterrupted ? .interrupted : .unavailable)
        }
        startupTimeout = timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 6, execute: timeout)
        sessionQueue.async { [weak self] in
            guard let self else { return }
            let ready = self.configureAuthorizedSession()
            if ready && !self.session.isRunning { self.session.startRunning() }
            DispatchQueue.main.async {
                guard self.wantsPreview, revision == self.activityRevision else { return }
                self.startAttemptFinished = true
                self.refreshPreviewState()
            }
        }
    }

    private func refreshPreviewState() {
        guard wantsPreview, startAttemptFinished else { return }
        let state = CameraPreviewState.resolve(isRunning: session.isRunning,
            isPreviewing: preview.isPreviewing, isInterrupted: session.isInterrupted)
        if state == .running { startupTimeout?.cancel() }
        stateHandler?(state)
    }

    func capture() {
        sessionQueue.async { [weak self] in self?.captureWhenFocused(attempt: 0) }
    }

    private func captureWhenFocused(attempt: Int) {
        guard session.isRunning, let photoDelegate else { return }
        if camera?.isAdjustingFocus == true, attempt < 15 {
            sessionQueue.asyncAfter(deadline: .now() + 0.05) { [weak self] in
                self?.captureWhenFocused(attempt: attempt + 1)
            }
            return
        }
        let settings = AVCapturePhotoSettings()
        settings.photoQualityPrioritization = .balanced
        output.capturePhoto(with: settings, delegate: photoDelegate)
    }

    @objc private func tapToFocus(_ gesture: UITapGestureRecognizer) {
        let location = gesture.location(in: view)
        let point = preview.captureDevicePointConverted(fromLayerPoint: location)
        focusIndicator.frame = CGRect(x: location.x - 32, y: location.y - 32, width: 64, height: 64)
        focusIndicator.layer.removeAllAnimations()
        focusIndicator.alpha = 1
        UIView.animate(withDuration: 0.3, delay: 1) { self.focusIndicator.alpha = 0 }
        sessionQueue.async { [weak self] in self?.focus(at: point) }
    }

    private func focus(at point: CGPoint) {
        guard let camera else { return }
        do {
            try camera.lockForConfiguration()
            defer { camera.unlockForConfiguration() }
            if camera.isFocusPointOfInterestSupported { camera.focusPointOfInterest = point }
            if camera.isFocusModeSupported(.continuousAutoFocus) { camera.focusMode = .continuousAutoFocus }
            if camera.isExposurePointOfInterestSupported { camera.exposurePointOfInterest = point }
            if camera.isExposureModeSupported(.continuousAutoExposure) { camera.exposureMode = .continuousAutoExposure }
            if camera.isSmoothAutoFocusSupported { camera.isSmoothAutoFocusEnabled = true }
            camera.isSubjectAreaChangeMonitoringEnabled = true
        } catch { }
    }

    @objc private func pinchToZoom(_ gesture: UIPinchGestureRecognizer) {
        guard let camera else { return }
        if gesture.state == .began { zoomStart = camera.videoZoomFactor }
        let zoom = min(max(zoomStart * gesture.scale, camera.minAvailableVideoZoomFactor), min(8, camera.maxAvailableVideoZoomFactor))
        sessionQueue.async {
            do {
                try camera.lockForConfiguration()
                defer { camera.unlockForConfiguration() }
                camera.videoZoomFactor = zoom
            } catch { }
        }
    }
}
