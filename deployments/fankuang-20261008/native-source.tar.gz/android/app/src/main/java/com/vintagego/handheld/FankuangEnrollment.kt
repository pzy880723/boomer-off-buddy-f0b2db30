package com.vintagego.handheld

import java.math.BigDecimal

fun fankuangEnrollment(price: String, override: Boolean?, productType: String = "custom"): Boolean {
    if (productType != "custom") return false
    override?.let { return it }
    val amount = price.trim().toBigDecimalOrNull() ?: return false
    return amount > BigDecimal.ZERO && amount <= BigDecimal("49.9")
}
