package com.vintagego.handheld

data class Item(
    val itemNo: String,
    val name: String,
    val priceCents: Int,
    val category: String,
    val categoryCode: String = "",
    val facetCodes: List<String> = emptyList(),
    val tags: List<String> = emptyList(),
    val recognitionRequestId: String = "",
    val categoryConfidence: Double? = null,
    val classificationStatus: String = "",
    val aiSuggestedPriceCny: Double? = null,
    val imagePath: String,
    val listingStoragePath: String = "",
    val listingStoragePaths: List<String> = emptyList(),
    val listingImageUrl: String = "",
    val originalImagePath: String = "",
    val originalImagePaths: List<String> = emptyList(),
    val brand: String = "",
    val ipName: String = "",
    val ipConfirmed: Boolean = true,
    val material: String = "",
    val color: String = "",
    val conditionGrade: String = "A",
    val conditionNote: String = "请人工确认成色",
    val createdAt: Long = System.currentTimeMillis(),
    val productType: String = "custom",
    val stockQty: Int = 0,
    val isDisplay: Boolean = true,
    val listingStatus: String = "selling",
    val statusLabel: String = "销售中",
    val canRestock: Boolean = false,
    val sourceLabel: String = "本机",
    val editable: Boolean = true,
    val isUnlimitedStock: Boolean = false,
    val imageProcessingStatus: String = "idle",
    val productStocks: List<ProductStock> = emptyList(),
    val erpId: String = "",
    val era: String = "",
    val fankuangOverride: Boolean? = null,
    val canEdit: Boolean? = null,
    val updatedAt: String = "",
)

fun listingImageProcessingLabel(status: String?): String? =
    when (status) {
        "queued", "processing" -> "主图正在修图"
        "retryable_failed" -> "主图正在修图，正在自动重试"
        "partial_failed" -> "部分主图修图未完成"
        else -> null
    }

fun shouldPollListingImage(status: String?): Boolean =
    status == "queued" || status == "processing" || status == "retryable_failed"
