package com.vintagego.handheld

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ItemStore(context: Context) {
    private val preferences = context.getSharedPreferences("items", Context.MODE_PRIVATE)

    fun save(item: Item) {
        val items = all().filterNot { it.itemNo == item.itemNo } + item
        val data = JSONArray()
        items.forEach { data.put(it.toJson()) }
        preferences.edit().putString("data", data.toString()).apply()
    }

    fun find(itemNo: String): Item? {
        return all().firstOrNull { it.itemNo.equals(itemNo.trim(), ignoreCase = true) }
    }

    fun all(): List<Item> {
        val data = JSONArray(preferences.getString("data", "[]"))
        return buildList {
            for (index in 0 until data.length()) add(data.getJSONObject(index).toItem())
        }.sortedByDescending(Item::createdAt)
    }

    private fun Item.toJson() = JSONObject()
        .put("itemNo", itemNo)
        .put("name", name)
        .put("priceCents", priceCents)
        .put("fankuangOverride", fankuangOverride ?: JSONObject.NULL)
        .put("category", category)
        .put("categoryCode", categoryCode)
        .put("facetCodes", JSONArray(facetCodes))
        .put("tags", JSONArray(tags))
        .put("recognitionRequestId", recognitionRequestId)
        .put("categoryConfidence", categoryConfidence)
        .put("classificationStatus", classificationStatus)
        .put("aiSuggestedPriceCny", aiSuggestedPriceCny)
        .put("imagePath", imagePath)
        .put("listingStoragePath", listingStoragePath)
        .put("listingStoragePaths", JSONArray(listingStoragePaths))
        .put("listingImageUrl", listingImageUrl)
        .put("originalImagePath", originalImagePath)
        .put("originalImagePaths", JSONArray(originalImagePaths))
        .put("brand", brand)
        .put("ipName", ipName)
        .put("ipConfirmed", ipConfirmed)
        .put("material", material)
        .put("color", color)
        .put("conditionGrade", conditionGrade)
        .put("conditionNote", conditionNote)
        .put("createdAt", createdAt)
        .put("productType", productType)
        .put("stockQty", stockQty)
        .put("isDisplay", isDisplay)
        .put("isUnlimitedStock", isUnlimitedStock)
        .put("listingStatus", listingStatus)
        .put("statusLabel", statusLabel)
        .put("canRestock", canRestock)
        .put("sourceLabel", sourceLabel)
        .put("editable", editable)

    private fun JSONObject.toItem() = Item(
        itemNo = getString("itemNo"),
        name = getString("name"),
        priceCents = getInt("priceCents"),
        fankuangOverride = opt("fankuangOverride") as? Boolean,
        category = optString("category"),
        categoryCode = optString("categoryCode"),
        facetCodes = optJSONArray("facetCodes").orEmptyStrings(),
        tags = optJSONArray("tags").orEmptyStrings(),
        recognitionRequestId = optString("recognitionRequestId"),
        categoryConfidence = if (has("categoryConfidence") && !isNull("categoryConfidence")) {
            optDouble("categoryConfidence")
        } else {
            null
        },
        classificationStatus = optString("classificationStatus"),
        aiSuggestedPriceCny = if (has("aiSuggestedPriceCny") && !isNull("aiSuggestedPriceCny")) {
            optDouble("aiSuggestedPriceCny")
        } else {
            null
        },
        imagePath = optString("imagePath"),
        listingStoragePath = optString("listingStoragePath"),
        listingStoragePaths = optJSONArray("listingStoragePaths").orEmptyStrings(),
        listingImageUrl = optString("listingImageUrl"),
        originalImagePath = optString("originalImagePath"),
        originalImagePaths = optJSONArray("originalImagePaths").orEmptyStrings(),
        brand = optString("brand"),
        ipName = optString("ipName"),
        ipConfirmed = optBoolean("ipConfirmed", true),
        material = optString("material"),
        color = optString("color"),
        conditionGrade = optString("conditionGrade", "A"),
        conditionNote = optString("conditionNote", "请人工确认成色"),
        createdAt = optLong("createdAt", System.currentTimeMillis()),
        productType = optString("productType", "custom"),
        stockQty = optInt("stockQty", 0),
        isDisplay = optBoolean("isDisplay", true),
        isUnlimitedStock = optBoolean("isUnlimitedStock", false),
        listingStatus = optString("listingStatus", "selling"),
        statusLabel = optString("statusLabel", "销售中"),
        canRestock = optBoolean("canRestock", false),
        sourceLabel = optString("sourceLabel", "本机"),
        editable = optBoolean("editable", true),
    )

    private fun JSONArray?.orEmptyStrings(): List<String> = buildList {
        val array = this@orEmptyStrings ?: return@buildList
        for (index in 0 until array.length()) {
            val value = array.optString(index)
            if (value.isNotBlank()) add(value)
        }
    }
}
