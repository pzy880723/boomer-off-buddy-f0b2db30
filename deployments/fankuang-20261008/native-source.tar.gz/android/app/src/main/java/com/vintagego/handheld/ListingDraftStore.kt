package com.vintagego.handheld

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ListingDraft(
    val photoPath: String = "",
    val photoPaths: List<String> = emptyList(),
    val listingStoragePath: String = "",
    val listingStoragePaths: List<String> = emptyList(),
    val listingImageUrl: String = "",
    val originalPhotoPath: String = "",
    val originalPhotoPaths: List<String> = emptyList(),
    val itemNo: String = "",
    val name: String = "",
    val category: String = "",
    val categoryCode: String = "",
    val facetCodes: List<String> = emptyList(),
    val recognitionRequestId: String = "",
    val classificationStatus: String = "",
    val aiSuggestedPriceCny: Double? = null,
    val brand: String = "",
    val ipName: String = "",
    val ipMatchStatus: String = "empty",
    val ipConfirmed: Boolean = true,
    val ipSuggestions: List<RecognitionIpSuggestion> = emptyList(),
    val material: String = "",
    val color: String = "",
    val conditionGrade: String = "",
    val conditionNote: String = "",
    val confidence: Double = 0.0,
    val price: String = "",
    val fankuangOverride: Boolean? = null,
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val hasContent: Boolean
        get() = photoPaths.isNotEmpty() || listOf(photoPath, name, category, price, conditionNote).any { it.isNotBlank() }
}

class ListingDraftStore(context: Context) {
    private val preferences = context.getSharedPreferences("listing_draft", Context.MODE_PRIVATE)

    fun save(state: UiState) {
        val draft = ListingDraft(
            photoPath = state.photo?.absolutePath.orEmpty(),
            photoPaths = state.photoBatch,
            listingStoragePath = state.listingStoragePath,
            listingStoragePaths = state.listingStoragePaths,
            listingImageUrl = state.listingImageUrl,
            originalPhotoPath = state.originalPhoto?.absolutePath.orEmpty(),
            originalPhotoPaths = state.originalPhotoBatch,
            itemNo = state.itemNo,
            name = state.name,
            category = state.category,
            categoryCode = state.categoryCode,
            facetCodes = state.selectedFacetCodes,
            recognitionRequestId = state.recognitionRequestId,
            classificationStatus = state.classificationStatus,
            aiSuggestedPriceCny = state.aiSuggestedPriceCny,
            brand = state.brand,
            ipName = state.ipName,
            ipMatchStatus = state.ipMatchStatus,
            ipConfirmed = state.ipConfirmed,
            ipSuggestions = state.ipSuggestions,
            material = state.material,
            color = state.color,
            conditionGrade = state.conditionGrade,
            conditionNote = state.conditionNote,
            confidence = state.confidence,
            price = state.price,
            fankuangOverride = state.fankuangOverride,
        )
        if (!draft.hasContent) return
        preferences.edit().putString(KEY, draft.toJson().toString()).apply()
    }

    fun load(): ListingDraft? {
        val raw = preferences.getString(KEY, null) ?: return null
        return runCatching { JSONObject(raw).toDraft() }
            .getOrNull()
            ?.takeIf { draft ->
                draft.hasContent && (draft.photoPath.isBlank() || File(draft.photoPath).exists())
            }
    }

    fun clear() {
        preferences.edit().remove(KEY).apply()
    }

    private fun ListingDraft.toJson() = JSONObject()
        .put("photoPath", photoPath)
        .put("photoPaths", JSONArray(photoPaths))
        .put("listingStoragePath", listingStoragePath)
        .put("listingStoragePaths", JSONArray(listingStoragePaths))
        .put("listingImageUrl", listingImageUrl)
        .put("originalPhotoPath", originalPhotoPath)
        .put("originalPhotoPaths", JSONArray(originalPhotoPaths))
        .put("itemNo", itemNo)
        .put("name", name)
        .put("category", category)
        .put("categoryCode", categoryCode)
        .put("facetCodes", JSONArray(facetCodes))
        .put("recognitionRequestId", recognitionRequestId)
        .put("classificationStatus", classificationStatus)
        .put("aiSuggestedPriceCny", aiSuggestedPriceCny)
        .put("brand", brand)
        .put("ipName", ipName)
        .put("ipMatchStatus", ipMatchStatus)
        .put("ipConfirmed", ipConfirmed)
        .put("ipSuggestions", JSONArray(ipSuggestions.map {
            JSONObject().put("id", it.id).put("name", it.name).put("confidence", it.confidence)
        }))
        .put("material", material)
        .put("color", color)
        .put("conditionGrade", conditionGrade)
        .put("conditionNote", conditionNote)
        .put("confidence", confidence)
        .put("price", price)
        .put("fankuangOverride", fankuangOverride ?: JSONObject.NULL)
        .put("updatedAt", updatedAt)

    private fun JSONObject.toDraft() = ListingDraft(
        photoPath = optString("photoPath"),
        photoPaths = optJSONArray("photoPaths").orEmptyStrings(),
        listingStoragePath = optString("listingStoragePath"),
        listingStoragePaths = optJSONArray("listingStoragePaths").orEmptyStrings(),
        listingImageUrl = optString("listingImageUrl"),
        originalPhotoPath = optString("originalPhotoPath"),
        originalPhotoPaths = optJSONArray("originalPhotoPaths").orEmptyStrings(),
        itemNo = optString("itemNo"),
        name = optString("name"),
        category = optString("category"),
        categoryCode = optString("categoryCode"),
        facetCodes = optJSONArray("facetCodes").orEmptyStrings(),
        recognitionRequestId = optString("recognitionRequestId"),
        classificationStatus = optString("classificationStatus"),
        aiSuggestedPriceCny = if (has("aiSuggestedPriceCny") && !isNull("aiSuggestedPriceCny")) {
            optDouble("aiSuggestedPriceCny")
        } else {
            null
        },
        brand = optString("brand"),
        ipName = optString("ipName"),
        ipMatchStatus = optString("ipMatchStatus", "empty"),
        ipConfirmed = optBoolean("ipConfirmed", true),
        ipSuggestions = optJSONArray("ipSuggestions").orEmptyObjects().map {
            RecognitionIpSuggestion(
                id = it.optString("id"),
                name = it.optString("name"),
                confidence = it.optDouble("confidence", 0.0),
            )
        },
        material = optString("material"),
        color = optString("color"),
        conditionGrade = optString("conditionGrade"),
        conditionNote = optString("conditionNote"),
        confidence = optDouble("confidence", 0.0),
        price = optString("price"),
        fankuangOverride = opt("fankuangOverride") as? Boolean,
        updatedAt = optLong("updatedAt", System.currentTimeMillis()),
    )

    private fun JSONArray?.orEmptyStrings(): List<String> = buildList {
        val array = this@orEmptyStrings ?: return@buildList
        for (index in 0 until array.length()) {
            val value = array.optString(index)
            if (value.isNotBlank()) add(value)
        }
    }

    companion object {
        private const val KEY = "draft_json"
    }

    private fun JSONArray?.orEmptyObjects(): List<JSONObject> = buildList {
        val array = this@orEmptyObjects ?: return@buildList
        for (index in 0 until array.length()) array.optJSONObject(index)?.let(::add)
    }
}
