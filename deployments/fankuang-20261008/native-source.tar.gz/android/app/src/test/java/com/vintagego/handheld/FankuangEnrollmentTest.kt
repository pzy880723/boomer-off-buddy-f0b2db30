package com.vintagego.handheld

import org.junit.Assert.*
import org.junit.Test

class FankuangEnrollmentTest {
    @Test fun automaticBoundaryAndManualPriority() {
        assertTrue(fankuangEnrollment("49.9", null))
        assertFalse(fankuangEnrollment("49.91", null))
        assertFalse(fankuangEnrollment("50", null))
        assertFalse(fankuangEnrollment("", null))
        assertFalse(fankuangEnrollment("9.9", false))
        assertTrue(fankuangEnrollment("199", true))
        assertFalse(fankuangEnrollment("9.9", true, "standard"))
    }
}
